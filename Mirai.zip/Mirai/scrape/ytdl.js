const axios = require('axios');

function ytdlmp3(url) {
    return new Promise((resolve, reject) => {
        let myA = [];
        axios({
            url: "https://yt1s.com/api/ajaxSearch/index",
            method: "POST",
            data: new URLSearchParams(Object.entries({
                q: url,
                vt: 'home'
            })),
            headers: {
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'
            }
        }).then(r => {
            myA.push({
                title: r.data.title,
                filesize: r.data.links.mp3['mp3128'].size,
                qualityType: r.data.links.mp3['mp3128'].q,
                thumbnail: `https://i.ytimg.com/vi/${r.data.vid}/0.jpg`,
                durationNumber: r.data.t
            })
            axios({
                url: "https://yt1s.com/api/ajaxConvert/convert",
                method: "post",
                data: new URLSearchParams(Object.entries({
                    vid: r.data.vid,
                    k: r.data.links.mp3['mp3128'].k
                })),
                headers: {
                    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'
                }
            }).then(x => {
                myA.push({
                    dlink: x.data.dlink
                })
                resolve(myA)
            }).catch(e => {
                return false;
            })
        }).catch(e => {
            return false;
        })
    })
}

function ytdlmp4(url) {
    return new Promise((resolve, reject) => {
        let myA = [];
        axios({
            url: "https://yt1s.com/api/ajaxSearch/index",
            method: "POST",
            data: new URLSearchParams(Object.entries({
                q: url,
                vt: 'home'
            })),
            headers: {
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'
            }
        }).then(r => {
            myA.push({
                title: r.data.title,
                filesize: r.data.links.mp4['135'].size,
                qualityType: r.data.links.mp4['135'].q,
                thumbnail: `https://i.ytimg.com/vi/${r.data.vid}/0.jpg`,
                durationNumber: r.data.t
            })
            axios({
                url: "https://yt1s.com/api/ajaxConvert/convert",
                method: "post",
                data: new URLSearchParams(Object.entries({
                    vid: r.data.vid,
                    k: r.data.links.mp4['135'].k
                })),
                headers: {
                    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'
                }
            }).then(x => {
                myA.push({
                    dlink: x.data.dlink
                })
                resolve(myA)
            }).catch(e => {
                return false;
            })
        }).catch(e => {
            return false;
        })
    })
}

module.exports.ytdlmp3 = ytdlmp3
module.exports.ytdlmp4 = ytdlmp4