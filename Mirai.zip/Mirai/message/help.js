exports.menu = (prefix, pendaftar, runtime, pushname, isOwner, isPremium, sisalimit, limitCount, glimit, gcount, expired, tanggal, jam, i, mode, _katabijak, botName) => {
    return `「 *${botName}* 」

• *Lib:* Stable
• *Mode:* ${mode.toUpperCase()}
• *Prefix:* ${prefix}
• *Total Pengguna:* ${pendaftar.length}
• *Date:* ${tanggal}
• *Time:* ${jam}
• *Runtime:* ${runtime}

_${_katabijak.katabijak}_

「 *USER-INFO* 」

• *Name:* ${pushname}
• *Status:* ${isOwner ? 'OWNER' : isPremium ? 'Premium' : 'Gratisan'}
• *Limit:* ${isPremium ? 'Unlimited' : `${sisalimit}/${limitCount}`}
• *Limit Game:* ${isOwner ? 'Unlimited' : `${glimit}/${gcount}`}
• *Expired Prem:* ${isOwner ? '-' : isPremium ? expired : 'Not Premium'}

*INFO*
• cekprefix
• ${prefix}listgrup
• ${prefix}update
• ${prefix}stats
• ${prefix}limit
• ${prefix}balance
• ${prefix}runtime
• ${prefix}ping
• ${prefix}owner
• ${prefix}info

*MULTI-SESSION*
• ${prefix}jadibot
• ${prefix}stopjadibot
• ${prefix}getcode
• ${prefix}listbot

*STICKER*
• ${prefix}esticker *type* *emoji*
• ${prefix}sticker
• ${prefix}swm
• ${prefix}take
• ${prefix}toimg

*DOWNLOADER*
• ${prefix}ytmp3 *url*
• ${prefix}ytmp4 *url*
• ${prefix}tiktok-dl *url*
• ${prefix}twtdl *url*
• ${prefix}ytdl *url*
• ${prefix}igdl *url*
• ${prefix}fbdl *url*
• ${prefix}yts *query*
• ${prefix}play *query*
• ${prefix}playmp4 *query*

*STALKER*
• ${prefix}ghstalk *username*

*ANIME*
• ${prefix}komikuinfo *url*
• ${prefix}komiku *query*
• ${prefix}chara *query*
• ${prefix}dewabatch *query*
• ${prefix}manga *query*
• ${prefix}kemono
• ${prefix}otakulast
• ${prefix}shota
• ${prefix}neonimeongoing
• ${prefix}anoboylast
• ${prefix}waifu
• ${prefix}nekonime
• ${prefix}loli
• ${prefix}husbu
• ${prefix}shinobu
• ${prefix}megumin
• ${prefix}konachan *query*

*MEDIA*
• ${prefix}wiki *lang* *query*
• ${prefix}brainly *soal*
• ${prefix}film *query*
• ${prefix}harta *text*
• ${prefix}upload _(reply media)_
• ${prefix}fakedata
• ${prefix}githubsearch *query*
• ${prefix}ramalpasangan kamu|dia
• ${prefix}grupsearch *query*
• ${prefix}kodepost *daerah*
• ${prefix}appstore *query*
• ${prefix}bing *query*
• ${prefix}artimimpi *query*
• ${prefix}newstickerline
• ${prefix}growstock *query*
• ${prefix}happymod *query*
• ${prefix}drakor *query*
• ${prefix}amazon *query*
• ${prefix}nomorhoki *nohp*
• ${prefix}artinama *nama*
• ${prefix}googleimage *query*
• ${prefix}cuaca *daerah*
• ${prefix}heroml *query*
• ${prefix}wattpad *query*
• ${prefix}cekspek *query*
• ${prefix}pinterest *query*
• ${prefix}npmjs *query*
• ${prefix}nuliskiri *text*
• ${prefix}nuliskanan *text*
• ${prefix}foliokiri *text*
• ${prefix}foliokanan *text*

*TOOLS*
• ${prefix}sk *sk_live_xxx*
• ${prefix}proxy-check *list_proxy*
• ${prefix}iban *IBAN*
• ${prefix}proxy http|socks4|socks5
• ${prefix}bin *bin|cc*
• ${prefix}get-bin *country*
• ${prefix}shell-checker *list*
• ${prefix}cc-checker *list*
• ${prefix}fast _(reply video)_
• ${prefix}slow _(reply video)_
• ${prefix}reverse _(reply video)_
• ${prefix}readmore a|b
• ${prefix}ebase64 *text*
• ${prefix}debase64 *enc-base64*
• ${prefix}ehex *text*
• ${prefix}dehex *enc-hex*
• ${prefix}ebinary *text*
• ${prefix}debinary *enc-binary*
• ${prefix}dork *dork?*
• ${prefix}ipgeolocation *ip*
• ${prefix}tinyurl *url*
• ${prefix}translate

*BAILEYS*
• ${prefix}inspect *url*
• ${prefix}searchmsg *query*
• ${prefix}tagme
• ${prefix}kontak nomor|nama
• ${prefix}hidetag
• ${prefix}getpp @tag atau 'group'

*SEWA*
• ${prefix}sewa
• ${prefix}sewa batal
• ${prefix}addsewa link waktu
• ${prefix}delsewa idgroup

*PREMIUM*
• ${prefix}premium
• ${prefix}premium batal
• ${prefix}addprem @tag waktu
• ${prefix}delprem @tag
• ${prefix}cekprem
• ${prefix}listprem

*BANNED*
• ${prefix}ban @tag
• ${prefix}unban @tag
• ${prefix}listban

*GAME*
• ${prefix}buylimit *jumlah*
• ${prefix}buyglimit *jumlah*
• ${prefix}tictactoe *@tag*
• ${prefix}delttt
• ${prefix}tebakgambar
• ${prefix}suit

*GROUP*
• ${prefix}revokelink
• ${prefix}afk
• ${prefix}infogrup
• ${prefix}chatinfo
• ${prefix}add *628xx*
• ${prefix}kick *@tag*
• ${prefix}promote *@tag*
• ${prefix}demote *@tag*
• ${prefix}linkgc
• ${prefix}leave
• ${prefix}setdesc
• ${prefix}setgrupname
• ${prefix}setppgrup
• ${prefix}group
• ${prefix}join
• ${prefix}tagall
• ${prefix}mute
• ${prefix}unmute

*SYSTEM*
• ${prefix}correct *on|off*
• ${prefix}antilink *on|off*
• ${prefix}welcome *on|off*
• ${prefix}left *on|off*
• ${prefix}antibadword *on|off*
• ${prefix}listbadword
• ${prefix}addbadword *any*
• ${prefix}delbadword *any*

*OWNER*
• >
• $
• =>
• #
• ${prefix}self
• ${prefix}acc *nomor*
• ${prefix}accept *nomor*
• ${prefix}public
• ${prefix}setprefix
• ${prefix}resetlimit
• ${prefix}bc
• ${prefix}sendbug
• ${prefix}antidelete
• ${prefix}clearall
• ${prefix}addchagelog
• ${prefix}exif nama|author`
}