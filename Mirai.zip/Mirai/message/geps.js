"use strict";
const {
    WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange,
    MessageOptions,
    WALocationMessage,
    WA_MESSAGE_STUB_TYPES,
    ReconnectMode,
    ProxyAgent,
    waChatKey,
    mentionedJid,
    WA_DEFAULT_EPHEMERAL
} = require("@adiwajshing/baileys");
const fs = require("fs");
const moment = require("moment-timezone");
const {
    exec,
    spawn
} = require("child_process");
const qs = require('qs');
const qrcode = require("qrcode");
const ffmpeg = require("fluent-ffmpeg");
const request = require('request');
const fetch = require("node-fetch");
const ms = require("parse-ms");
const toMs = require("ms");
const axios = require("axios");
const speed = require("performance-now");
const proxyChecker = require('proxy-checker');
const yts = require("yt-search");
const translate = require("@vitalets/google-translate-api");
const {
    default: Axios
} = require("axios");
const util = require("util");
const os = require("os");
const gis = require('g-i-s');
const weather = require('weather-js');
const amazonScraper = require('amazon-buddy');
const gplay = require('google-play-scraper');
const ip2location = require('ip-to-location');
const bing = require("bing-scraper");
const google = require('google-it');
const anonfile = require('anonfile-lib');
const cheerio = require('cheerio');
const pty = require('node-pty');
const brainly = require("brainly-wrapper");

// stickwm
const Exif = require('../lib/exif')
const exif = new Exif()

const {
    addReqtiktok,
    checkReqtiktok,
    deleteReqtiktok,
    getReqtiktok
} = require('../lib/ttdl_button');
const {
    addReq,
    checkReq,
    deleteReq,
    getReq
} = require('../lib/ytdl_button');
const {
    color,
    bgcolor
} = require("../lib/color");
const msgFilter = require("../lib/antispam");
const {
    serialize,
    getBuffer,
    getRandom,
    getGroupAdmins,
    runtime
} = require("../lib/myfunc");
const {
    isLimit,
    limitAdd,
    getLimit,
    giveLimit,
    addBalance,
    kurangBalance,
    getBalance,
    isGame,
    gameAdd,
    givegame,
    cekGLimit
} = require("../lib/limit");
const _prem = require("../lib/premium");
const _sewa = require("../lib/sewa");
const afk = require("../lib/afk");
const {
    addBanned,
    unBanned,
    BannedExpired,
    cekBannedUser
} = require("../lib/banned");
const {
    isTicTacToe,
    getPosTic
} = require("../lib/tictactoe");
const tictac = require("../lib/tictac");
const {
    yta,
    ytv
} = require("../lib/ytdl");
const {
    fbdl
} = require("../lib/fbdl");
const {
    tebak_gambar
} = require('../lib/tebakgambar');
const game = require("../lib/game");
const {
    searchkomiku,
    komiku
} = require("../lib/komiku")
const {
    addBadword,
    delBadword,
    isKasar,
    addCountKasar,
    isCountKasar,
    delCountKasar
} = require("../lib/badword");
const {
    getEmoji
} = require("../lib/emoji");
const {
    getLirik
} = require("../lib/lirik");
const {
    ytdlmp3,
    ytdlmp4
} = require('../scrape/ytdl');

// Database
let pendaftar = JSON.parse(fs.readFileSync('./database/user.json'));
let setting = JSON.parse(fs.readFileSync('./config.json'));
let limit = JSON.parse(fs.readFileSync('./database/limit.json'));
let glimit = JSON.parse(fs.readFileSync('./database/glimit.json'));
let mess = JSON.parse(fs.readFileSync('./message/mess.json'));
let premium = JSON.parse(fs.readFileSync('./database/premium.json'));
let sewa = JSON.parse(fs.readFileSync('./database/sewa.json'));
let ban = JSON.parse(fs.readFileSync('./database/ban.json'));
let antilink = JSON.parse(fs.readFileSync('./database/antilink.json'));
let badword = JSON.parse(fs.readFileSync('./database/badword.json'));
let grupbadword = JSON.parse(fs.readFileSync('./database/grupbadword.json'));
let senbadword = JSON.parse(fs.readFileSync('./database/senbadword.json'));
let mute = JSON.parse(fs.readFileSync('./database/mute.json'));
let changelog = JSON.parse(fs.readFileSync('./database/changelog.json'));
let balance = JSON.parse(fs.readFileSync('./database/balance.json'));

// Hit
global.hit = {}

// Game
let tictactoe = [];
let tebakgambar = [];

// Jadi bot

if (global.conns instanceof Array) console.log()
else global.conns = []

let {
    ownerNumber,
    limitCount,
    gamewaktu,
    gopay,
    botName
} = setting

moment.tz.setDefault("Asia/Jakarta").locale("id");

module.exports = async (geps, msg, blocked, _afk, welcome, left, reqDB, reqDB_tiktok, setting_path) => {
    try {
        const {
            menu,
            newMenu,
            stickerMenu
        } = require("./help");
        const {
            type,
            quotedMsg,
            isGroup,
            isQuotedMsg,
            mentioned,
            sender,
            from,
            fromMe,
            pushname,
            chats,
            isBaileys
        } = msg
        if (isBaileys) return
        const {
            text,
            extendedText,
            contact,
            location,
            liveLocation,
            image,
            video,
            sticker,
            document,
            audio,
            product
        } = MessageType
        const args = chats.split(' ')
        const command = chats.toLowerCase().split(' ')[0] || ''

        if (geps.multi) {
            var prefix = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(command) ? command.match(/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : '#'
        } else {
            if (geps.nopref) {
                prefix = ''
            } else {
                prefix = geps.prefa
            }
        }

        const isCmd = command.startsWith(prefix)
        const q = chats.slice(command.length + 1, chats.length)
        const body = chats.startsWith(prefix) ? chats : ''

        const botNumber = geps.user.jid
        const groupMetadata = isGroup ? await geps.groupMetadata(from) : ''
        const groupName = isGroup ? groupMetadata.subject : ''
        const groupId = isGroup ? groupMetadata.jid : ''
        const groupMembers = isGroup ? groupMetadata.participants : ''
        const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
        const isGroupAdmins = groupAdmins.includes(sender) || false

        const isOwner = ownerNumber.includes(sender)
        const isPremium = isOwner ? true : _prem.checkPremiumUser(sender, premium)
        const isSewa = _sewa.checkSewaGroup(from, sewa)
        const isBan = cekBannedUser(sender, ban)
        const isAfkOn = afk.checkAfkUser(sender, _afk)
        const isAntiLink = isGroup ? antilink.includes(from) : false
        const isWelcome = isGroup ? welcome.includes(from) : false
        const isLeft = isGroup ? left.includes(from) : false
        const isUser = pendaftar.includes(sender)
        const isBadword = isGroup ? grupbadword.includes(from) : false
        const isMuted = isGroup ? mute.includes(from) : false

        const gcounti = setting.gcount
        const gcount = isPremium ? gcounti.prem : gcounti.user

        const tanggal = moment().format("ll")
        const jam = moment().format("HH:mm:ss z")

        const isUrl = (url) => {
            return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
        }

        function monospace(string) {
            return '```' + string + '```'
        }

        function jsonformat(string) {
            return JSON.stringify(string, null, 2)
        }

        function randomNomor(angka) {
            return Math.floor(Math.random() * angka) + 1
        }
        const nebal = (angka) => {
            return Math.floor(angka)
        }
        const reply = (teks) => {
            return geps.sendMessage(from, teks, text, {
                quoted: msg
            })
        }
        const sendMess = (hehe, teks) => {
            return geps.sendMessage(hehe, teks, text)
        }
        const mentions = (teks, memberr, id) => {
            let ai = (id == null || id == undefined || id == false) ? geps.sendMessage(from, teks.trim(), extendedText, {
                contextInfo: {
                    "mentionedJid": memberr
                }
            }) : geps.sendMessage(from, teks.trim(), extendedText, {
                quoted: msg,
                contextInfo: {
                    "mentionedJid": memberr
                }
            })
            return ai
        }
        async function sendFileFromUrl(from, url, caption, msg, men) {
            let damta = await getBuffer(url)
            let res = await axios.head(url)
            let mime = res.headers['content-type'] ? res.headers['content-type'] : "image/gif"
            let type = mime.split("/")[0] + "Message"
            if (mime === "image/gif") {
                type = MessageType.video
                mime = Mimetype.gif
            }
            if (mime === "application/pdf") {
                type = MessageType.document
                mime = Mimetype.pdf
            }
            if (mime.split("/")[0] === "audio") {
                mime = Mimetype.mp4Audio
            }
            return geps.sendMessage(from, damta, type, {
                caption: caption,
                quoted: msg,
                mimetype: mime,
                contextInfo: {
                    "mentionedJid": men ? men : []
                }
            })
        }

        function toRupiah(angka) {
            var balancenyeini = '';
            var angkarev = angka.toString().split('').reverse().join('');
            for (var i = 0; i < angkarev.length; i++)
                if (i % 3 == 0) balancenyeini += angkarev.substr(i, 3) + '.';
            return '' + balancenyeini.split('', balancenyeini.length - 1).reverse().join('');
        }

        // SPAM
        const spampm = () => {
            console.log(color('[SPAM]', 'red'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`))
            msgFilter.addSpam(sender, geps.spam)
            if (msgFilter.isSpam(sender, geps.spam)) {
                addBanned(sender, '30m', ban)
                reply(`Kamu melakukan spam\nKamu akan diban selama 30menit`)
            } else {
                reply(`Hai\nKamu terdeteksi menggunakan command tanpa jeda\nHarap tunggu 5 detik`)
            }
        }
        const spamgr = () => {
            console.log(color('[SPAM]', 'red'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
            msgFilter.addSpam(sender, geps.spam)
            if (msgFilter.isSpam(sender, geps.spam)) {
                addBanned(sender, '30m', ban)
                reply(`Kamu melakukan spam\nKamu akan diban selama 30menit`)
            } else {
                reply(`Hai\nKamu terdeteksi menggunakan command tanpa jeda\nHarap tunggu 5 detik`)
            }
        }

        const isImage = (type === 'imageMessage')
        const isAudio = (type === 'audioMessage')
        const isVideo = (type === 'videoMessage')
        const isSticker = (type == 'stickerMessage')
        const isDocument = (type == 'documentMessage')
        const isMedia = isImage || isVideo || isSticker || (type == 'audioMessage') || (type == 'documentMessage')
        const isQuotedDocument = isQuotedMsg ? (quotedMsg.type === 'documentMessage') ? true : false : false
        const isQuotedImage = isQuotedMsg ? (quotedMsg.type === 'imageMessage') ? true : false : false
        const isQuotedAudio = isQuotedMsg ? (quotedMsg.type === 'audioMessage') ? true : false : false
        const isQuotedVideo = isQuotedMsg ? (quotedMsg.type === 'videoMessage') ? true : false : false
        const isQuotedSticker = isQuotedMsg ? (quotedMsg.type === 'stickerMessage') ? true : false : false
        const isButton = (type == 'buttonsResponseMessage') ? msg.message.buttonsResponseMessage.selectedDisplayText : ''
        const isListMessage = (type == 'listResponseMessage') ? msg.message.listResponseMessage.title : ''

        //  Anti spam
        msgFilter.ResetSpam(geps.spam)

        // TicTacToe
        if (isTicTacToe(from, tictactoe) && !isMuted) {
            tictac(geps, chats, prefix, tictactoe, from, sender, reply, mentions, addBalance, balance)
        }

        // Mode
        if (geps.mode === 'self') {
            if (!fromMe) return
        }

        // Anti link
        if (isGroup && isAntiLink && !isOwner && !isGroupAdmins && isBotGroupAdmins) {
            if (chats.match(/(https:\/\/chat.whatsapp.com)/gi)) {
                reply(`*「 GROUP LINK DETECTOR 」*\n\nSepertinya kamu mengirimkan link grup, maaf kamu akan di kick`)
                geps.groupRemove(from, [sender])
            }
        }

        // Badword
        if (isGroup && isBadword && !isOwner && !isGroupAdmins) {
            for (let kasar of badword) {
                if (chats.toLowerCase().includes(kasar)) {
                    if (isCountKasar(sender, senbadword)) {
                        if (!isBotGroupAdmins) return reply(`Kamu beruntung karena bot bukan admin`)
                        reply(`*「 ANTI BADWORD 」*\n\nSepertinya kamu sudah berkata kasar lebih dari 5x, maaf kamu akan di kick`)
                        geps.groupRemove(from, [sender])
                        delCountKasar(sender, senbadword)
                    } else {
                        addCountKasar(sender, senbadword)
                        reply(`Kamu terdeteksi berkata kasar\nJangan ulangi lagi atau kamu akan dikick`)
                    }
                }
            }
        }

        // Banned
        if (isBan) return
        BannedExpired(ban)

        // MUTE
        if (isMuted) {
            if (!isGroupAdmins && !isOwner) return
            if (chats.toLowerCase().startsWith(prefix + 'unmute')) {
                let anu = mute.indexOf(from)
                mute.splice(anu, 1)
                fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
                reply(`Bot telah diunmute di group ini`)
            }
        }

        // GAME
        game.cekWaktuTG(geps, tebakgambar)

        // GAME 
        if (game.isTebakGambar(from, tebakgambar) && isUser) {
            if (chats.toLowerCase().includes(game.getJawabanTG(from, tebakgambar))) {
                var htgm = randomNomor(100)
                addBalance(sender, htgm, balance)
                await reply(`*Selamat jawaban kamu benar*\n*Jawaban :* ${game.getJawabanTG(from, tebakgambar)}\n*Hadiah :* $${htgm}\n\nIngin bermain lagi? kirim *${prefix}tebakgambar*`)
                tebakgambar.splice(game.getTGPosi(from, tebakgambar), 1)
            }
        }

        // Premium
        _prem.expiredCheck(premium)

        // Auto Regist
        if (isCmd && !isUser) {
            pendaftar.push(sender)
            fs.writeFileSync('./database/user.json', JSON.stringify(pendaftar))
        }

        // ANTI SPAM
        if (isCmd && msgFilter.isFiltered(sender) && !isGroup) return spampm()
        if (isCmd && msgFilter.isFiltered(sender) && isGroup) return spamgr()
        if (isCmd && !isOwner && !isPremium) msgFilter.addFilter(sender)

        // Premium Otomatis
        const PremiumPath = './database/premium'
        if (fs.existsSync(PremiumPath + '/' + sender + '.json')) {
            if (!chats.startsWith(prefix) && !msg.key.fromMe && global.geps.user.jid === geps.user.jid) {
                let data_buyprem = JSON.parse(fs.readFileSync(PremiumPath + '/' + sender + '.json'))
                if (data_buyprem.session == 'name') {
                    if (chats.length < 1) return reply('Masukan nama dengan benar')
                    if (chats.length > 60) return reply('Maaf kak nama yang telah dimasukan lebih dari 60 karakter')
                    data_buyprem.data.name = chats
                    data_buyprem.session = 'month'
                    fs.writeFileSync(PremiumPath + '/' + sender + '.json', JSON.stringify(data_buyprem, null, 3))
                    geps.sendMessage(from, `Oke Dengan kak ${chats}, mau berapa bulan untuk jadi premium user? 

${monospace(`Rp10.000,- / bulan

Untuk lebih jelasnya atau apabila ada kendala silahkan hubungi : @${ownerNumber.replace(/@.+/g, '')}`)}`, MessageType.text, {
                        quoted: msg,
                        contextInfo: {
                            mentionedJid: [ownerNumber]
                        }
                    })
                } else if (data_buyprem.session == 'month') {
                    if (isNaN(chats)) return reply(`Masukan hanya angka ya :)`)
                    if (Number(chats) > 12) return reply(`Maaf kak bulan tidak lebih dari 12 :(`)
                    data_buyprem.data.month = Number(chats)
                    data_buyprem.session = 'phone'
                    fs.writeFileSync(PremiumPath + '/' + sender + '.json', JSON.stringify(data_buyprem, null, 3))
                    reply(`Mohon masukan nomer telepon untuk melanjutkan pembayaran 📲\n\n_Contoh : 089523258649_`)
                } else if (data_buyprem.session == 'phone') {
                    if (isNaN(chats)) return reply(`Masukan hanya angka ya :)`)
                    if (chats.length > 40) return reply(`Sepertinya tidak ada nomer telepon lebih dari 40 kata hmm..`)
                    data_buyprem.data.phone = chats.toLowerCase()
                    data_buyprem.session = 'confirm'
                    fs.writeFileSync(PremiumPath + '/' + sender + '.json', JSON.stringify(data_buyprem, null, 3))
                    reply(`「 *PREMIUM-USER* 」

${monospace(`Nama       : ${data_buyprem.data.name}
Nomor      : ${data_buyprem.number.replace(/@.+/g, '')}
Waktu Sewa : ${data_buyprem.data.month} Bulan
ID         : ${data_buyprem.ID}`)}

Apakah data tersebut benar? akan gagal apabila terdapat kesalahan input.

\`\`\`ketik Y untuk melanjutkan, N untuk mengulangi inputan dan ${prefix}buyprem batal untuk membatalkan pesanan\`\`\``)
                } else if (data_buyprem.session == 'confirm') {
                    if (chats.toLowerCase() == 'y') {
                        const totalBayars = data_buyprem.data.month * 10000
                        reply(`「 *ON-PROSES* 」

${monospace(`Nama        : ${data_buyprem.data.name}
Nomor       : ${data_buyprem.number.replace(/@.+/g, '')}
Waktu Sewa  : ${data_buyprem.data.month} Bulan
Total Harga : Rp. ${toRupiah(totalBayars)}
ID          : ${data_buyprem.ID}
Status      : Pending
Gopay       : ${gopay}`)}

_Silahkan transfer ke nomer gopay yang sudah tertera dan Mohon tunggu konfirmasi dari owner 1x24jam, Jika ingin batal ketik ${prefix}pbuyprem batal_`).then(() => {
                            sendMess(ownerNumber, `「 *PESANAN-PREMIUM* 」

${monospace(`Nama        : ${data_buyprem.data.name}
Nomor       : wa.me/${data_buyprem.number.replace(/@.+/g, '')}
Waktu Sewa  : ${data_buyprem.data.month} Bulan
Total Harga : Rp. ${toRupiah(totalBayars)}
ID          : ${data_buyprem.ID}
Status      : Pending`)}

Jika saldo Gopay sudah masuk, Silahkan ketik !accept ${data_buyprem.number.replace(/@.+/g, '')}`)
                        })
                    } else if (chats.toLowerCase() == 'n') {
                        let pathSewanya = './database/premium'
                        let dataID_sewa = JSON.parse(fs.readFileSync(pathSewanya + '/ids-match.json'));
                        let indexData_sewa = dataID_sewa.findIndex(r => r['number'] == data_buyprem.number)
                        dataID_sewa.splice(indexData_sewa, 1)
                        fs.writeFileSync(pathSewanya + '/ids-match.json', JSON.stringify(dataID_sewa, null, 3))
                        fs.unlinkSync(pathSewanya + '/' + data_buyprem.number + '.json')
                        reply(`Baik kak, Pembayaran dibatalkan 😊`)
                    }
                }
            }
        }

        // Sewa
        _sewa.expiredCheck(global.geps, sewa)

        // Sewa Otomatis
        const sewaPath = './database/sewa'
        if (fs.existsSync(sewaPath + '/' + sender + '.json')) {
            if (!isGroup && !chats.startsWith(prefix) && !msg.key.fromMe && global.geps.user.jid === geps.user.jid) {
                let data_sewagc = JSON.parse(fs.readFileSync(sewaPath + '/' + sender + '.json'))
                if (data_sewagc.session == 'name') {
                    if (chats.length < 1) return reply('Masukan nama dengan benar')
                    if (chats.length > 60) return reply('Maaf kak nama yang telah dimasukan lebih dari 60 karakter')
                    data_sewagc.data.name = chats
                    data_sewagc.session = 'month'
                    fs.writeFileSync(sewaPath + '/' + sender + '.json', JSON.stringify(data_sewagc, null, 3))
                    geps.sendMessage(from, `Oke Dengan kak ${chats}, berapa bulan untuk sewa group? 

${monospace(`Rp10.000,- / bulan

Untuk lebih jelasnya atau apabila ada kendala silahkan hubungi : @${ownerNumber.replace(/@.+/g, '')}`)}`, MessageType.text, {
                        quoted: msg,
                        contextInfo: {
                            mentionedJid: [ownerNumber]
                        }
                    })
                } else if (data_sewagc.session == 'month') {
                    if (isNaN(chats)) return reply(`Masukan hanya angka ya :)`)
                    if (Number(chats) > 12) return reply(`Maaf kak bulan tidak lebih dari 12 :(`)
                    data_sewagc.data.month = Number(chats)
                    data_sewagc.session = 'phone'
                    fs.writeFileSync(sewaPath + '/' + sender + '.json', JSON.stringify(data_sewagc, null, 3))
                    reply(`Mohon masukan nomer telepon untuk melanjutkan pembayaran 📲\n\n_Contoh : 089523258649_`)
                } else if (data_sewagc.session == 'phone') {
                    if (isNaN(chats)) return reply(`Masukan hanya angka ya :)`)
                    if (chats.length > 40) return reply(`Sepertinya tidak ada nomer telepon lebih dari 40 kata hmm..`)
                    data_sewagc.data.phone = chats.toLowerCase()
                    data_sewagc.session = 'link'
                    fs.writeFileSync(sewaPath + '/' + sender + '.json', JSON.stringify(data_sewagc, null, 3))
                    reply(`Kirimkan link group yang mau dimasukin`)
                } else if (data_sewagc.session == 'link') {
                    if (!chats.match(/(https:\/\/chat.whatsapp.com)/gi)) return reply(`Harap masukkan link group dengan benar`)
                    let ceke = await geps.cekInviteCode(chats.replace('https://chat.whatsapp.com/', ''))
                    if (ceke.status !== 200) return reply(`Harap berikan link group yang valid`)
                    data_sewagc.data.grouplink = chats
                    data_sewagc.session = 'confirm'
                    fs.writeFileSync(sewaPath + '/' + sender + '.json', JSON.stringify(data_sewagc, null, 3))
                    reply(`「 *SEWA-GROUP* 」

${monospace(`Nama       : ${data_sewagc.data.name}
Nomor      : ${data_sewagc.number.replace(/@.+/g, '')}
Waktu Sewa : ${data_sewagc.data.month} Bulan
ID         : ${data_sewagc.ID}
Link Group : ${data_sewagc.data.grouplink}`)}

Apakah data tersebut benar? akan gagal apabila terdapat kesalahan input.

\`\`\`ketik Y untuk melanjutkan, N untuk mengulangi inputan dan ${prefix}sewa batal untuk membatalkan pesanan\`\`\``)
                } else if (data_sewagc.session == 'confirm') {
                    if (chats.toLowerCase() == 'y') {
                        const totalBayar = data_sewagc.data.month * 10000
                        reply(`「 *ON-PROSES* 」

${monospace(`Nama        : ${data_sewagc.data.name}
Nomor       : ${data_sewagc.number.replace(/@.+/g, '')}
Waktu Sewa  : ${data_sewagc.data.month} Bulan
Total Harga : Rp. ${toRupiah(totalBayar)}
ID          : ${data_sewagc.ID}
Status      : Pending
Gopay       : ${gopay}
Link Group  : ${data_sewagc.data.grouplink}`)}

_Silahkan transfer ke nomer gopay yang sudah tertera dan Mohon tunggu konfirmasi dari owner 1x24jam, Jika ingin batal ketik ${prefix}sewa batal_`).then(() => {
                            sendMess(ownerNumber, `「 *PESANAN-SEWA-GROUP* 」

${monospace(`Nama        : ${data_sewagc.data.name}
Nomor       : wa.me/${data_sewagc.number.replace(/@.+/g, '')}
Waktu Sewa  : ${data_sewagc.data.month} Bulan
Total Harga : Rp. ${toRupiah(totalBayar)}
ID          : ${data_sewagc.ID}
Status      : Pending
Link Group  : ${data_sewagc.data.grouplink}`)}

Jika saldo Gopay sudah masuk, Silahkan ketik !acc ${data_sewagc.number.replace(/@.+/g, '')}`)
                        })
                    } else if (chats.toLowerCase() == 'n') {
                        let pathSewanya = './database/sewa'
                        let dataID_sewa = JSON.parse(fs.readFileSync(pathSewanya + '/ids-match.json'));
                        let indexData_sewa = dataID_sewa.findIndex(r => r['number'] == data_sewagc.number)
                        dataID_sewa.splice(indexData_sewa, 1)
                        fs.writeFileSync(pathSewanya + '/ids-match.json', JSON.stringify(dataID_sewa, null, 3))
                        fs.unlinkSync(pathSewanya + '/' + data_sewagc.number + '.json')
                        reply(`Baik kak, Pembayaran dibatalkan 😊`)
                    }
                }
            }
        }

        // AFK
        if (isGroup) {
            if (mentioned.length !== 0) {
                for (let ment of mentioned) {
                    if (afk.checkAfkUser(ment, _afk)) {
                        const getId = afk.getAfkId(ment, _afk)
                        const getReason = afk.getAfkReason(getId, _afk)
                        const getTime = Date.now() - afk.getAfkTime(getId, _afk)
                        const heheh = ms(getTime)
                        await mentions(`@${ment.split('@')[0]} sedang afk\n\n*Alasan :* ${getReason}\n*Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu`, [ment], true)
                        sendMess(ment, `Ada yang mencari anda saat anda offline\n\nNama : ${pushname}\nNomor : wa.me/${sender.split("@")[0]}\nIn Group : ${groupName}\nPesan : ${chats}`)
                    }
                    if (ment === ownerNumber) {
                        reply('Apa si tag tag owner ku')
                    }
                    if (ment === geps.user.jid) {
                        reply(`Ya ada apa ${pushname}, silahkan kirim ${prefix}menu`)
                    }
                }
            }
            if (afk.checkAfkUser(sender, _afk)) {
                _afk.splice(afk.getAfkPosition(sender, _afk), 1)
                fs.writeFileSync('./database/afk.json', JSON.stringify(_afk))
                await mentions(`@${sender.split('@')[0]} telah kembali`, [sender], true)
            }
        }

        // Auto Read
        geps.chatRead(from, "read")

        // CMD
        if (isCmd && !isGroup) {
            addBalance(sender, parseInt(randomNomor(20)), balance)
            console.log(color('[CMD]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        }
        if (isCmd && isGroup) {
            addBalance(sender, parseInt(randomNomor(20)), balance)
            console.log(color('[CMD]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
        }

        const spam = {
            chat_id: {
                spam: 0,
                time: 0
            }
        }

        const user = {
            chat_id: {
                silent: false,
                text: ""
            }
        }

        function isSpam(chat_id) {
            if (spam[chat_id]) {
                if (spam[chat_id].spam > 20) {
                    spam[chat_id] = {
                        spam: 0,
                        time: new Date()
                    }
                    return true
                }
                if (new Date() - spam[chat_id].time < 500) { // 500 ms = 0.5 second
                    spam[chat_id].time = new Date()
                    spam[chat_id].spam += 1
                } else {
                    spam[chat_id].time = new Date()
                    spam[chat_id].spam = 0
                }
            } else {
                spam[chat_id] = {
                    spam: 0,
                    time: new Date()
                }
            }
            return false
        }

        function parse(text_) {
            while (RegExp(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/).exec(text_) || /\r/.exec('text')) {
                text_ = text_.replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/, '').replace('\r', '')
            }
            return text_
        }

        async function addPty({
            pty,
            user_id
        }) {
            user[user_id] = {
                silent: false,
                text: "",
                pty: pty
            }
            pty.on('exit', async (x) => {
                delete user[user_id]
                await geps.sendMessage(user_id, 'Session Terbunuh', text)
            })
            pty.on('data', async (data) => {
                if (!user[user_id].silent) {
                    if (!isSpam(user_id)) {
                        console.log(user_id)
                        //console.log(JSON.stringify({data:data.replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/, '')}))
                        var par = parse(data)
                        par ? await geps.sendMessage(user_id, par, text) : false
                    } else {
                        pty.kill()
                        delete user[user_id]
                        await geps.sendMessage(user_id, 'Session Terbunuh', text)
                    }
                } else {
                    user[user_id].text += parse(data)
                }
            })
        }
        async function sendWrite(text, from) {
            if (user[from]) {
                user[from].pty.write(`${text}\n`)
            } else {
                await addPty({
                    pty: pty.spawn('bash'),
                    user_id: from
                }).then((x) => x)
                await sendWrite(text, from).then((x) => x)
            }
        }
        if (isOwner) {
            if (chats.startsWith("> ")) {
                console.log(color('[EVAL]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
                try {
                    let evaled = await eval(chats.slice(2))
                    if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                    reply(`${evaled}`)
                } catch (err) {
                    reply(`${err}`)
                }
            } else if (chats.startsWith("# ")) {
                console.log(color('[EXEC]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
                await sendWrite(chats.slice(2), from).then((x) => x.trim());
            } else if (chats.startsWith('=> ')) {
                console.log(color('[EVAL]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
                try {
                    let evaled = await eval(`;(async () => { ${chats.slice(3)} })()`);
                    if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                    reply(`${evaled}`)
                } catch (err) {
                    reply(err)
                }
            } else if (chats.startsWith("$ ")) {
                console.log(color('[EXEC]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
                exec(chats.slice(2), (err, stdout) => {
                    if (err) return reply(`${err}`)
                    if (stdout) reply(`${stdout}`)
                })
            }
        }

        // RANDOM
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`
        }

        async function sendStickerFromUrl(to, url) {
            var names = Date.now() / 10000;
            var download = function(uri, filename, callback) {
                request.head(uri, function(err, res, body) {
                    request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                });
            };
            download(url, '../sticker' + names + '.png', async function() {
                let filess = '../sticker' + names + '.png'
                let asw = '../sticker' + names + '.webp'
                exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                    let media = fs.readFileSync(asw)
                    geps.sendMessage(to, media, MessageType.sticker, {
                        quoted: msg
                    })
                    fs.unlinkSync(filess)
                    fs.unlinkSync(asw)
                });
            });
        }

        // Auto-Correct Command
        const autocorrect = require('autocorrect')({
            dictionary: './menu.txt'
        });
        if (autocorrect(command.slice(1)) && isCmd && setting_path.autoCorrect === true) {
            reply(`Mungkin yang kamu maksud ${prefix}${autocorrect(command.slice(1))}`)
        }

        const cekNumber = (num, arr) => {
            let status = false
            Object.keys(arr).forEach((i) => {
                if (arr[i] === num) {
                    status = true
                }
            })
            return status
        }

        switch (command) {
            // Masih Project Sloerrr, Jgn dipake dlu
            // case prefix + 'getsms':
            //     if (isNaN(args[1])) return reply(`Gunakan dengan cara ${command} *nomer*\n\n_Contoh_\n\n${command} 16476960707\n\nLihat list nomer yang tersedia dengan cara ketik ${prefix}listnumbersms`)
            //     if (args[1].match(/^\d*(\.\d+)?$/) === false) return reply(`Gunakan dengan cara ${command} *nomer*\n\n_Contoh_\n\n${command} 16476960707\n\nLihat list nomer yang tersedia dengan cara ketik ${prefix}listnumbersms`)

            //     axios.get('https://getfreesmsnumber.com/').then(r => {
            //         if (r.status === 200) {
            //             const $ = cheerio.load(r.data);
            //             let myA = [];
            //             $('div.col-12.col-lg-3.col-md-4.col-sm-6.p-2').each((i, el) => {
            //                 const nomer_sms = $(el).find('div.card > div.card-body.text-center > div.card-text > p.p-0.m-0.font-weight-bold').text().trim();
            //                 myA.push(nomer_sms)
            //             })
            //             if (cekNumber('+' + args[1], myA) === true) {
            //                 axios.get(`https://getfreesmsnumber.com/virtual-phone/p-${args[1]}`, {
            //                     headers: {
            //                         'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:93.0) Gecko/20100101 Firefox/93.0',
            //                         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            //                         'Accept-Language': 'en-US,en;q=0.5',
            //                         'Connection': 'keep-alive',
            //                         'Referer': 'https://getfreesmsnumber.com/',
            //                         'Cookie': 'XSRF-TOKEN=eyJpdiI6Imh1WnpCMnFJT010ZXpXMGxPTVNJMXc9PSIsInZhbHVlIjoibmd1UVFGK1g1blROQnBRRC9Ea2kyNTg2aEl2dG5FSkpPVnFSaGZjY2Ixa2x6ODRmN2p1SWo5Rk5mVytoL0xsVCIsIm1hYyI6ImY1Njc0NDgyMTBhMGEyOTgyNzI0ODY1NmY3MTgxODhiYzhhNWY4MGJjOTZlMzliYjlmNWJhOWJlYzNmZmJmZjEifQ%3D%3D; getfreesmsnumber_session=eyJpdiI6Imt3d3h3M1crQlRvRDZqSThxTVQweGc9PSIsInZhbHVlIjoiRFFYUlBFYXpNcldlTks1OGo0ZnpEMDQvWEZDeEd1d0NlS3BaUFZaNzVtS2tyNW1vdFBXelE3eDRvMkJoQ2hCMiIsIm1hYyI6ImYxYjJlOGNhMTY4MDQyNThkMWE0Y2Q5MmMzZTNiMjg5MjYxNWZhNTM2NWVmOTNmMGNlNGIzMzAyZWQ0NjIyNTcifQ%3D%3D; _ga=GA1.2.24510703.1634103277; _gid=GA1.2.1766232496.1634103277; __gads=ID=214adac7e1fc07ab-22dc0b3f74cc0069:T=1634103306:RT=1634103306:S=ALNI_Mb8-2pkyINCVqGFfSEc2Hblxl66PA; fpestid=lkqWX_MYOPHZn6a-S5HYqFB81AeOpkXtQn-JnEcoNHS8a81_UxtqJZaZusHyxRI8f-DcIw; PHPSESSID=aa78o5mqinuac744jq0g2gjnuv; gfsno=abd49d4e9577cc2c066abdfcc8caf92c',
            //                         'Upgrade-Insecure-Requests': '1',
            //                         'Sec-Fetch-Dest': 'document',
            //                         'Sec-Fetch-Mode': 'navigate',
            //                         'Sec-Fetch-Site': 'same-origin',
            //                         'Sec-Fetch-User': '?1',
            //                         'TE': 'trailers'
            //                     }
            //                 }).then(r => {
            //                     if (r.status === 200) {
            //                         const $ = cheerio.load(r.data);
            //                         let myAS = [];
            //                         $('div.card.m-2.text-center').each((i, el) => {
            //                             const sender_msg = $(el).find('div.card-header > span.mt-0 > a').text().trim();
            //                             const msg_sms = $(el).find('div.card-body').text().replace(/\s+/g, " ")
            //                             myAS.push({
            //                                 sender_msg,
            //                                 msg_sms
            //                             })
            //                         })
            //                         let send_text_sms = `「 *FREE-SMS-NUMBER* 」\n\n`
            //                         for (let y of myAS) {
            //                             send_text_sms += `${monospace(`From : ${y.sender_msg}\nMsg  : ${y.msg_sms}\n\n`)}`
            //                         }
            //                         reply(`*${myAS.length}* Message Recv...`)
            //                         reply(send_text_sms.trim())
            //                     }
            //                 }).catch(e => {
            //                     console.log(e)
            //                 })
            //             } else {
            //                 reply(`Nomer ${args[1]} tidak ada di provider kami, jika ingin melihat list ketik ${prefix}listnumbersms`)
            //             }
            //         }
            //     }).catch(e => {
            //         console.log(e)
            //     })
            //     break
            // case prefix + 'listnumbersms':
            //     axios.get('https://getfreesmsnumber.com/').then(r => {
            //         if (r.status === 200) {
            //             const $ = cheerio.load(r.data);
            //             let myA = [];
            //             $('div.col-12.col-lg-3.col-md-4.col-sm-6.p-2').each((i, el) => {
            //                 const nomer_sms = $(el).find('div.card > div.card-body.text-center > div.card-text > p.p-0.m-0.font-weight-bold').text().trim();
            //                 const updateAt_ = $(el).find('div.card > div.card-body.text-center > div.card-text > p.p-0.m-0.small').text().trim();
            //                 myA.push({
            //                     number: nomer_sms,
            //                     updateAt: updateAt_
            //                 })
            //             })
            //             let text_send = `「 *FREE-SMS-NUMBER* 」\n\n*Total:* ${myA.length}\n\n`
            //             for (let x of myA) {
            //                 text_send += `${monospace(`Number   : ${x.number}\nUpdateAt : ${x.updateAt}\n\n`)}`
            //             }
            //             reply(mess.wait);
            //             reply(text_send.trim())
            //         }
            //     }).catch(e => {
            //         reply(mess.error.api)
            //         console.log(e)
            //     })
            //     break
            case prefix + 'sk':
                if (!args[1]) return reply(`Gunakan dengan cara ${command} sk_live_xxxx\n\n_Contoh_\n\n${command} sk_live_klNUiGIYAFGIYSA`)
                axios.get(`https://ninja-checker.herokuapp.com/skchk.php?lista=${q}`).then(r => {
                    if (r.status === 200) {
                        const $ = cheerio.load(r.data);
                        const resp_sk = $('p > b > span').text().trim();
                        if (resp_sk === '[SK LIVE]') {
                            reply(mess.wait)
                            reply(`「 *SK-CHECKER* 」
                            
${monospace(`Status    : LIVE
CheckedBy : ${botName}`)}`)
                        } else if (resp_sk === '[TEST MODE]') {
                            reply(mess.wait)
                            reply(`「 *SK-CHECKER* 」
                            
${monospace(`Status    : TEST MODE
CheckedBy : ${botName}`)}`)
                        } else if (resp_sk === '[Dead]') {
                            reply(mess.wait)
                            reply(`「 *SK-CHECKER* 」
                            
${monospace(`Status    : DEAD
CheckedBy : ${botName}`)}`)
                        } else {
                            reply(mess.wait)
                            reply(`Unknown Key:(`)
                        }
                    }
                }).catch(e => {
                    reply(`Unknown Key:(`)
                    console.log('Error: ', e)
                })
                break
            case prefix + 'proxy-checker':
            case prefix + 'proxy-check':
                if (!args[1]) return reply('Where the list proxy?, ngamtuk kah?')
                var timers = ms => new Promise(res => setTimeout(res, ms))
                let split_proxy = args[1].split('\n');
                let live_proxy = [];

                if (split_proxy.length >= 200) return reply('Maximal 200 list!')
                fs.writeFileSync(`./temp/proxy_check_${sender.split('@')[0]}.txt`, args[1])
                proxyChecker.checkProxiesFromFile(
                    `./temp/proxy_check_${sender.split('@')[0]}.txt`, {
                        url: 'http://google.com',
                    },
                    async function(host, port, ok, statusCode, err) {
                        if (statusCode === 200) {
                            live_proxy.push(host + ':' + port)
                            await timers(3000)
                        }
                    }
                );

                setTimeout(function() {
                    Promise.all(live_proxy).then(r => {
                        let result_proxy = `「 *PROXY-CHECKER* 」\n\n*Total Live:* ${r.length}\n\n`
                        for (let xxx of r) {
                            result_proxy += `${xxx}\n`
                        }
                        reply(mess.wait)
                        reply(result_proxy.trim())
                        fs.unlinkSync(`./temp/proxy_check_${sender.split('@')[0]}.txt`)
                    })
                }, 4000);
                break
            case prefix + 'iban':
                if (!args[1]) return reply(`Gunakan dengan cara ${command} IBAN\n\n_Contoh_\n\n${command} GB54BARC20035383263439`)

                axios({
                    method: 'POST',
                    url: 'https://www.theswiftcodes.com/iban-checker/',
                    data: new URLSearchParams(Object.entries({
                        iban: q
                    })),
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:93.0) Gecko/20100101 Firefox/93.0'
                    }
                }).then(r => {
                    const $ = cheerio.load(r.data);
                    const iban_country = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(1) > td:nth-child(3)').text().trim();
                    const iban_SEPA = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(2) > td:nth-child(2)').text().trim();
                    const iban_checksum = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(3) > td:nth-child(2)').text().trim();
                    const iban_BBAN = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(4) > td:nth-child(2)').text().trim();
                    const iban_swift = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(5) > td:nth-child(2)').text().trim();
                    const iban_sortc = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(6) > td:nth-child(2)').text().trim();
                    const iban_number = $('.swift-detail > tbody:nth-child(2) > tr:nth-child(7) > td:nth-child(2)').text().trim();
                    const iban_response = $('div.resultcorrect:nth-child(6) > span:nth-child(1)').text().trim();
                    const iban_result = `「 *IBAN-CHECKER* 」
    
${monospace(`Country    : ${iban_country ? iban_country : '-'}
SEPA       : ${iban_SEPA ? iban_SEPA : '-'}
Checksum   : ${iban_checksum ? iban_checksum : '-'}
BBAN       : ${iban_BBAN ? iban_BBAN : '-'}
BIC_Code   : ${iban_swift ? iban_swift : '-'}
Sort_Code  : ${iban_sortc ? iban_sortc : '-'}
Acc_Number : ${iban_number ? iban_number : '-'}
Response   : ${iban_response ? iban_response : '-'}`)}`
                    reply(mess.wait)
                    reply(iban_result.trim())
                }).catch(err => {
                    reply('Iban Not Valid!')
                })
                break
            case prefix + 'proxy':
                if (!args[1]) return reply(`Gunakan dengan cara ${command} http|socks5|socks4 \n\n_Contoh_\n\n${command} http`)

                if (args[1] === 'http') {
                    axios.get('https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=5000&country=all&ssl=all&anonymity=all').then(async (r) => {
                        fs.writeFileSync('./temp/proxy_http.txt', r.data)
                        var amount_proxy = fs.readFileSync('./temp/proxy_http.txt').toString().split('\n').length
                        var last_proxy_update = await axios.get('https://api.proxyscrape.com/?request=lastupdated&proxytype=http')
                        reply(mess.wait)
                        geps.sendMessage(from, fs.readFileSync('./temp/proxy_http.txt'), MessageType.document, {
                            quoted: msg,
                            mimetype: 'text/plain',
                            filename: 'proxy_http.txt'
                        }).then((x) => {
                            geps.sendMessage(from, `「 *Proxy-HTTP* 」
                            
${monospace(`Amount     : ${amount_proxy}
LastUpdate : ${last_proxy_update.data}`)}`, MessageType.text, {
                                quoted: x
                            }).then(() => {
                                fs.unlinkSync('./temp/proxy_http.txt')
                            })
                        })

                    })
                } else if (args[1] === 'socks4') {
                    axios.get('https://api.proxyscrape.com/?request=getproxies&proxytype=socks4&timeout=5000&country=all').then(async (r) => {
                        fs.writeFileSync('./temp/proxy_socks4.txt', r.data)
                        var amount_proxy = fs.readFileSync('./temp/proxy_socks4.txt').toString().split('\n').length
                        var last_proxy_update = await axios.get('https://api.proxyscrape.com?request=lastupdated&proxytype=socks4')
                        reply(mess.wait)
                        geps.sendMessage(from, fs.readFileSync('./temp/proxy_socks4.txt'), MessageType.document, {
                            quoted: msg,
                            mimetype: 'text/plain',
                            filename: 'proxy_socks4.txt'
                        }).then((x) => {
                            geps.sendMessage(from, `「 *Proxy-SOCKS4* 」
                            
${monospace(`Amount     : ${amount_proxy}
LastUpdate : ${last_proxy_update.data}`)}`, MessageType.text, {
                                quoted: x
                            }).then(() => {
                                fs.unlinkSync('./temp/proxy_socks4.txt')
                            })
                        })

                    })
                } else if (args[1] === 'socks5') {
                    axios.get('https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&timeout=5000&country=all').then(async (r) => {
                        fs.writeFileSync('./temp/proxy_socks5.txt', r.data)
                        var amount_proxy = fs.readFileSync('./temp/proxy_socks5.txt').toString().split('\n').length
                        var last_proxy_update = await axios.get('https://api.proxyscrape.com?request=lastupdated&proxytype=socks5')
                        reply(mess.wait)
                        geps.sendMessage(from, fs.readFileSync('./temp/proxy_socks5.txt'), MessageType.document, {
                            quoted: msg,
                            mimetype: 'text/plain',
                            filename: 'proxy_socks5.txt'
                        }).then((x) => {
                            geps.sendMessage(from, `「 *Proxy-SOCKS5* 」
                            
${monospace(`Amount     : ${amount_proxy}
LastUpdate : ${last_proxy_update.data}`)}`, MessageType.text, {
                                quoted: x
                            }).then(() => {
                                fs.unlinkSync('./temp/proxy_socks5.txt')
                            })
                        })

                    })
                } else {
                    reply(`Gunakan dengan cara ${command} http|socks5|socks4 \n\n_Contoh_\n\n${command} http`)
                }
                break
            case prefix + 'correct':
                if (!isOwner) return
                if (!args[1]) return reply(`Gunakan dengan cara ${command} on|off\n\n_Contoh_\n\n${command} on`)

                if (args[1] === "on") {
                    if (setting_path.autoCorrect === true) return reply(`*Auto-Correct* telah diaktifkan sebelumnya`)
                    setting_path.autoCorrect = true
                    fs.writeFileSync('./config.json', JSON.stringify(setting_path, null, 2))
                    reply(`*Auto-Correct* Berhasil diaktifkan!`)
                } else if (args[1] === "off") {
                    if (setting_path.autoCorrect === false) return reply(`*Auto-Correct* telah dimatikan sebelumnya`)
                    setting_path.autoCorrect = false
                    fs.writeFileSync('./config.json', JSON.stringify(setting_path, null, 2))
                    reply(`*Auto-Correct* Berhasil dimatikan!`)
                }
                break
            case prefix + 'accept':
                if (!isOwner) return false;
                if (!args[1]) return reply(`Gunakan dengan cara ${command} nomer\n\n_Contoh_\n\n${command} 6289523258649`)

                try {
                    let premiumPath__ = './database/premium'
                    let data_premium_ = JSON.parse(fs.readFileSync(premiumPath__ + '/' + args[1] + '@s.whatsapp.net' + '.json'))
                    let dataID = JSON.parse(fs.readFileSync(premiumPath__ + '/ids-match.json'))
                    reply(`Sukses accept payment dengan ID: ${data_premium_.ID}`)
                    sendMess(data_premium_.number, `Terima kasih ${data_premium_.data.name} pembayaran telah diterima dengan ID ${data_premium_.ID}, sesi premium anda telah diaktifkan untuk ${data_premium_.data.month} bulan ✅😇`)
                    if (_prem.checkPremiumUser(data_premium_.number, premium)) {
                        premium[_prem.getPremiumPosition(data_premium_.number, premium)].expired += toMs(data_premium_.data.month * 30 + "d")
                        fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
                        let indexData_sewa = dataID.findIndex(r => r['ID'] == data_premium_['ID'])
                        dataID.splice(indexData_sewa, 1)
                        fs.writeFileSync(premiumPath__ + '/ids-match.json', JSON.stringify(dataID, null, 3))
                        fs.unlinkSync(premiumPath__ + '/' + args[1] + '@s.whatsapp.net' + '.json')
                    } else {
                        _prem.addPremiumUser(data_premium_.number, data_premium_.data.month * 30 + "d", premium)
                        let indexData_sewa = dataID.findIndex(r => r['ID'] == data_premium_['ID'])
                        dataID.splice(indexData_sewa, 1)
                        fs.writeFileSync(premiumPath__ + '/ids-match.json', JSON.stringify(dataID, null, 3))
                        fs.unlinkSync(premiumPath__ + '/' + args[1] + '@s.whatsapp.net' + '.json')
                    }
                } catch (e) {
                    console.log(e)
                }
                break
            case prefix + 'acc':
                if (!isOwner) return false;
                if (!args[1]) return reply(`Gunakan dengan cara ${command} nomer\n\n_Contoh_\n\n${command} 6289523258649`)

                try {
                    let sewaPaths = './database/sewa'
                    let data_sewagc = JSON.parse(fs.readFileSync(sewaPaths + '/' + args[1] + '@s.whatsapp.net' + '.json'))
                    sendMess(args[1] + '@s.whatsapp.net', `Terima kasih ${data_sewagc.data.name} pembayaran telah diterima dengan ID ${data_sewagc.ID} ✅😇\n\nBot akan otomatis masuk ke grup yang telah dikirim, chat owner apabila terdapat kendala dengan ketik !owner`)
                    let cekrek = await geps.cekInviteCode(data_sewagc.data.grouplink.replace('https://chat.whatsapp.com/', ''))
                    geps.acceptInvite(data_sewagc.data.grouplink.replace('https://chat.whatsapp.com/', ''))
                        .then(async rest => {
                            let data_sewageceh = JSON.parse(fs.readFileSync(sewaPaths + '/' + args[1] + '@s.whatsapp.net' + '.json'))
                            let dataID = JSON.parse(fs.readFileSync(sewaPaths + '/ids-match.json'))
                            const metaMineFcs = await geps.fetchGroupMetadataFromWA(rest.gid)
                            if (_sewa.checkSewaGroup(cekrek.id, sewa)) {
                                sewa[_sewa.getSewaPosition(cekrek.id, sewa)].expired += toMs(data_sewageceh.data.month * 30 + "d")
                                fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa))
                                sendMess(rest.gid, `Halo, waktu sewa bot telah ditambahkan di grup ${metaMineFcs.subject} untuk ${data_sewageceh.data.month} bulan, have a nice day 😉🎇`)
                                let indexData_sewa = dataID.findIndex(r => r['ID'] == data_sewageceh['ID'])
                                dataID.splice(indexData_sewa, 1)
                                fs.writeFileSync(sewaPaths + '/ids-match.json', JSON.stringify(dataID, null, 3))
                                fs.unlinkSync(sewaPaths + '/' + args[1] + '@s.whatsapp.net' + '.json')
                            } else {
                                _sewa.addSewaGroup(rest.gid, toMs(data_sewageceh.data.month * 30 + "d"), sewa)
                                sendMess(rest.gid, `Halo, bot telah masuk ke grup ${metaMineFcs.subject} untuk ${data_sewageceh.data.month} bulan, have a nice day 😉🎇`)
                                let indexData_sewa = dataID.findIndex(r => r['ID'] == data_sewageceh['ID'])
                                dataID.splice(indexData_sewa, 1)
                                fs.writeFileSync(sewaPaths + '/ids-match.json', JSON.stringify(dataID, null, 3))
                                fs.unlinkSync(sewaPaths + '/' + args[1] + '@s.whatsapp.net' + '.json')
                            }
                        })
                        .catch(e => {
                            console.log(e)
                            let data_sewageceh = JSON.parse(fs.readFileSync(sewaPaths + '/' + args[1] + '@s.whatsapp.net' + '.json'))
                            sendMess(ownerNumber, `Kesalahan masuk grup ${util.format(e)}`)
                            sendMess(args[1] + '@s.whatsapp.net', `Maaf kak bot tidak bisa masuk grup, kirim laporan ke wa.me/${ownerNumber.replace(/@.+/g, '')}?text=Join+Group+Failed+ID+${data_sewageceh.ID}`)
                        })
                } catch (err) {
                    console.log(err)
                }
                break
            case prefix + 'ytmp3':
                if (!q) return reply(`kirim perintah ${prefix}ytmp3 *url*\nContoh: ${prefix}ytmp3 https://youtube.com/shorts/FfNiaDaNX0I?feature=share`)
                if (!q.includes('youtube.com') && !q.includes('youtu.be')) return reply('Url yang kamu kirimkan tidak valid')

                ytdlmp3(q).then(async (r) => {
                    reply(mess.wait);
                    if (Number(r[0].filesize.split(' MB')[0]) >= 100.0) {
                        axios.get(`https://tinyurl.com/api-create.php?url=${r[1].dlink}`).then(x => {
                            reply(`_Mohon maaf, media tersebut melebihi batas yang disajikan, Silahkan download menggunakan link dibawah_\n\n${x.data}`)
                        }).catch(err => {
                            reply(mess.error.api)
                            console.log(err)
                        })
                    }
                    sendFileFromUrl(from, r[0].thumbnail, `「 *YTMP3-DL* 」\n\n• *Title:* ${r[0].title ? r[0].title : '-'}\n• *Filesize:* ${r[0].filesize ? r[0].filesize : '-'}\n• *qualityType:* ${r[0].qualityType ? r[0].qualityType : '-'}\n• *Duration:* ${r[0].durationNumber ? r[0].durationNumber : '-'}\n\n_Mohon tunggu sebentar, media akan segera dikirim_`, msg);
                    sendFileFromUrl(from, r[1].dlink, `Nih`, msg)
                }).catch(e => {
                    reply(mess.error.api);
                    console.log(e);
                })
                break
            case prefix + 'ytmp4':
                if (!q) return reply(`kirim perintah ${prefix}ytmp4 *url*\nContoh: ${prefix}ytmp4 https://youtube.com/shorts/FfNiaDaNX0I?feature=share`)
                if (!q.includes('youtube.com') && !q.includes('youtu.be')) return reply('Url yang kamu kirimkan tidak valid')

                ytdlmp4(q).then(async (r) => {
                    reply(mess.wait);
                    if (Number(r[0].filesize.split(' MB')[0]) >= 100.0) {
                        axios.get(`https://tinyurl.com/api-create.php?url=${r[1].dlink}`).then(x => {
                            reply(`_Mohon maaf, media tersebut melebihi batas yang disajikan, Silahkan download menggunakan link dibawah_\n\n${x.data}`)
                        }).catch(err => {
                            reply(mess.error.api)
                            console.log(err)
                        })
                    }
                    sendFileFromUrl(from, r[0].thumbnail, `「 *YTMP4-DL* 」\n\n• *Title:* ${r[0].title ? r[0].title : '-'}\n• *Filesize:* ${r[0].filesize ? r[0].filesize : '-'}\n• *qualityType:* ${r[0].qualityType ? r[0].qualityType : '-'}\n• *Duration:* ${r[0].durationNumber ? r[0].durationNumber : '-'}\n\n_Mohon tunggu sebentar, media akan segera dikirim_`, msg);
                    sendFileFromUrl(from, r[1].dlink, `Nih`, msg)
                }).catch(e => {
                    reply(mess.error.api);
                    console.log(e);
                })
                break
            case prefix + 'ytdl':
                if (!q) return reply(`kirim perintah ${prefix}ytdl *url*\nContoh: ${prefix}ytdl https://youtube.com/shorts/FfNiaDaNX0I?feature=share`)
                if (!q.includes('youtube.com') && !q.includes('youtu.be')) return reply('Url yang kamu kirimkan tidak valid')

                ytdlmp4(q).then(async (r) => {
                    reply(mess.wait)
                    const buffimg = await getBuffer(r[0].thumbnail)
                    const prepimg = await geps.prepareMessage(from, buffimg, image, {
                        thumbnail: buffimg
                    })
                    var buttonMessage = {
                        imageMessage: prepimg.message.imageMessage,
                        contentText: `• *Title:* ${r[0].title ? r[0].title : '-'}\n• *Filesize:* ${r[0].filesize ? r[0].filesize : '-'}\n• *qualityType:* ${r[0].qualityType ? r[0].qualityType : '-'}\n• *Duration:* ${r[0].durationNumber ? r[0].durationNumber : '-'}`,
                        footerText: setting.botName,
                        buttons: [{
                                buttonId: 'audio',
                                buttonText: {
                                    displayText: 'AUDIO'
                                },
                                type: 1
                            },
                            {
                                buttonId: 'video',
                                buttonText: {
                                    displayText: 'VIDEO'
                                },
                                type: 1
                            }
                        ],
                        headerType: 4
                    }
                    geps.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                    addReq(sender, q, reqDB)
                }).catch(e => {
                    reply(mess.error.api)
                    deleteReq(sender, reqDB)
                })
                break
            case prefix + 'wiki':
                if (!args[1] && !args[2]) return reply(`Gunakan perintah\n${prefix}wiki *lang* *query*\nExample: ${prefix}wiki id ikan`);

                axios.get(`https://${args[1]}.wikipedia.org/wiki/${args[2]}`).then(r => {
                    if (r.status === 200) {
                        const $ = cheerio.load(r.data);
                        let data_res = $('#mw-content-text > div.mw-parser-output > p').text().trim();
                        reply(mess.wait);
                        reply(`「 *WIKI-SEARCH* 」\n\n${data_res.trim()}`)
                    }
                }).catch(err => {
                    reply(mess.error.api);
                    console.log(err);
                })
                break
            case prefix + 'brainly':
                if (!q) return reply(`Gunakan dengan cara\n${prefix}brainly *soal*\nContoh: ${prefix}brainly apa itu dpr`)
                const delay = ms => new Promise(res => setTimeout(res, ms))

                brainly.getQuestion(q).then(async (r) => {
                    reply(mess.wait);
                    reply(`*${r.length}* Jawaban di temukan...`)
                    for (let x = 0; x < r.length; x++) {
                        let result_brainly = `${r[x].node.answers.nodes[0].content.replace(/(<([^>]+)>)/ig, "").trim()}`
                        reply(result_brainly.trim())
                        await delay(3000)
                    }
                }).catch(async (e) => {
                    reply(mess.error.api)
                    console.log(e)
                })
                break
            case prefix + 'tiktok-dl':
                if (!q) return reply(`kirim perintah ${prefix}tiktok-dl *url*\nContoh: ${prefix}tiktok-dl https://vt.tiktok.com/ZSJwT7ACN/`)
                if (!q.includes('tiktok.com')) return reply('Url yang kamu kirimkan tidak valid')

                axios.get('https://en.tiktok-downloader.online/').then(r => {
                    const $ = cheerio.load(r.data);
                    var _tomken = $('head > meta:nth-child(3)').attr('content');

                    axios({
                        method: 'GET',
                        url: `https://en.tiktok-downloader.online/api/v1/fetch?url=${q}`,
                        data: new URLSearchParams(Object.entries({
                            url: q
                        })),
                        headers: {
                            'token': _tomken,
                            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
                        }
                    }).then(r => {
                        reply(mess.wait)
                        var buttonMessage = {
                            contentText: `「 *TIKTOK-DL* 」

• *Title:* ${r.data.title ? r.data.title : '-'}
• *Video_ID:* ${r.data.video_id ? r.data.video_id : '-'}
• *Caption:* ${r.data.caption ? r.data.caption : '-'}
• *Comments:* ${r.data.stats.comments ? r.data.stats.comments : '-'}
• *Like:* ${r.data.stats.likes ? r.data.stats.likes : '-'}
• *Shares:* ${r.data.stats.shares ? r.data.stats.shares : '-'}
• *Play:* ${r.data.stats.play ? r.data.stats.play : '-'}
• *UploadAt:* ${r.data.uploaded_at ? r.data.uploaded_at : '-'}
• *DownloadCount:* ${r.data.dl_count ? r.data.dl_count : '-'}

_Pilih berdasarkan button dibawah_`,
                            footerText: setting.botName,
                            buttons: [{
                                    buttonId: 'mp4',
                                    buttonText: {
                                        displayText: 'MP4-WM'
                                    },
                                    type: 1
                                },
                                {
                                    buttonId: 'mp4-nowm',
                                    buttonText: {
                                        displayText: 'MP4-NOWM'
                                    },
                                    type: 1
                                },
                                {
                                    buttonId: 'mp3',
                                    buttonText: {
                                        displayText: 'MP3'
                                    },
                                    type: 1
                                }
                            ],
                            headerType: 1
                        }
                        geps.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                        addReqtiktok(sender, q, reqDB_tiktok)
                    }).catch(e => {
                        // reply(mess.error.api)
                        // deleteReqtiktok(sender, reqDB_tiktok)
                    })
                }).catch(e => {
                    // reply(mess.error.api)
                    // deleteReqtiktok(sender, reqDB_tiktok)
                })
                break
            case prefix + 'bin-check':
            case prefix + 'bin-checker':
            case prefix + 'bin-lookup':
            case prefix + 'bin':
                if (!q) return reply(`Gunakan dengan\n${prefix}bin-checker *bin/cc*\nExample: ${prefix}bin-checker 4514030006555013\n\nATAU\n\n${prefix}bin-checker 451403`)
                if (q.length === 6) {
                    axios.get(`https://lookup.binlist.net/${q}`).then(r => {
                        let res_bincheck = `「 *BIN-LOOKUP* 」

${monospace(`Scheme     : ${r.data.scheme ? r.data.scheme : '-'}
Type       : ${r.data.type ? r.data.type : '-'}
Brand      : ${r.data.brand ? r.data.brand : '-'}
County     : ${r.data.country.name ? r.data.country.name : '-'} ${r.data.country.emoji ? r.data.country.emoji : '-'}
Currency   : ${r.data.country.currency ? r.data.country.currency : '-'}
Bank_Name  : ${r.data.bank.name ? r.data.bank.name : '-'}
Bank_Phone : ${r.data.bank.phone ? r.data.bank.phone : '-'}`)}`
                        reply(mess.wait);
                        reply(res_bincheck.trim())
                    }).catch(e => {
                        reply('Bin Not Valid!')
                        console.log(e)
                    })
                } else {
                    axios.get(`https://lookup.binlist.net/${q.slice(0, 6)}`).then(r => {
                        let res_bincheck = `「 *BIN-LOOKUP* 」

${monospace(`Scheme     : ${r.data.scheme ? r.data.scheme : '-'}
Type       : ${r.data.type ? r.data.type : '-'}
Brand      : ${r.data.brand ? r.data.brand : '-'}
County     : ${r.data.country.name ? r.data.country.name : '-'} ${r.data.country.emoji ? r.data.country.emoji : '-'}
Currency   : ${r.data.country.currency ? r.data.country.currency : '-'}
Bank_Name  : ${r.data.bank.name ? r.data.bank.name : '-'}
Bank_Phone : ${r.data.bank.phone ? r.data.bank.phone : '-'}`)}`
                        reply(mess.wait);
                        reply(res_bincheck.trim())
                    }).catch(e => {
                        reply(mess.error.api)
                        console.log(e)
                    })
                }
                break
            case prefix + 'get-bin':
                if (!q) return reply(`Gunakan dengan cara\n${prefix}get-bin *country*\nContoh: ${prefix}get-bin canada`)

                axios.get(`https://www.getbincodes.com/country-${q}/`).then(r => {
                    const $ = cheerio.load(r.data);
                    let myA = [];

                    $('table.table.table-bordered.table-hover > tbody > tr').each((_i, _el) => {
                        let _bin = $(_el).find('td:nth-child(1) > a').text();
                        let _type = $(_el).find('td:nth-child(4) > a').text();
                        myA.push({
                            bin: _bin,
                            type: _type
                        })
                    })
                    let res_bin = `「 *BIN-SEARCH* 」\n\n*Total Bin:* ${myA.length}\n\n`
                    for (let x = 0; x < myA.length; x++) {
                        res_bin += `• *Bin:* ${myA[x].bin}\n• *Type:* ${myA[x].type}\n\n`
                    }
                    reply(mess.wait)
                    reply(res_bin.trim())
                }).catch(e => {
                    reply(mess.error.api)
                    console.log(e)
                })
                break
            case prefix + 'shell-checker':
                if (!q) return reply('Listnya?, mana?')

                let split_shell = q.split('\n');
                let live_shell = [];

                if (split_shell.length > 50) return reply('Maximal 50 list!')
                split_shell.forEach((_shell) => {
                    axios.get(_shell).then(r => {
                        if (r.status === 200) {
                            live_shell.push(_shell)
                        }
                    }).catch(e => {
                        //
                    })
                })

                setTimeout(function() {
                    Promise.all(live_shell).then(r => {
                        let result_shell = `「 *SHELL-CHECKER* 」\n\n*Total Live:* ${r.length}\n\n`
                        // console.log(r.length)
                        for (let xh of r) {
                            result_shell += `${xh}\n`
                        }
                        reply(result_shell.trim())
                    })
                }, 3000);
                break
            case prefix + 'cc-checker':
                if (!args[1]) return reply('Where the list cc?, ngamtuk kah?')
                var timers = ms => new Promise(res => setTimeout(res, ms))
                let split_cc = args[1].split('\n');
                let live_cc = [];

                if (split_cc.length > 200) return reply('Maximal 200 list!')
                split_cc.forEach((_cc) => {
                    axios.post('https://gostrafx.com/api.php', qs.stringify({
                        data: _cc
                    })).then(async (r) => {
                        if (r.data.error === 1) {
                            live_cc.push(_cc)
                            await timers(3000)
                        }
                    }).catch(e => {
                        //
                    })
                });

                setTimeout(function() {
                    Promise.all(live_cc).then(r => {
                        let result_ccc = `「 *CC-CHECKER* 」\n\n*Total Live:* ${r.length}\n\n`
                        for (let xxx of r) {
                            result_ccc += `${xxx}\n`
                        }
                        reply(result_ccc.trim())
                    })
                }, 4000);
                break
            case prefix + 'film':
                if (!q) return reply(`Kirim perintah ${prefix}film *query*\n\nContoh: ${prefix}film mortal`)

                let myA = [];

                axios.get(`https://search.sharemydrive.xyz/?s=${q}`).then(r => {
                    var random_url = r.data.results[Math.floor(Math.random() * (r.data.results.length))]

                    axios.get(`http://149.56.24.226/${random_url.slug}`).then(x => {
                        const $ = cheerio.load(x.data);
                        let title_film = $('body > main > section.breadcrumb > div > ol > li.last > a > span').text().trim();
                        let quality_ = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(1) > h3 > a').text().trim();
                        let country_ = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(2) > h3 > a').text().trim();
                        let star_film = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(3)').text().replace('Bintang film', '').trim();
                        let sutradara_ = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(4) > h3 > a').text().trim();
                        let genre__ = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(5) > h3').text().trim();
                        let imdb = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(6) > h3').text().trim();
                        let terbit = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(7) > h3').text().trim();
                        let unggah = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(11) > h3').text().trim();
                        let duration = $('#movie-detail > div > div.col-xs-10.content > div:nth-child(12) > h3').text().trim();
                        myA.push({
                            title: title_film,
                            kualitas: quality_,
                            negara: country_,
                            bintang_film: star_film,
                            sutradara: sutradara_,
                            genre: genre__,
                            imdb: imdb,
                            terbit: terbit,
                            unggah: unggah,
                            durasi: duration
                        })

                        axios({
                            method: 'POST',
                            url: `http://dl.sharemydrive.xyz/verifying.php?slug=${random_url.slug}`,
                            data: new URLSearchParams(Object.entries({
                                slug: random_url.slug
                            })),
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36',
                                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                'Origin': 'http://dl.sharemydrive.xyz',
                                'Accept-Encoding': 'gzip, deflate',
                                'Accept-Language': 'en-US,en;q=0.9'
                            }
                        }).then(z => {
                            const $$ = cheerio.load(z.data)
                            let a = [];

                            $$('tbody > tr').each((i, el) => {
                                let provider = $$(el).find('td > strong').text().trim();
                                let url_dl = $$(el).find('td > a').attr('href');
                                a.push({
                                    provider: provider,
                                    link: url_dl
                                })
                            })
                            myA.push({
                                download: a
                            })
                            let result_filmmm = `「 *FILM-SEARCH* 」\n\n• *Title:* ${myA[0].title}\n• *Quality:* ${myA[0].kualitas}\n• *Country:* ${myA[0].negara}\n• *Star_Film:* ${myA[0].bintang_film}\n• *Sutradara:* ${myA[0].sutradara}\n• *Genre:* ${myA[0].genre}\n• *ImDb:* ${myA[0].imdb}\n• *Terbit:* ${myA[0].terbit}\n• *UploadAt:* ${myA[0].unggah}\n• *Duration:* ${myA[0].durasi}\n\n「 *MIRROR-DOWNLOAD* 」\n\n`
                            for (let x_ of myA[1].download) {
                                result_filmmm += `• *Provider:* ${x_.provider}\n• *Link:* ${x_.link}\n\n`
                            }
                            reply(mess.wait)
                            reply(result_filmmm.trim())
                        }).catch(e => {
                            reply(mess.error.api)
                            console.log(e)
                        })
                    }).catch(e => {
                        reply(mess.error.api)
                        console.log(e)
                    })
                }).catch(e => {
                    reply(mess.error.api)
                    console.log(e)
                })
                break
            case prefix + 'harta':
            case prefix + 'tahta':
                if (!q) return (async () => {
                    const replace_text = await q.replace(/(\S+\s*){1,10}/g, '$&\n')
                    const upper_text = await 'HARTA\nTAHTA\n' + replace_text.toUpperCase()
                    await spawn('convert', [
                            '-gravity',
                            'Center',
                            '-size',
                            '1280x1280',
                            'xc:black',
                            '-font',
                            './media/harta_tahta/hartatahta.ttf',
                            '-pointsize',
                            '200',
                            '-tile',
                            './media/harta_tahta/gradient.jpg',
                            '-annotate',
                            '+20+80',
                            upper_text,
                            '-wave',
                            '10x175',
                            '-crop',
                            '1200x1200+0+0',
                            `./media/harta_tahta/harta_${sender}.jpg`
                        ])
                        .on('error', async () => await reply(mess.error.api))
                        .on('exit', async () => {
                            await reply(mess.wait);
                            await geps.sendMessage(from, fs.readFileSync(`./media/harta_tahta/harta_${sender}.jpg`), image, {
                                quoted: msg,
                                caption: `HARTA TAHTA ${q.toUpperCase()}`
                            })
                            return await fs.unlinkSync(`./media/harta_tahta/harta_${sender}.jpg`)
                        })
                })();
                break
            case prefix + 'randomgore':
                axios.get('https://deadhouse.ru/').then(r => {
                    const $ = cheerio.load(r.data);
                    let myA = [];
                    $('div.post-grid-slide').each((i, el) => {
                        const _grab_link = $(el).find('div > a').attr('href');
                        myA.push(_grab_link);
                    })
                    var random_url = myA[Math.floor(Math.random() * myA.length)];

                    axios.get(random_url).then(x => {
                        const $$ = cheerio.load(x.data);
                        const _url_video = $$('script[type="application/ld+json"]').get(0).children[0].data;
                        const make_tojson = JSON.parse(_url_video)
                        sendFileFromUrl(from, make_tojson.contentUrl, `「 *RANDOM-GORE* 」\n\n• *Title:* ${make_tojson.name}\n• *UploadAt:* ${make_tojson.uploadDate}\n• *Description:* ${make_tojson.description}`, msg)
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                }).catch(e => {
                    reply(mess.error.api)
                })
                break
            case prefix + 'suit':
                if (isGame(sender, isOwner, gcount, glimit)) return reply(`Limit game kamu sudah habis`)
                var buttonMessage = {
                    contentText: `Silahkan Pilih berdasarkan button yang dibawah..`,
                    footerText: setting.botName,
                    buttons: [{
                            buttonId: 'batu',
                            buttonText: {
                                displayText: 'BATU'
                            },
                            type: 1
                        },
                        {
                            buttonId: 'gunting',
                            buttonText: {
                                displayText: 'GUNTING'
                            },
                            type: 1
                        },
                        {
                            buttonId: 'kertas',
                            buttonText: {
                                displayText: 'KERTAS'
                            },
                            type: 1
                        }
                    ],
                    headerType: 1
                }
                geps.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                gameAdd(sender, glimit)
                break
            case prefix + 'upload':
                if (isImage || isQuotedImage) {
                    let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                    let media = await geps.downloadAndSaveMediaMessage(encmedia, `./temp/By_DarkChatBOT`)
                    anonfile.upload(media).then((r) => {
                        if (r.status === true) {
                            let res_anon = `「 *ANONFILES-UPLOAD* 」

${monospace(`ID        : ${r.data.file.metadata.id}
Name      : ${r.data.file.metadata.name}
FileSize  : ${r.data.file.metadata.size.readable}
TypeFile  : Image
UploadAt  : ${moment(new Date()).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
Url-Short : ${r.data.file.url.short}
Url-Fulls : ${r.data.file.url.full}`)}`
                            reply(mess.wait)
                            sendFileFromUrl(from, "https://anonfiles.com/static/logo.png", res_anon.trim(), msg)
                            fs.unlinkSync(media)
                        } else {
                            reply(mess.error.api)
                        }
                    });
                } else if (isVideo || isQuotedVideo) {
                    let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                    let media = await geps.downloadAndSaveMediaMessage(encmedia, `./temp/By_DarkChatBOT`)
                    anonfile.upload(media).then((r) => {
                        if (r.status === true) {
                            let res_anon = `「 *ANONFILES-UPLOAD* 」

${monospace(`ID        : ${r.data.file.metadata.id}
Name      : ${r.data.file.metadata.name}
FileSize  : ${r.data.file.metadata.size.readable}
TypeFile  : Video
UploadAt  : ${moment(new Date()).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
Url-Short : ${r.data.file.url.short}
Url-Fulls : ${r.data.file.url.full}`)}`
                            reply(mess.wait)
                            sendFileFromUrl(from, "https://anonfiles.com/static/logo.png", res_anon.trim(), msg)
                            fs.unlinkSync(media)
                        } else {
                            reply(mess.error.api)
                        }
                    });
                } else if (isAudio || isQuotedAudio) {
                    let encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                    let media = await geps.downloadAndSaveMediaMessage(encmedia, `./temp/By_DarkChatBOT`)
                    anonfile.upload(media).then((r) => {
                        if (r.status === true) {
                            let res_anon = `「 *ANONFILES-UPLOAD* 」

${monospace(`ID        : ${r.data.file.metadata.id}
Name      : ${r.data.file.metadata.name}
FileSize  : ${r.data.file.metadata.size.readable}
TypeFile  : Audio
UploadAt  : ${moment(new Date()).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
Url-Short : ${r.data.file.url.short}
Url-Fulls : ${r.data.file.url.full}`)}`
                            reply(mess.wait)
                            sendFileFromUrl(from, "https://anonfiles.com/static/logo.png", res_anon.trim(), msg)
                            fs.unlinkSync(media)
                        } else {
                            reply(mess.error.api)
                        }
                    });
                } else if (isSticker || isQuotedSticker) {
                    let encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                    let media = await geps.downloadAndSaveMediaMessage(encmedia, `./temp/By_DarkChatBOT`)
                    anonfile.upload(media).then((r) => {
                        if (r.status === true) {
                            let res_anon = `「 *ANONFILES-UPLOAD* 」

${monospace(`ID        : ${r.data.file.metadata.id}
Name      : ${r.data.file.metadata.name}
FileSize  : ${r.data.file.metadata.size.readable}
TypeFile  : Sticker
UploadAt  : ${moment(new Date()).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
Url-Short : ${r.data.file.url.short}
Url-Fulls : ${r.data.file.url.full}`)}`
                            reply(mess.wait)
                            sendFileFromUrl(from, "https://anonfiles.com/static/logo.png", res_anon.trim(), msg)
                            fs.unlinkSync(media)
                        } else {
                            reply(mess.error.api)
                        }
                    });
                } else if (isDocument || isQuotedDocument) {
                    let encmedia = isQuotedDocument ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                    let media = await geps.downloadAndSaveMediaMessage(encmedia, `./temp/By_DarkChatBOT`)
                    anonfile.upload(media).then((r) => {
                        if (r.status === true) {
                            let res_anon = `「 *ANONFILES-UPLOAD* 」

${monospace(`ID        : ${r.data.file.metadata.id}
Name      : ${r.data.file.metadata.name}
FileSize  : ${r.data.file.metadata.size.readable}
TypeFile  : ${quotedMsg.type}
UploadAt  : ${moment(new Date()).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
Url-Short : ${r.data.file.url.short}
Url-Fulls : ${r.data.file.url.full}`)}`
                            reply(mess.wait)
                            sendFileFromUrl(from, "https://anonfiles.com/static/logo.png", res_anon.trim(), msg)
                            fs.unlinkSync(media)
                        } else {
                            reply(mess.error.api)
                        }
                    });
                } else {
                    reply('Format salah, Silahkan reply media yang ingin di upload')
                }
                break
            case prefix + 'esticker':
                if (args[1] === '--type' || args[1] === 'type') return reply(`*LIST-TYPE-STICKER*

1 = Apple
2 = Google
3 = Samsung
4 = Microsoft
5 = WhatsApp
6 = Twitter
7 = Facebook
8 = Skype
9 = JoyPixels
10 = OpenMoji
11 = EmojiDex
12 = Messenger
13 = Instagram
14 = Htc
15 = Mozilla
16 = Softbank
17 = Docomo
                
_Pilih Berdasarkan nomor_`)
                if (!args[1] && !args[2]) return reply(`Kirim perintah ${prefix}esticker *type* *emoji*\nContoh: ${prefix}esticker 1 🗿\n\nUntuk type lebih lanjut ketik ${prefix}esticker --type`)
                let digits_only = string => [...string].every(c => '0123456789'.includes(c));
                if (digits_only(args[1]) == false) return reply(`Format Salah silahkan ketik ${prefix}esticker --type\nuntuk melihat list emoji yang tersedia\nUntuk menggunakan silahkan ketik contoh: ${prefix}esticker 1 🗿`)
                if (args[1] === '1') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.apple)
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '2') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.google);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '3') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.samsung);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '4') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.microsoft);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '5') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.whatsapp);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '6') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.twitter);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '7') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.facebook);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '8') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.skype);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '9') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.joypixels);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '10') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.openmoji);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '11') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.emojidex);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '12') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.messenger);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '13') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.Ig);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '14') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.htc);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '15') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.mozilla);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '16') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.softbank);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else if (args[1] === '17') {
                    getEmoji(args[2]).then(r => {
                        sendStickerFromUrl(from, r.result.docomo);
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                } else {
                    reply(`Format Salah silahkan ketik ${prefix}esticker --type\nuntuk melihat list emoji yang tersedia\nUntuk menggunakan silahkan ketik contoh: ${prefix}esticker 1 🗿`)
                }
                break
            case prefix + 'komikuinfo':
                if (!q) return reply(`Kirim perintah ${prefix}komikinfo *url*\nExample: ${prefix}komikinfo https://komiku.id/manga/one-piece-indonesia/`);
                if (!q.includes('komiku.id')) return reply(`Url yang anda kirim tidak valid!`);

                komiku(q).then(r => {
                    let data_komiku = `「 *KOMIKU-INFO* 」\n\n• *Title-Japan:* ${r.JudulJepang}\n• *Title-Indo:* ${r.JudulIndo}\n• *Chapter:* ${r.Chapter}\n• *Creator:* ${r.Creator}\n• *Genre:* ${r.Genre}\n• *Description:* ${r.Deskripsi}\n• *Url:* ${r.Link}\n• *Sinopsis:* ${r.Sinopsis}`
                    sendFileFromUrl(from, r.Thumbnail, data_komiku.trim(), msg);
                }).catch(e => {
                    reply(mess.error.api)
                })
                break
            case prefix + 'komiku':
                if (!q) return reply(`Kirim perintah ${prefix}komiku *query*\nExample: ${prefix}komiku boruto`)

                searchkomiku(q).then(r => {
                    reply(mess.wait);
                    var random_pict = r[Math.floor(Math.random() * r.length)];
                    let data_komik = `「 *KOMIKU-SEARCH* 」\n\n• *Title:* ${random_pict.Judul}\n• *Url:* ${random_pict.Link}\n• *Description:* ${random_pict.Keterangan}`
                    sendFileFromUrl(from, random_pict.Gambar, data_komik.trim(), msg)
                }).catch(e => {
                    reply(mess.error.api);
                })
                break
            case prefix + 'fast':
                if (!isQuotedVideo) return reply('reply videonya...')
                var encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                var media = await geps.downloadAndSaveMediaMessage(encmedia)
                var outMp4 = getRandom('.mp4')

                exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2[a]" -map "[v]" -map "[a]" ${outMp4}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply(`Sorry error:(`)
                    var buffout = fs.readFileSync(outMp4)
                    geps.sendMessage(from, buffout, video, {
                        mimetype: 'video/mp4',
                        quoted: msg
                    })
                    fs.unlinkSync(outMp4)
                })
                break
            case prefix + 'slow':
                if (!isQuotedVideo) return reply('reply videonya...')
                var encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                var media = await geps.downloadAndSaveMediaMessage(encmedia)
                var outMp4 = getRandom('.mp4')

                exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=2*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]" ${outMp4}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply(`Sorry error:(`)
                    var buffout = fs.readFileSync(outMp4)
                    geps.sendMessage(from, buffout, video, {
                        mimetype: 'video/mp4',
                        quoted: msg
                    })
                    fs.unlinkSync(outMp4)
                })
                break
            case prefix + 'reverse':
                if (!isQuotedVideo) return reply('reply videonya...')
                var encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                var media = await geps.downloadAndSaveMediaMessage(encmedia)
                var outMp4 = getRandom('.mp4')

                exec(`ffmpeg -i ${media} -vf reverse -af areverse ${outMp4}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply(`Sorry error:(`)
                    var buffout = fs.readFileSync(outMp4)
                    geps.sendMessage(from, buffout, video, {
                        mimetype: 'video/mp4',
                        quoted: msg
                    })
                    fs.unlinkSync(outMp4)
                })
                break
            case prefix + 'chara':
                if (!q) return reply(`Kirim perintah ${prefix}chara *character_name*\nContoh: ${prefix}chara boruto`)
                axios.get(`https://myanimelist.net/search/prefix.json?type=character&keyword=${q}&v=1`)
                    .then(x => {
                        let data_chara = `「 *CHARA-SEARCH* 」

${monospace(`ID        : ${x.data.categories[0].items[0].id}
CharaName : ${x.data.categories[0].items[0].name}
Score     : ${x.data.categories[0].items[0].es_score}
Related   : ${x.data.categories[0].items[0].payload.related_works[0]}
Favorites : ${x.data.categories[0].items[0].payload.favorites}
Url       : ${x.data.categories[0].items[0].url}`)}`
                        reply(mess.wait)
                        sendFileFromUrl(from, x.data.categories[0].items[0].image_url, data_chara, msg)
                    }).catch(e => {
                        reply(mess.error.api)
                    })
                break
            case prefix + 'grup':
            case prefix + 'group':
                if (!isGroup) return reply(mess.OnlyGrup)
                if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(mess.BotAdmin)
                var buttonMessage = {
                    contentText: "Please choose from the provided options",
                    footerText: setting.botName,
                    buttons: [{
                            buttonId: 'id1',
                            buttonText: {
                                displayText: 'OPEN'
                            },
                            type: 1
                        },
                        {
                            buttonId: 'id2',
                            buttonText: {
                                displayText: 'CLOSE'
                            },
                            type: 1
                        }
                    ],
                    headerType: 1
                }

                geps.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                break
            case prefix + 'nowa':
                var teks = args[1]
                if (!teks.includes('x')) return reply('lah?')
                var numberPattern = /\d+/g;
                var nomer = teks.match(numberPattern)
                var random_length = teks.length - nomer[0].length
                if (random_length == 1) {
                    var random = 10
                } else if (random_length == 2) {
                    var random = 100
                } else if (random_length == 3) {
                    var random = 1000
                } else if (random_length == 4) {
                    var random = 10000
                }
                console.log(random)

                var nomerny = `*List Nomer*\n\nPunya Bio/status/info\n`
                var no_bio = `\nTanpa Bio/status/info ||\nHey there! I am using WhatsApp.\n`
                var no_watsap = `\nTidak Terdaftar\n`

                for (let i = 0; i < random; i++) {
                    var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
                    var dom1 = nu[Math.floor(Math.random() * nu.length)]
                    var dom2 = nu[Math.floor(Math.random() * nu.length)]
                    var dom3 = nu[Math.floor(Math.random() * nu.length)]
                    var dom4 = nu[Math.floor(Math.random() * nu.length)]

                    if (random_length == 1) {
                        var rndm = `${dom1}`
                    } else if (random_length == 2) {
                        var rndm = `${dom1}${dom2}`
                    } else if (random_length == 3) {
                        var rndm = `${dom1}${dom2}${dom3}`
                    } else if (random_length == 4) {
                        var rndm = `${dom1}${dom2}${dom3}${dom4}`
                    }

                    var anu = await geps.isOnWhatsApp(`${nomer[0]}${i}@s.whatsapp.net`);
                    var anuu = anu ? anu : false

                    try {
                        var anu1 = await geps.getStatus(anu.jid)
                        if (anu1.status == 401 || anu1.status == 'Hey there! I am using WhatsApp.') {
                            no_bio += `wa.me/${anu.jid.split("@")[0]}\n`
                            console.log(`-${i}) ${nomer[0]}${i}`, color(` [REGISTERED]`, 'green'))
                        } else {
                            nomerny += `wa.me/${anu.jid.split("@")[0]}\n`
                            console.log(`-${i}) ${nomer[0]}${i}`, color(` [REGISTERED]`, 'green'))
                        }
                    } catch {
                        no_watsap += `${nomer[0]}${i}\n`
                        console.log(`-${i}) ${nomer[0]}${i}`, color(` [NOT REGISTERED]`, 'red'))
                    }
                }
                reply(`${nomerny}${no_bio}${no_watsap}`)
                break
            case prefix + 'githubsearch':
                if (!q) return reply(`Kirim format ${prefix}githubsearch *query*\nExample: ${prefix}githubsearch x-tools`)
                axios.get(`https://github.com/search?q=${q}`).then(x => {
                    const $ = cheerio.load(x.data);
                    let myAu = [];
                    $('li.repo-list-item.hx_hit-repo.d-flex.flex-justify-start.py-4.public.source').each((i, el) => {
                        const _title_ = $(el).find('div.mt-n1 > div.f4.text-normal > a').text().trim();
                        const _langcode_ = $(el).find('div.mt-n1 > div > div.d-flex.flex-wrap.text-small.color-text-secondary > div > span > span').text().trim();
                        const _starCount_ = $(el).find('div.mt-n1 > div > div.d-flex.flex-wrap.text-small.color-text-secondary > div > a').text().trim();
                        const _updated_ = $(el).find('div.mt-n1 > div > div.d-flex.flex-wrap.text-small.color-text-secondary > div > relative-time').text().trim();
                        const _desc_ = $(el).find('div.mt-n1 > p').text().trim();
                        const _url_repo_ = $(el).find('div.mt-n1 > div.f4.text-normal > a').attr('href');
                        myAu.push({
                            title: _title_,
                            langcode: _langcode_,
                            starCount: _starCount_,
                            updated: _updated_,
                            url_repo: "https://github.com/" + _url_repo_,
                            desc: _desc_
                        })
                    })
                    let resghsearch = "「 *GITHUB-SEARCH* 」\n\n"
                    for (let x = 0; x < myAu.length; x++) {
                        resghsearch += `• *Title:* ${myAu[x].title}\n• *LangCode:* ${myAu[x].langcode}\n• *StarCount:* ${myAu[x].starCount}\n• *Updated:* ${myAu[x].updated}\n• *Url_repo:* ${myAu[x].url_repo}\n• *Desc:* ${myAu[x].desc}\n\n`
                    }
                    reply(mess.wait)
                    reply(resghsearch.trim())
                }).catch((err) => {
                    console.log(color('[Githubsearch]', 'red'), err)
                    reply(mess.error.api)
                })
                break
            case 'prefix':
            case 'cekprefix': {
                reply(`${prefix}`)
            }
            break
        case prefix + 'help':
        case prefix + 'menu': {
            let sisalimit = getLimit(sender, limitCount, limit)
            let sisaGlimit = cekGLimit(sender, gcount, glimit)
            let cekvip = ms(_prem.getPremiumExpired(sender, premium) - Date.now())
            var rawnya = JSON.parse(fs.readFileSync('./database/katabijak.json'));
            var ranraw = Math.floor(Math.random() * rawnya.length)
            var _katabijak = rawnya[ranraw]
            let expiredPrem = () => {
                if (cekvip.days != 0) {
                    return `${cekvip.days} day(s)`
                } else if (cekvip.hours != 0) {
                    return `${cekvip.hours} hour(s)`
                } else if (cekvip.minutes != 0) {
                    return `${cekvip.minutes}`
                }
            }
            reply(menu(prefix, pendaftar, runtime(process.uptime()), pushname, isOwner, isPremium, sisalimit, limitCount, sisaGlimit, gcount, expiredPrem(), tanggal, jam, setting.emote, geps.mode, _katabijak, botName))
        }
        break
        case prefix + 'exif': {
            if (!isOwner) return
            const namaPack = q.split('|')[0] ? q.split('|')[0] : q
            const authorPack = q.split('|')[1] ? q.split('|')[1] : ''
            exif.create(namaPack, authorPack)
            await reply('Done gan')
        }
        break
        case prefix + 'sticker':
        case prefix + 'stiker':
        case prefix + 's':
        case prefix + 'stickergif':
        case prefix + 'sgif': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (isImage || isQuotedImage) {
                let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                await ffmpeg(`${media}`)
                    .input(media)
                    .on('start', function(cmd) {
                        console.log(`Started : ${cmd}`)
                    })
                    .on('error', function(err) {
                        console.log(`Error : ${err}`)
                        fs.unlinkSync(media)
                        reply(mess.error.api)
                    })
                    .on('end', function() {
                        console.log('Finish')
                        exec(`webpmux -set exif ./sticker/data.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                            if (error) return reply(mess.error.api)
                            geps.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker, {
                                quoted: msg
                            })
                            limitAdd(sender, limit)
                            fs.unlinkSync(media)
                            fs.unlinkSync(`./sticker/${sender}.webp`)
                        })
                    })
                    .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                    .toFormat('webp')
                    .save(`./sticker/${sender}.webp`)
            } else if ((isVideo && msg.message.videoMessage.fileLength < 10000000 || isQuotedVideo && msg.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.fileLength < 10000000)) {
                let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                reply(mess.wait)
                await ffmpeg(`${media}`)
                    .inputFormat(media.split('.')[4])
                    .on('start', function(cmd) {
                        console.log(`Started : ${cmd}`)
                    })
                    .on('error', function(err) {
                        console.log(`Error : ${err}`)
                        fs.unlinkSync(media)
                        let tipe = media.endsWith('.mp4') ? 'video' : 'gif'
                        reply(mess.error.api)
                    })
                    .on('end', function() {
                        console.log('Finish')
                        exec(`webpmux -set exif ./sticker/data.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                            if (error) return reply(mess.error.api)
                            geps.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker, {
                                quoted: msg
                            })
                            limitAdd(sender, limit)
                            fs.unlinkSync(media)
                            fs.unlinkSync(`./sticker/${sender}.webp`)
                        })
                    })
                    .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                    .toFormat('webp')
                    .save(`./sticker/${sender}.webp`)
            } else {
                reply(`Kirim gambar/video dengan caption ${prefix}sticker atau tag gambar/video yang sudah dikirim\nNote : Durasi video maximal 10 detik`)
            }
        }
        break
        case prefix + 'stickerwm':
        case prefix + 'swm':
        case prefix + 'take':
        case prefix + 'takesticker':
        case prefix + 'takestick': {
            if (!isPremium) return reply(mess.OnlyPrem)
            if (args.length < 2) return reply(`Penggunaan ${command} nama|author`)
            let packname1 = q.split('|')[0] ? q.split('|')[0] : q
            let author1 = q.split('|')[1] ? q.split('|')[1] : ''
            if (isImage || isQuotedImage) {
                let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                exif.create(packname1, author1, `stickwm_${sender}`)
                await ffmpeg(`${media}`)
                    .input(media)
                    .on('start', function(cmd) {
                        console.log(`Started : ${cmd}`)
                    })
                    .on('error', function(err) {
                        console.log(`Error : ${err}`)
                        fs.unlinkSync(media)
                        reply(mess.error.api)
                    })
                    .on('end', function() {
                        console.log('Finish')
                        exec(`webpmux -set exif ./sticker/stickwm_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                            if (error) return reply(mess.error.api)
                            geps.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker, {
                                quoted: msg
                            })
                            fs.unlinkSync(media)
                            fs.unlinkSync(`./sticker/${sender}.webp`)
                            fs.unlinkSync(`./sticker/stickwm_${sender}.exif`)
                        })
                    })
                    .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                    .toFormat('webp')
                    .save(`./sticker/${sender}.webp`)
            } else if ((isVideo && msg.message.videoMessage.fileLength < 10000000 || isQuotedVideo && msg.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.fileLength < 10000000)) {
                let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                exif.create(packname1, author1, `stickwm_${sender}`)
                reply(mess.wait)
                await ffmpeg(`${media}`)
                    .inputFormat(media.split('.')[4])
                    .on('start', function(cmd) {
                        console.log(`Started : ${cmd}`)
                    })
                    .on('error', function(err) {
                        console.log(`Error : ${err}`)
                        fs.unlinkSync(media)
                        let tipe = media.endsWith('.mp4') ? 'video' : 'gif'
                        reply(mess.error.api)
                    })
                    .on('end', function() {
                        console.log('Finish')
                        exec(`webpmux -set exif ./sticker/stickwm_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                            if (error) return reply(mess.error.api)
                            geps.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker, {
                                quoted: msg
                            })
                            fs.unlinkSync(media)
                            fs.unlinkSync(`./sticker/${sender}.webp`)
                            fs.unlinkSync(`./sticker/stickwm_${sender}.exif`)
                        })
                    })
                    .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                    .toFormat('webp')
                    .save(`./sticker/${sender}.webp`)
            } else if (isQuotedSticker) {
                let encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                let media = await geps.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                exif.create(packname1, author1, `takestick_${sender}`)
                exec(`webpmux -set exif ./sticker/takestick_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                    if (error) return reply(mess.error.api)
                    geps.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker, {
                        quoted: msg
                    })
                    fs.unlinkSync(media)
                    fs.unlinkSync(`./sticker/takestick_${sender}.exif`)
                })
            } else {
                reply(`Kirim gambar/video dengan caption ${prefix}stickerwm nama|author atau tag gambar/video yang sudah dikirim\nNote : Durasi video maximal 10 detik`)
            }
        }
        break
        case prefix + 'tomp4':
        case prefix + 'toimg':
        case prefix + 'tomedia': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (!isQuotedSticker) return reply('Reply stiker nya')
            let encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            let media = await geps.downloadAndSaveMediaMessage(encmedia)
            if (quotedMsg.stickerMessage.isAnimated === true) {
                let outGif = getRandom('.gif')
                let outMp4 = getRandom('.mp4')
                exec(`convert ${media} ${outGif}`, (err) => {
                    if (err) {
                        console.log(err)
                        fs.unlinkSync(media)
                        return reply(`Error bruh`)
                    }
                    exec(`ffmpeg -i ${outGif} -vf "crop=trunc(iw/2)*2:trunc(ih/2)*2" -b:v 0 -crf 25 -f mp4 -vcodec libx264 -pix_fmt yuv420p ${outMp4}`, (err) => {
                        if (err) {
                            console.log(err)
                            fs.unlinkSync(media)
                            fs.unlinkSync(outGif)
                            return reply(`Error`)
                        }
                        geps.sendVideo(from, fs.readFileSync(outMp4), 'Nih', msg)
                            .then(() => {
                                fs.unlinkSync(outMp4)
                                limitAdd(sender, limit)
                            })
                    })
                })
            } else {
                reply(mess.wait)
                let ran = getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply('Gagal :V')
                    geps.sendMessage(from, fs.readFileSync(ran), image, {
                        quoted: msg,
                        caption: 'NIH'
                    })
                    limitAdd(sender, limit)
                    fs.unlinkSync(ran)
                })
            }
        }
        break
        case prefix + 'translate':
        case prefix + 'tr': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}translate* kodebahasa teks\n*${prefix}translate* kodebahasa <reply message>\n\nContoh : ${command} id What is your name?`)
            if (isQuotedMsg) {
                let bahasanya = args[1].toString()
                const trans = await translate(quotedMsg.chats, {
                        to: bahasanya
                    })
                    .then((res) => reply(res.text))
                    .catch((err) => {
                        reply(`${err}`)
                    })
                trans
                limitAdd(sender, limit)
            } else {
                if (args.length < 3) return reply(`Penggunaan :\n*${prefix}translate* kodebahasa teks\n*${prefix}translate* kodebahasa <reply message>`)
                let bahasanya = args[1].toString()
                let textnya = q.slice(args[1].length + 1, q.length)
                const trans = await translate(textnya, {
                        to: bahasanya
                    })
                    .then((res) => reply(res.text))
                    .catch((err) => {
                        reply(`${err}`)
                    })
                trans
                limitAdd(sender, limit)
            }
        }
        break
        case prefix + 'readmore':
            var more = String.fromCharCode(8206)
            var readMore = more.repeat(4001)
            const rmoreteks1 = q.split('|')[0] ? q.split('|')[0] : q
            const rmoreteks2 = q.split('|')[1] ? q.split('|')[1] : ''
            reply(`${rmoreteks1}${readMore}${rmoreteks2}`)
            break
        case prefix + 'ramalpasangan':
            const namayouu = q.split('|')[0] ? q.split('|')[0] : q
            const namashee = q.split('|')[1] ? q.split('|')[1] : ''
            if (!namayouu && !namashee) return reply(`kirim perintah ${prefix}ramalpasangan namakamu|namadia`)
            axios.get(`https://www.primbon.com/kecocokan_nama_pasangan.php?nama1=${namayouu}&nama2=${namashee}&proses=+Submit%21+`)
                .then(({
                    data
                }) => {
                    var $ = cheerio.load(data)
                    var progress = 'https://www.primbon.com/' + $('#body > img').attr('src')
                    var isi = $('#body').text().split(namashee)[1].replace('< Hitung Kembali', '').split('\n')[0]
                    var posi = isi.split('Sisi Negatif Anda: ')[0].replace('Sisi Positif Anda: ', '')
                    var nega = isi.split('Sisi Negatif Anda: ')[1]
                    var res = {
                        result: {
                            nama1: namayouu,
                            nama2: namashee,
                            thumb: progress,
                            positif: posi,
                            negatif: nega
                        }
                    }
                    var resultramalan = `「 *HASIL-RAMALAN* 」

${monospace(`Nama     : ${res.result.nama1}
Pasangan : ${res.result.nama2}
Positif  : ${res.result.positif}
Negatif  : ${res.result.negatif}`)}`
                    reply(mess.wait)
                    sendFileFromUrl(from, res.result.thumb, resultramalan, msg)
                }).catch((err) => {
                    console.log(color('[RamalPasangan]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'grupsearch':
            if (!q) return reply(`Format salah!, Kirim perintah\n\n${prefix}grupsearch *query*\nContoh: ${prefix}grupsearch bot`)
            axios.get(`http://ngarang.com/link-grup-wa/daftar-link-grup-wa.php?search=${q}&searchby=name`).then(x => {
                const $ = cheerio.load(x.data);
                let myAu = [];
                $('div.wa-chat').each((i, el) => {
                    const _title_ = $(el).find('div > div > div > a > div > div').text().split('.')[1].replace('*', '').trim();
                    const _url_ = $(el).find('div.wa-chat-body > div.wa-chat-message > a.URLMessage').text();
                    myAu.push({
                        title: _title_,
                        url: _url_
                    })
                })
                let my_text = `「 *GROUP-SEARCH* 」\n\n`
                for (let xyz = 0; xyz < myAu.length; xyz++) {
                    my_text += `• *Title:* ${myAu[xyz].title}\n• *Link:* ${myAu[xyz].url}\n\n`
                }
                reply(mess.wait)
                reply(my_text.trim())
            }).catch((err) => {
                console.log(color('[GroupSearch]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'inspect':
            if (!q) return reply(`Kirim perintah ${prefix}inspect *link*\n\nExample: ${prefix}inspect https://chat.whatsapp.com/G0io17sFYds7OTtOWHDyYF`)
            if (!q.includes('chat.whatsapp.com')) return reply(`Link group tidak valid!`)
            try {
                geps.cekInviteCode(q.split("/")[3]).then(x => {

                    let AAbb = `「 *INSPECTOR-LINK* 」
                        
${monospace(`Judul        : ${x.subject ? x.subject : '-'}
TotalMember  : ${x.size}
DiBuat Oleh  : ${x.id.split('-')[0]}
Pada tanggal : ${timeConverter(x.creation)}
Description  : ${x.desc ? x.desc : '-'}`)}`
                    reply(AAbb)

                    function timeConverter(UNIX_timestamp) {
                        var a = new Date(UNIX_timestamp * 1000);
                        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                        var year = a.getFullYear();
                        var month = months[a.getMonth()];
                        var date = a.getDate();
                        var hour = a.getHours();
                        var min = a.getMinutes();
                        var sec = a.getSeconds();
                        var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
                        return time;
                    }
                })
            } catch (e) {
                reply('Gagal inspect!')
            }
            break
        case prefix + 'shota':
            const shota = () => new Promise((resolve, reject) => {
                const Arr = ["shotanime", "shota anime", "anime shota"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    })
            })

            shota().then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.link, '*RANDOM-SHOTA*', msg)
            }).catch(async (err) => {
                console.log(color('[shota]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'kodepost':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah ${prefix}kodepost *daerah*`)

            async function searchCodePos(keywords) {
                return new Promise((resolve, reject) => {

                    let carikodepos = "https://carikodepos.com/"
                    let url = carikodepos + "?s=" + keywords

                    axios({
                        method: "GET",
                        url: url,
                        headers: {
                            "Accept": "application/json, text/javascript, /;",
                            "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4209.3 Mobile Safari/537.36",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                            "Origin": carikodepos,
                            "Referer": carikodepos
                        }
                    }).then((response) => {
                        const $ = cheerio.load(response.data)
                        let search = $("tr")

                        if (search.length > 0) {
                            let results = []

                            search.each((number, element) => {
                                if (number !== 0) {
                                    let td = $(element).find("td")
                                    let result = {}

                                    td.each((index, html) => {
                                        let value = $(html).find("a").html()
                                        let key = index === 0 ? "province" :
                                            (index === 1 ? "city" :
                                                (index === 2 ? "subdistrict" :
                                                    (index === 3 ? "urban" : "postalcode")))

                                        result[key] = value
                                    })

                                    results.push(result)
                                }
                            })

                            resolve({
                                status: 200,
                                data: results
                            })
                        } else {
                            reject("No result could be found")
                        }
                    }).catch(reject)

                })
            }

            searchCodePos(q).then(res => {
                let datakodepost = `「 *KODE-POST* 」\n\n`
                for (let x = 0; x < res.data.length; x++) {
                    datakodepost += `• Provinsi: ${res.data[x].province}\n• Kota: ${res.data[x].city}\n• Subdistrict: ${res.data[x].subdistrict}\n• Urban: ${res.data[x].urban}\n• Postalcode: ${res.data[x].postalcode}\n\n`
                }
                reply(mess.wait)
                reply(datakodepost.trim())
            }).catch(err => {
                console.log(color('[kodepost]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'appstore':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (!q) return reply(`Kirim perintah dengan\n\n${prefix}appstore *query*\nContoh: ${prefix}appstore panda`)
            const appstore = require('app-store-scraper');

            appstore.search({
                term: q,
                num: 2,
                page: 3,
                country: 'us',
                lang: 'lang'
            }).then((res) => {
                let dataappstore = `「 *APP-STORE* 」

${monospace(`Judul             : ${res[0].title}
ID                : ${res[0].id}
AppId             : ${res[0].appId}
Url               : ${res[0].url}
PrimaryGenre      : ${res[0].primaryGenre}
PrimaryGenreId    : ${res[0].primaryGenreId}
Rating            : ${res[0].contentRating}
Size              : ${bytesToSize(res[0].size)}
RequiredOSVersion : ${res[0].requiredOsVersion}
Released          : ${res[0].released}
Updated           : ${res[0].updated}
Version           : ${res[0].version}
isFree            : ${res[0].free ? 'Ya' : 'Tidak'}
DeveloperName     : ${res[0].developer}
Reviews           : ${res[0].reviews}
Description       : ${res[0].description.trim()}`)}`
                reply(mess.wait)
                sendFileFromUrl(from, res[0].icon, dataappstore, msg)
                limitAdd(sender, limit)
            }).catch((err) => {
                console.log(color('[Appstore]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'ebase64':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}ebase64 *text*\nContoh: ${prefix}ebase64 helloworld`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')
            reply(Buffer.from(q).toString('base64'))
            break
        case prefix + 'debase64':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}debase64 *encrypt base64*\nContoh: ${prefix}debase64 aGVsbG93b3JsZA==`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')
            reply(Buffer.from(q, 'base64').toString('ascii'))
            break
        case prefix + 'ehex':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}ehex *text*\nContoh: ${prefix}ehex Hello world`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')
            var convertHex = require('amrhextotext')
            reply(convertHex.textToHex(q))
            break
        case prefix + 'dehex':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}dehex *encrypt hex*\nContoh: ${prefix}dehex 68656c6c6f20776f726c64`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')
            var convertHex = require('amrhextotext')
            reply(convertHex.hexToUtf8(q))
            break
        case prefix + 'ebinary':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}ebinary *text*\nContoh: ${prefix}ebinary hello world`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')

            function encodeBinary(char) {
                return char.split("").map(str => {
                    const converted = str.charCodeAt(0).toString(2);
                    return converted.padStart(8, "0");
                }).join(" ")
            }
            reply(encodeBinary(q))
            break
        case prefix + 'debinary':
            if (!q) return reply(`Format salah!\n\nKirim perintah: ${prefix}debinary *text*\nContoh: ${prefix}debinary 01110100 01100101 01110011`)
            if (q.length > 2048) return reply('Maximal 2.048 String!')

            function decodebinary(char) {
                return char.split(" ").map(str => String.fromCharCode(Number.parseInt(str, 2))).join("");
            }
            reply(decodebinary(q))
            break
        case prefix + 'twtdl':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (!q) return reply(`Kirim perintah:\n\n${prefix}twtdl *link*`)
            if (!q.includes('twitter.com')) return reply(`Link yang kamu kirim tidak valid!`)
            const twtdl = (url) => new Promise((resolve, reject) => {
                fetch("https://twdown.net/download.php", {
                        "headers": {
                            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "content-type": "application/x-www-form-urlencoded",
                            "pragma": "no-cache",
                            "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-fetch-dest": "document",
                            "sec-fetch-mode": "navigate",
                            "sec-fetch-site": "same-origin",
                            "sec-fetch-user": "?1",
                            "upgrade-insecure-requests": "1"
                            // "cookie": "_ga=GA1.2.1814159488.1623699519; _gid=GA1.2.539894488.1623699519; _gat=1; __gads=ID=60356e4da39a627d-22cc5e8d84c90058:T=1623699520:RT=1623699520:S=ALNI_MbgAJ4sh0qPRkD-wf4Wi_G_VNLLig"
                        },
                        "referrer": "https://twdown.net/",
                        "referrerPolicy": "strict-origin-when-cross-origin",
                        "body": `URL=${url}`,
                        "method": "POST",
                        "mode": "cors"
                    }).then((ress) => ress.text())
                    .then((text) => {
                        const $ = cheerio.load(text)
                        const __thumbimage__ = $('body > div.jumbotron > div > center > div.row > div > div:nth-child(1) > div:nth-child(1) > img').attr('src');
                        const __caption__ = $('body > div.jumbotron > div > center > div.row > div > div:nth-child(1) > div:nth-child(2) > p').text().trim();
                        const __urlmp4__ = $('body > div.jumbotron > div > center > div.row > div > div:nth-child(5) > table > tbody > tr:nth-child(3) > td:nth-child(4) > a').attr('href');
                        const __twtname__ = $('body > div.jumbotron > div > center > div.row > div > div:nth-child(1) > div:nth-child(2) > h4 > strong').text().trim();
                        resolve({
                            twtname: __twtname__,
                            urlimage: __thumbimage__,
                            caption: __caption__,
                            urlmp4: __urlmp4__
                        })
                    }).catch((err) => {
                        resolve({
                            message: "emrror"
                        })
                    })
            })

            twtdl(q).then(data => {
                reply(mess.wait)
                sendFileFromUrl(from, data.urlimage, `「 *TWITTER-DL* 」\n\n• NameTwt: ${data.twtname}\n• Type: Video/480\n• Caption: ${data.caption}\n\n_Media sedang dikirim mohon tunggu_`, msg)
                sendFileFromUrl(from, data.urlmp4, 'Nih kak', msg)
            }).catch(err => {
                console.log(color('[TwtDL]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'bing':
            if (!q) return reply(`Kirim perintah ${prefix}bing *query*\nContoh: ${prefix}bing mark`)
            bing.search({
                q: q,
                enforceLanguage: true
            }, function(err, resp) {
                if (err) {
                    console.log(err);
                } else {
                    let myText = "「 BING-SEARCH 」\n\n";
                    for (let x = 0; x < resp.results.length; x++) {
                        myText += `• Title: ${resp.results[x].title}\n• Url: ${resp.results[x].url}\n• Desc: ${resp.results[x].description}\n\n`
                    }
                    reply(myText.trim())
                }
            })
            break
        case prefix + 'artimimpi':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}artimimpi query*`)

            function artimimpi(katakunci) {
                return new Promise((resolve, reject) => {
                    axios.get('https://www.primbon.com/tafsir_mimpi.php?mimpi=' + katakunci + '&submit=+Submit+')
                        .then(({
                            data
                        }) => {
                            var $ = cheerio.load(data)
                            var detect = $('#body > font > i').text()
                            var isAva = /Tidak ditemukan/g.test(detect) ? false : true
                            if (isAva) {
                                var isi = $('#body').text().split(`Hasil pencarian untuk kata kunci: ${katakunci}`)[1].replace(/\n\n\n\n\n\n\n\n\n/gi, '\n')
                                var res = {
                                    status: true,
                                    result: isi
                                }
                                resolve(res)
                            } else {
                                var res = {
                                    status: false,
                                    result: `Data tidak ditemukan! Gunakan kata kunci.`
                                }
                                resolve(res)
                            }
                        })
                        .catch(reject)
                })
            }
            artimimpi(q)
                .then((hasil) => {
                    if (hasil.result == false) return reply(`Artimimpi ${q}, tidak ditemukan`)
                    reply(hasil.result.trim())
                }).catch((err) => {
                    console.log(color('[Artimimpi]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'manga':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}manga query*`)
            try {
                reply(mess.wait)
                axios.get(`https://myanimelist.net/search/prefix.json?type=manga&keyword=${q}&v=1`)
                    .then(({
                        data
                    }) => {
                        var resultmangasearch = `*RESULT-MANGA*

${monospace(`Judul      : ${data.categories[0].items[0].name}
ID         : ${data.categories[0].items[0].id}
Link       : ${data.categories[0].items[0].url}
Type       : ${data.categories[0].items[0].type}
Published  : ${data.categories[0].items[0].payload.published}
Score      : ${data.categories[0].items[0].payload.score}
Start-Year : ${data.categories[0].items[0].payload.start_year}
Status     : ${data.categories[0].items[0].payload.status}`)}`
                        reply(resultmangasearch.trim())
                    }).catch((e) => {
                        reply(`Manga ${q} tidak di temukan`)
                    })
            } catch (err) {
                console.log(color('[Manga]', 'red'), err)
                reply(mess.error.api)
            }
            break
        case prefix + 'kemono':
            const kemono = () => new Promise((resolve, reject) => {
                const Arr = ["kemononime", "kemono anime", "anime kemono"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    })
            })

            kemono().then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.link, '*RANDOM-KEMONO*', msg)
            }).catch(async (err) => {
                console.log(color('[Kemono]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'otakulast':
            try {
                request(`https://otakudesu.moe/ongoing-anime/`, function(err, res, html) {
                    if (!err && res.statusCode == 200) {
                        var $ = cheerio.load(html)
                        const dataArrotakuon = [];
                        $('div.detpost').each((i, el) => {
                            const judulotakuon = $(el).find('div > a > div > h2').text().trim();
                            const epsotakuon = $(el).find('div.epz').text().trim();
                            const rilisdayotaku = $(el).find('div.epztipe').text().trim();
                            const tanggalotaku = $(el).find('div.newnime').text().trim();
                            const urlotakuon = $(el).find('div.thumb > a').attr('href');
                            dataArrotakuon.push({
                                judul: judulotakuon,
                                episode: epsotakuon,
                                rilis: rilisdayotaku + ' ' + tanggalotaku,
                                link: urlotakuon
                            })
                        })
                        let resultotakuon = `「 *OTAKU-LAST* 」\n\n`
                        for (let i = 0; i < dataArrotakuon.length; i++) {
                            resultotakuon += `• Judul: ${dataArrotakuon[i].judul}\n• Episode: ${dataArrotakuon[i].episode}\n• Tanggal: ${dataArrotakuon[i].rilis}\n• Link: ${dataArrotakuon[i].link}\n\n`
                        }
                        reply(mess.wait)
                        reply(resultotakuon.trim())
                    }
                })
            } catch (err) {
                console.log(color('[otakulast]', 'red'), err)
                reply(mess.error.api)
            }
            break
        case prefix + 'tinyurl':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}tinyurl* link\n\nContoh : ${command} https://youtube.com`)
            if (!isUrl(args[1])) return reply(body.replace(args[1], "*" + args[1] + "*") + `\n\nMasukkan link dengan benar\nContoh : ${command} https://youtube.com`)
            axios.get(`https://tinyurl.com/api-create.php?url=${args[1]}`)
                .then((a) => reply(`Nih ${a.data}`))
                .catch(() => reply(`Error, harap masukkan link dengan benar`))
            break
        case prefix + 'tomp3': {
            if (isVideo || isQuotedVideo) {
                let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadMediaMessage(encmedia)
                geps.sendMessage(from, media, audio, {
                    quoted: msg
                })
            }
        }
        break
        case prefix + 'waifu':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            const waifu = () => new Promise((resolve, reject) => {
                const Arr = ["waifunime", "waifu anime", "anime waifu"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    })
            })

            waifu().then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.link, `*RANDOM-WAIFU*`, msg)
            }).catch(async (err) => {
                console.log(color('[Waifu]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'neko':
        case prefix + 'nekonime':
            const neko = () => new Promise((resolve, reject) => {
                const Arr = ["nekonime", "neko anime", "anime neko"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    })
            })

            neko().then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.link, '*RANDOM-NEKO*', msg)
            }).catch(async (err) => {
                console.log(color('[neko]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'shinobu': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            reply(mess.wait)
            axios.get('https://waifu.pics/api/sfw/shinobu')
                .then(({
                    data
                }) => sendFileFromUrl(from, data.url, 'cintai shinobu mu', msg))
                .catch(err => {
                    console.log(color('[Nekonime]', 'red'), err)
                    reply(mess.error.api)
                })
            limitAdd(sender, limit)
        }
        break
        case prefix + 'megumin': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            reply(mess.wait)
            axios.get('https://waifu.pics/api/sfw/megumin')
                .then(({
                    data
                }) => sendFileFromUrl(from, data.url, 'cintai megumin mu', msg))
                .catch(err => {
                    console.log(color('[Nekonime]', 'red'), err)
                    reply(mess.error.api)
                })
            limitAdd(sender, limit)
        }
        break
        case prefix + 'husbu':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            const husbu = () => new Promise((resolve, reject) => {
                const Arr = ["husbunime", "husbu anime", "anime husbu"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    }).catch(reject)
            })

            husbu().then(async (res) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, res.link, `*RANDOM-HUSBU*`, msg)
            }).catch(async (err) => {
                console.log(color('[Husbu]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'loli':
            const loli = () => new Promise((resolve, reject) => {
                const Arr = ["lolinime", "loli anime", "anime loli"];
                const random = Arr[Math.floor(Math.random() * (Arr.length))]
                fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${random}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${random}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                        "headers": {
                            "accept": "application/json, text/javascript, */*, q=0.01",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "no-cache",
                            "pragma": "no-cache",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "sec-gpc": "1",
                            "x-app-version": "9a236a4",
                            "x-pinterest-appstate": "active",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.pinterest.com/",
                        "referrerPolicy": "origin",
                        "body": null,
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.json())
                    .then((json) => {
                        const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                        resolve({
                            status: 200,
                            link: generatepin.images.orig.url
                        })
                    })
            })

            loli().then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.link, '*RANDOM-LOLI*', msg)
            }).catch(async (err) => {
                console.log(color('[Loli]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'lirik':
        case prefix + 'lyric':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (!q) return reply(`Penggunaan : ${command} judul lagu`)

            axios.get(`http://www.songlyrics.com/index.php?section=search&searchW=${q}&submit=Search`).then(r => {
                const $ = cheerio.load(r.data);
                var top_result = $('div.serpresult:nth-child(5) > h3:nth-child(2) > a:nth-child(1)').attr('href');

                axios.get(top_result).then(x => {
                    const $$ = cheerio.load(x.data);
                    let res_lirik = $$('#songLyricsDiv').text().trim()
                    reply(mess.wait)
                    reply(res_lirik.trim())
                }).catch(er => {
                    console.log(er)
                    reply(mess.error.api)
                })
            }).catch(e => {
                console.log(e)
                reply(mess.error.api)
            })
            break
        case prefix + 'nulis':
            reply(`*Pilihan*\n${prefix}nuliskiri\n${prefix}nuliskanan\n${prefix}foliokiri\n${prefix}foliokanan`)
            break
        case prefix + 'nuliskiri': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}nuliskiri* teks`)
            reply(mess.wait)
            const tulisan = body.slice(11)
            const splitText = tulisan.replace(/(\S+\s*){1,9}/g, '$&\n')
            const fixHeight = splitText.split('\n').slice(0, 31).join('\n')
            spawn('convert', [
                    './media/nulis/images/buku/sebelumkiri.jpg',
                    '-font',
                    './media/nulis/font/Indie-Flower.ttf',
                    '-size',
                    '960x1280',
                    '-pointsize',
                    '22',
                    '-interline-spacing',
                    '2',
                    '-annotate',
                    '+140+153',
                    fixHeight,
                    './media/nulis/images/buku/setelahkiri.jpg'
                ])
                .on('error', () => reply(mess.error.api))
                .on('exit', () => {
                    geps.sendMessage(from, fs.readFileSync('./media/nulis/images/buku/setelahkiri.jpg'), image, {
                        quoted: msg,
                        caption: `Jangan malas pak...`
                    })
                    limitAdd(sender, limit)
                })
        }
        break
        case prefix + 'nuliskanan': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}nuliskanan* teks`)
            reply(mess.wait)
            const tulisan = body.slice(12)
            const splitText = tulisan.replace(/(\S+\s*){1,9}/g, '$&\n')
            const fixHeight = splitText.split('\n').slice(0, 31).join('\n')
            spawn('convert', [
                    './media/nulis/images/buku/sebelumkanan.jpg',
                    '-font',
                    './media/nulis/font/Indie-Flower.ttf',
                    '-size',
                    '960x1280',
                    '-pointsize',
                    '23',
                    '-interline-spacing',
                    '2',
                    '-annotate',
                    '+128+129',
                    fixHeight,
                    './media/nulis/images/buku/setelahkanan.jpg'
                ])
                .on('error', () => reply(mess.error.api))
                .on('exit', () => {
                    geps.sendMessage(from, fs.readFileSync('./media/nulis/images/buku/setelahkanan.jpg'), image, {
                        quoted: msg,
                        caption: `Jangan malas pak...`
                    })
                    limitAdd(sender, limit)
                })
        }
        break
        case prefix + 'newstickerline':
        case prefix + 'newsline':
            request('https://store.line.me/stickershop/showcase/new/id', function(err, res, html) {
                if (!err && res.statusCode == 200) {
                    var $ = cheerio.load(html)
                    var dataArrnewsline = [];
                    var urlnewsline = 'https://store.line.me'
                    $('li.mdCMN02Li').each((i, el) => {
                        var judulnewsline = $(el).find('a > div > p').text();
                        var linknewsline = $(el).find('a').attr('href');
                        dataArrnewsline.push({
                            Judul: judulnewsline,
                            Link: urlnewsline + linknewsline
                        })
                    })
                    var resultnewsline = `「 *NEW-STICKERLINE* 」\n\n`
                    for (let i = 0; i < dataArrnewsline.length; i++) {
                        resultnewsline += `• Judul: ${dataArrnewsline[i].Judul}\n• Link: ${dataArrnewsline[i].Link}\n\n`
                    }
                    reply(mess.wait)
                    reply(resultnewsline.trim())
                } else {
                    console.log(color('[newstickerline]', 'red'), err)
                    reply(mess.error.api)
                }
            })
            break
        case prefix + 'konachan':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}konachan query*`)

            const konachanSearch = (query) => new Promise((resolve, reject) => {
                fetch(`https://konachan.net/post?tags=${query}`, {
                        "credentials": "include",
                        "headers": {
                            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0",
                            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                            "Accept-Language": "en-US,en;q=0.5",
                            "Upgrade-Insecure-Requests": "1",
                            "Pragma": "no-cache",
                            "Cache-Control": "no-cache"
                        },
                        "referrer": "https://konachan.net/",
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.text())
                    .then((text) => {
                        const $ = cheerio.load(text)
                        const dataArr = [];
                        $('li.creator-id-181250').each((i, el) => {
                            const allgraburl = $(el).find('div.inner > a').attr('href');
                            dataArr.push(`https://konachan.net${allgraburl}`)
                        })
                        const randomPict = dataArr[Math.floor(Math.random() * dataArr.length)];
                        axios.get(randomPict).then(data => {
                            const $$ = cheerio.load(data.data)
                            const id = $$('#stats > ul:nth-child(2) > li:nth-child(2)').text().replace('Id: ', '').trim();
                            const postAt = $$('#stats > ul:nth-child(2) > li:nth-child(3) > a:nth-child(1)').text().trim();
                            const size = $$('#stats > ul:nth-child(2) > li:nth-child(4)').text().replace('Size: ', '').trim();
                            const rating = $$('#stats > ul:nth-child(2) > li:nth-child(6)').text().replace('Rating: ', '').trim();
                            const score = $$('#stats > ul:nth-child(2) > li:nth-child(7)').text().replace('Score: ', '').trim();
                            const source = $$('#stats > ul:nth-child(2) > li:nth-child(5) > a:nth-child(1)').attr('href');
                            const image = $$('#image').attr('src');
                            resolve({
                                status: 200,
                                id: id,
                                postAt: postAt,
                                size: size,
                                rating: rating,
                                score: score,
                                source: source,
                                image: image
                            })
                        })
                    })
            })

            konachanSearch(q).then(async (data) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, data.image, `「 *KONACHAN-SEARCH* 」\n\n• ID: ${data.id}\n• PostAt: ${data.postAt}\n• SizeImage: ${data.size}\n• Source: ${data.source}\n• Rating: ${data.rating}\n• Score: ${data.score}`, msg)
            }).catch(async (err) => {
                console.log(color('[KONACHAN]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'growstock':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}growstock query*`)
            const growstockSearch = (query) => new Promise((resolve, reject) => {
                fetch(`https://growstocks.xyz/search?item=${query}`, {
                        "credentials": "include",
                        "headers": {
                            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0",
                            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                            "Accept-Language": "en-US,en;q=0.5",
                            "Upgrade-Insecure-Requests": "1",
                            "Pragma": "no-cache",
                            "Cache-Control": "no-cache"
                        },
                        "referrer": "https://growstocks.xyz/",
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.text())
                    .then((text) => {
                        const $ = cheerio.load(text)
                        const dataArr = [];
                        $('div.searchRes').each((i, el) => {
                            const title = $(el).find('div > div > h2 > a').text().trim();
                            const price = $(el).find('div > div > p:nth-child(3) > b:nth-child(1)').text().trim();
                            const editedAt = $(el).find('div > div > p:nth-child(5) > b:nth-child(1)').text().trim();
                            dataArr.push({
                                title: title,
                                price: price ? price : 'Data tidak terbaca',
                                editedAt: editedAt ? editedAt : 'Data tidak terbaca',
                            })
                        })
                        resolve(dataArr)
                    })
            })

            growstockSearch(q).then(data => {
                let txt_ = `「 *GROWSTOCK-SEARCH* 」\n\n`
                for (let x = 0; x < data.length; x++) {
                    txt_ += `• Judul: ${data[x].title}\n• Price: ${data[x].price}\n• editedAt: ${data[x].editedAt}\n\n`
                }
                reply(mess.wait)
                reply(txt_.trim())
            }).catch((err) => {
                console.log(color('[growstock]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'happymod':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}happymod query*`)
            request(`https://www.happymod.com/search.html?q=${q}`, function(err, res, html) {
                if (!err && res.statusCode == 200) {
                    var $ = cheerio.load(html)
                    var dataArrhappymod = [];
                    $('div.pdt-app-msg').each((i, el) => {
                        var titlehappymod = $(el).find('h3 > a').text();
                        var linkhappymod = $(el).find('h3 > a').attr('href');
                        var ratehappymod = $(el).find('div.clearfix > span').text();
                        dataArrhappymod.push({
                            judul: titlehappymod,
                            link: 'https://www.happymod.com' + linkhappymod,
                            rate: ratehappymod
                        })
                    })
                    var resulthappymodsearch = `「 *HAPPY-MOD* 」\n\n`
                    for (let i = 0; i < dataArrhappymod.length; i++) {
                        resulthappymodsearch += `• Judul: ${dataArrhappymod[i].judul}\n• Link: ${dataArrhappymod[i].link}\n• Rating: ${dataArrhappymod[i].rate}\n\n`
                    }
                    reply(mess.wait)
                    reply(resulthappymodsearch.trim())
                } else {
                    console.log(color('[happymod]', 'red'), err)
                    reply(mess.error.api)
                }
            })
            break
        case prefix + 'drakor':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}drakor query*`)
            const drakorSearch = (query) => new Promise((resolve, reject) => {
                fetch(`https://drakorindo.life/?s=${query}`, {
                        "credentials": "include",
                        "headers": {
                            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0",
                            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                            "Accept-Language": "en-US,en;q=0.5",
                            "Upgrade-Insecure-Requests": "1",
                            "Pragma": "no-cache",
                            "Cache-Control": "no-cache"
                        },
                        "referrer": "https://drakorindo.life/",
                        "method": "GET",
                        "mode": "cors"
                    }).then((res) => res.text())
                    .then((text) => {
                        const $ = cheerio.load(text)
                        const dataArr = [];
                        $('article.mh-loop-item').each((i, el) => {
                            const title = $(el).find('div > header > h3 > a').text().trim();
                            const updateAt = $(el).find('div > header > div > span:nth-child(1)').text().trim();
                            const commentCOunt = $(el).find('div > header > div > span:nth-child(3) > a').text().trim();
                            const image = $(el).find('figure > a > img').attr('src');
                            const url = $(el).find('div > header > h3 > a').attr('href')
                            const description = $(el).find('div > div > div > p:nth-child(1)').text().trim();
                            dataArr.push({
                                title: title,
                                updateAt: updateAt,
                                commentCOunt: commentCOunt,
                                image: image,
                                source: url,
                                description: description
                            })
                        })
                        resolve(dataArr)
                    })
            })

            drakorSearch(q).then(async (data) => {
                let txt_ = `「 *DRAKOR-INDO* 」\n\n`
                for (let x = 0; x < data.length; x++) {
                    txt_ += `• Judul: ${data[x].title}\n• updateAt: ${data[x].updateAt}\n• CommentCount: ${data[x].commentCOunt}\n• url: ${data[x].source}\n• Desc: ${data[x].description}\n\n`
                }
                await reply(mess.wait)
                await reply(txt_.trim())
            }).catch(async (err) => {
                console.log(color('[drakor]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'amazon':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}amazon query*`)
            const randomnumbera = Math.floor(Math.random() * 50) + 1;

            amazonScraper.products({
                keyword: q,
                number: randomnumbera
            }).then((res) => {
                var reusltamazon = `「 *AMAZON-PRODUCT* 」

${monospace(`Item        : ${res.result[0].title}
Review      : ${res.result[0].reviews.total_reviews}
Rating      : ${res.result[0].reviews.rating}
Price       : ${res.result[0].price.current_price} ${res.result[0].price.currency}
Score       : ${res.result[0].score}
Discounted  : ${res.result[0].price.discounted ? 'Yes' : 'No'}
Url         : ${res.result[0].url}
Sponsored   : ${res.result[0].sponsored ? 'Yes' : 'No'}
BestSeller  : ${res.result[0].bestSeller ? 'Yes' : 'No'}
AmazonPrime : ${res.result[0].amazonPrime ? 'Yes' : 'No'}`)}`
                reply(mess.wait)
                sendFileFromUrl(from, res.result[0].thumbnail, reusltamazon.trim(), msg)
            }).catch((err) => {
                console.log(color('[amazon]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'dork':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}dork query*`)
            google({
                    'query': q,
                    'disableConsole': true
                })
                .then((res) => {
                    var resultdork = `「 *DORK-RESULT* 」\n\n`
                    for (let i = 0; i < res.length; i++) {
                        resultdork += `${i + 1}. ${res[i].link ? res[i].link : 'data tidak ada'}\n`
                    }
                    reply(mess.wait)
                    reply(resultdork.trim())
                }).catch((err) => {
                    console.log(color('[dork]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'nomorhoki':
            if (args.length === 1) return reply(`Kirim perintah ${prefix}nomorhoki *nomor*`)
            const nomorhoki = (no) => new Promise((resolve, reject) => {
                fetch("https://www.primbon.com/no_hoki_bagua_shuzi.php", {
                        "headers": {
                            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "max-age=0",
                            "content-type": "application/x-www-form-urlencoded",
                            "sec-fetch-dest": "document",
                            "sec-fetch-mode": "navigate",
                            "sec-fetch-site": "same-origin",
                            "sec-fetch-user": "?1",
                            "sec-gpc": "1",
                            "upgrade-insecure-requests": "1"
                        },
                        "referrer": "https://www.primbon.com/no_hoki_bagua_shuzi.htm",
                        "referrerPolicy": "strict-origin-when-cross-origin",
                        "body": `nomer=${no}&submit=+Submit%21+`,
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "omit"
                    }).then((res) => res.text())
                    .then((text) => {
                        const $ = cheerio.load(text)
                        $('#body').each((i, el) => {
                            const energipositif = $(el).find('table:nth-child(9) > tbody > tr:nth-child(1) > td:nth-child(1)').text().replace('ENERGI POSITIF', '');
                            const energinegatif = $(el).find('table:nth-child(9) > tbody > tr:nth-child(1) > td:nth-child(3)').text().replace('ENERGI NEGATIF', '');
                            const ratenomer = $(el).find('b:nth-child(6)').text().replace('% Angka Bagua Shuzi : ', '')
                            resolve({
                                status: 200,
                                energipositif: energipositif,
                                energinegatif: energinegatif,
                                rate: ratenomer
                            })
                        })
                    })
            })

            nomorhoki(q).then(async (data) => {
                reply(`「 *NOMOR-HOKI* 」\n\n• No: ${q}\n• Rate: ${data.rate}\n• Positif: ${data.energipositif}\n• Negatif: ${data.energinegatif}`)
            }).catch(async (err) => {
                console.log(color('[Nomorhoki]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'artinama':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}artinama query*`)
            axios.get(`https://www.primbon.com/arti_nama.php?nama1=${q}&proses=+Submit%21+`)
                .then(({
                    data
                }) => {
                    var $ = cheerio.load(data)
                    var result = $('#body').text().split('Nama:')[0]
                    reply(result.trim())
                }).catch((err) => {
                    console.log(color('[artinama]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'googleimage':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}googleimage query*`)
            async function ImageSearch(query) {
                return new Promise((resolve, reject) => {
                    gis(query, logResults)

                    function logResults(error, results) {
                        if (error) {
                            reject(error)
                        } else {
                            let url = []
                            for (let i = 0; i < results.length; i++) {
                                url.push(decodeURIComponent(JSON.parse(`"${results[i].url}"`)))
                            }
                            resolve(url)
                        }
                    }
                })
            }


            ImageSearch(q)
                .then(async (hasil) => {
                    var mathlolires = Math.floor(Math.random() * 50) + 1;
                    await reply(mess.wait)
                    await sendFileFromUrl(from, hasil[mathlolires], `Hasil: ${q}`, msg)
                }).catch(async (err) => {
                    console.log(color('[GoogleImage]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'cuaca':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}cuaca daerah*`)

            weather.find({
                search: q,
                degreeType: 'F'
            }, function(err, res) {
                if (err) {
                    console.log(color('[cuaca]', 'red'), err)
                    reply(mess.error.api)
                } else {
                    var resultcuaca = `「 *WEATHER* 」
  
${monospace(`Daerah      : ${res[0].location.name}
Latitude    : ${res[0].location.lat}
Longitude   : ${res[0].location.long}
TimeZone    : ${res[0].location.timezone}
Temperature : ${res[0].current.temperature}°
Tanggal     : ${res[0].current.date}
Waktu       : ${res[0].current.observationtime}
Hari        : ${res[0].current.day}
Cuaca       : ${res[0].current.skytext}`)}`
                    reply(mess.wait)
                    reply(resultcuaca.trim())
                }
            })
            break
        case prefix + 'ipgeolocation':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}ipgeolocation ip*`)
            ip2location.fetch(q)
                .then(res => {
                    var resultipgeo = `「 *IP-GEOLOCATION* 」

${monospace(`IpAddress   : ${q}
Code Negara : ${res.country_code}
Negara      : ${res.country_name}
Region Code : ${res.region_code}
Region Name : ${res.region_name}
City        : ${res.city}
Isp         : ${res.isp}
Zip Code    : ${res.zip_code}
TimeZone    : ${res.time_zone}
Latitude    : ${res.latitude}
Longitude   : ${res.longitude}`)}`
                    reply(mess.wait)
                    reply(resultipgeo)
                }).catch((err) => {
                    console.log(color('[IpGeolocation]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'heroml':
            if (args.length === 1) return reply(`Kirim perintah *${prefix}heroml query*`)

            function herodetails(name) {
                return new Promise((resolve, reject) => {
                    var splitStr = name.toLowerCase().split(' ');
                    for (let i = 0; i < splitStr.length; i++) {
                        splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
                    }
                    var que = splitStr.join(' ')
                    axios.get('https://mobile-legends.fandom.com/wiki/' + que)
                        .then(({
                            data
                        }) => {
                            var $ = cheerio.load(data)
                            var mw = []
                            var attrib = []
                            var skill = []
                            var name = $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td > table > tbody > tr > td > font > b').text()
                            $('.mw-headline').get().map((res) => {
                                var mwna = $(res).text()
                                mw.push(mwna)
                            })
                            $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td').get().map((rest) => {
                                var haz = $(rest).text().replace(/\n/g, '')
                                attrib.push(haz)
                            })
                            $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td > div.progressbar-small.progressbar > div').get().map((rest) => {
                                skill.push($(rest).attr('style').replace('width:', ''))
                            })
                            axios.get('https://mobile-legends.fandom.com/wiki/' + que + '/Story')
                                .then(({
                                    data
                                }) => {
                                    var $ = cheerio.load(data)
                                    var pre = []
                                    $('#mw-content-text > div > p').get().map((rest) => {
                                        pre.push($(rest).text())
                                    })
                                    var story = pre.slice(3).join('\n')
                                    var items = []
                                    var character = []
                                    $('#mw-content-text > div > aside > section > div').get().map((rest) => {
                                        character.push($(rest).text().replace(/\n\t\n\t\t/g, '').replace(/\n\t\n\t/g, '').replace(/\n/g, ''))
                                    })
                                    $('#mw-content-text > div > aside > div').get().map((rest) => {
                                        items.push($(rest).text().replace(/\n\t\n\t\t/g, '').replace(/\n\t\n\t/g, '').replace(/\n/g, ''))
                                    })
                                    var img = $('#mw-content-text > div > aside > figure > a').attr('href')
                                    var chara = character.slice(0, 2)
                                    var result = {
                                        status: 200,
                                        hero_name: name + ` ( ${mw[0].replace('CV:', ' CV:')} )`,
                                        entrance_quotes: attrib[2].replace('Entrance Quotes', '').replace('\n', ''),
                                        hero_feature: attrib[attrib.length - 1].replace('Hero Feature', ''),
                                        image: img,
                                        items: items,
                                        character: {
                                            chara
                                        },
                                        attributes: {
                                            movement_speed: attrib[12].replace('● Movement Speed', ''),
                                            physical_attack: attrib[13].replace('● Physical Attack', ''),
                                            magic_power: attrib[14].replace('● Magic Power', ''),
                                            attack_speed: attrib[15].replace('● Attack Speed', ''),
                                            physical_defense: attrib[16].replace('● Physical Defense', ''),
                                            magic_defense: attrib[17].replace('● Magic Defense', ''),
                                            basic_atk_crit_rate: attrib[18].replace('● Basic ATK Crit Rate', ''),
                                            hp: attrib[19].replace('● HP', ''),
                                            mana: attrib[20].replace('● Mana', ''),
                                            ability_crit_rate: attrib[21].replace('● Ability Crit Rate', ''),
                                            hp_regen: attrib[22].replace('● HP Regen', ''),
                                            mana_regen: attrib[23].replace('● Mana Regen', '')
                                        },
                                        price: {
                                            battle_point: mw[1].split('|')[0].replace(/ /g, ''),
                                            diamond: mw[1].split('|')[1].replace(/ /g, ''),
                                            hero_fragment: mw[1].split('|')[2] ? mw[1].split('|')[2].replace(/ /g, '') : 'none'
                                        },
                                        role: mw[2],
                                        skill: {
                                            durability: skill[0],
                                            offense: skill[1],
                                            skill_effects: skill[2],
                                            difficulty: skill[3]
                                        },
                                        speciality: mw[3],
                                        laning_recommendation: mw[4],
                                        release_date: mw[5],
                                        background_story: story
                                    }
                                    resolve(result)
                                }).catch((e) => reject({
                                    status: 404,
                                    message: e.message
                                }))
                        }).catch((e) => reject({
                            status: 404,
                            message: e.message
                        }))
                })
            }

            herodetails(q)
                .then(async (hasil) => {
                    var resultheroml = `「 *RESULT-FOUND!* 」

Nama Hero: ${hasil.hero_name}
Quotes: ${hasil.entrance_quotes}
Hero Feature: ${hasil.hero_feature}
Price Point: ${hasil.price.battle_point.trim()}
Price Diamond: ${hasil.price.diamond}
Role: ${hasil.role}
Movement speed: ${hasil.attributes.movement_speed}
Physical Attack: ${hasil.attributes.physical_attack}
Attack Speed: ${hasil.attributes.attack_speed}
Hp: ${hasil.attributes.hp} / ${hasil.attributes.hp_regen} _Regen_
Mana: ${hasil.attributes.mana} / ${hasil.attributes.mana_regen} _Regen_
Recommend Lane: ${hasil.laning_recommendation}
Release: ${hasil.release_date}
Background History: ${hasil.background_story.trim()}`

                    await reply(mess.wait)
                    await sendFileFromUrl(from, hasil.image, resultheroml.trim(), msg)
                }).catch(async (err) => {
                    console.log(color('[Heroml]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'wattpad':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}wattpad query*`)

            async function wattpadSearch(query) {
                return new Promise((resolve, reject) => {
                    axios.get('https://www.wattpad.com/search/' + query)
                        .then(({
                            data
                        }) => {
                            var $ = cheerio.load(data)
                            var title = []
                            var url = []
                            var id = []
                            var img = []
                            $('#results-stories > div > ul > li > div > a > div.cover.cover-xs.pull-left > img').get().map((rest) => {
                                title.push($(rest).attr('alt'))
                                img.push($(rest).attr('src'))
                            })
                            $('#results-stories > div > ul > li > div > a').get().map((rest) => {
                                url.push('https://www.wattpad.com' + $(rest).attr('href'))
                                id.push($(rest).attr('data-id'))
                            })
                            var results = []
                            for (let i = 0; i < title.length; i++) {
                                var ress = {
                                    id: id[i],
                                    title: title[i],
                                    thumb: img[i],
                                    url: url[i],

                                }
                                results.push(ress)
                            }
                            resolve(results)
                        }).catch(reject)
                })
            }

            wattpadSearch(q)
                .then((hasil) => {
                    var resultwp = '「 *WATTPAD-SEARCH* 」\n\n'
                    for (let i = 0; i < hasil.length; i++) {
                        resultwp += `• ID: ${hasil[i].id}\n• Judul: ${hasil[i].title}\n• Url: ${hasil[i].url}\n\n`
                    }
                    reply(mess.wait)
                    reply(resultwp.trim())
                }).catch((err) => {
                    console.log(color('[wattpad]', 'red'), err)
                    reply(mess.error.api)
                })
            break
        case prefix + 'cekspek':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}cekspek query*`)
            try {
                request(`https://www.gsmarena.com/res.php3?sSearch=${q}`, (error, res, html) => {
                    if (!error && res.statusCode == 200) {
                        var $ = cheerio.load(html);
                        $('#review-body > div > ul > li:nth-child(1) > a').each((i, el) => {
                            var urlnyaa = $(el).attr('href');
                            var urlimage = $('#review-body > div > ul > li:nth-child(1) > a > img').attr('src');
                            request(`https://www.gsmarena.com/${urlnyaa}`, (e, res, html) => {
                                if (!e && res.statusCode == 200) {
                                    var $ = cheerio.load(html);

                                    $('#body > div > div.review-header > div > div.article-info-line.page-specs.light.border-bottom > h1').each((i, el) => {
                                        var judulitem = $(el).text();
                                        var displaytipe = $('#specs-list > table:nth-child(5) > tbody > tr:nth-child(1) > td.nfo').text();
                                        var displaySize = $('#specs-list > table:nth-child(5) > tbody > tr:nth-child(2) > td.nfo').text();
                                        var displayreso = $('#specs-list > table:nth-child(5) > tbody > tr:nth-child(3) > td.nfo').text();
                                        var chipset = $('#specs-list > table:nth-child(6) > tbody > tr:nth-child(2) > td.nfo').text();
                                        var merkos = $('#specs-list > table:nth-child(6) > tbody > tr:nth-child(1) > td.nfo').text();
                                        var merkcpu = $('#specs-list > table:nth-child(6) > tbody > tr:nth-child(3) > td.nfo').text();
                                        var internalspek = $('#specs-list > table:nth-child(7) > tbody > tr:nth-child(2) > td.nfo').text();
                                        var spekkamera = $('#specs-list > table:nth-child(8) > tbody > tr:nth-child(1) > td.nfo').text();
                                        var spekbatre = $('#specs-list > table:nth-child(13) > tbody > tr:nth-child(1) > td.nfo').text();
                                        var allresultspek = `「 *RESULT FOUND!*」

${monospace(`Spek             : ${judulitem}
Display Tipe     : ${displaytipe}
Display Size     : ${displaySize}
Display Resolusi : ${displayreso}
Chipset          : ${chipset}
OS               : ${merkos}
Cpu              : ${merkcpu}
Internal         : ${internalspek}
Kamera           : ${spekkamera}
Batterai         : ${spekbatre}`)}`
                                        reply(mess.wait)
                                        sendFileFromUrl(from, urlimage, allresultspek, msg)
                                    })
                                }
                            })
                        })

                    }
                })
            } catch (err) {
                console.log(color('[google]', 'red'), err)
                reply(mess.error.api)
            }
            break
        case prefix + 'google':
            if (args.length === 1) return reply(`Kirim perintah ${prefix}google *query*\n\nExample: ${prefix}google bot`)
            google({
                'query': q,
                'disableConsole': true
            }).then(results => {
                let vars = `「 *GOOGLE-SEARCH* 」\n\n_Hasil Pencarian : ${q}_\n\n`
                for (let i = 0; i < results.length; i++) {
                    vars += `• Judul: ${results[i].title}\n• Link: ${results[i].link}\n• Deskripsi: ${results[i].snippet}\n\n`
                }
                reply(mess.wait)
                reply(vars.trim())
            }).catch((err) => {
                console.log(color('[google]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'dewabatch':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}dewabatch query*`)

            const dewabatchSearch = (query) => new Promise((resolve, reject) => {
                axios.get(`https://dewabatch.com/?s=${query}`).then((res) => {
                    const $ = cheerio.load(res.data)
                    const dataArr = [];
                    $('div.dtl').each((i, el) => {
                        const title = $(el).find('h2 > a').text().trim();
                        const url = $(el).find('h2 > a').attr('href');
                        const rating = $(el).find(' div.footer-content-post.fotdesktoppost > div.contentleft > span:nth-child(1) > rating > ratingval > ratingvalue').text().trim();
                        const uploadAt = $(el).find('div.footer-content-post.fotdesktoppost > div.contentleft > span:nth-child(2) > a').text().trim();
                        const desc = $(el).find('div.entry-content.synopspost').text().trim();
                        dataArr.push({
                            title: title,
                            rating: rating,
                            uploadAt: uploadAt,
                            url: url,
                            desc: desc
                        })
                    })
                    resolve({
                        status: 200,
                        data: dataArr
                    })
                })
            })

            dewabatchSearch(q).then(data => {
                let text_ = `「 *DEWABATCH-SEARCH* 」\n\n`
                for (let x = 0; x < data.data.length; x++) {
                    text_ += `• Judul: ${data.data[x].title}\n• Rating: ${data.data[x].rating}\n• UploadAt: ${data.data[x].uploadAt}\n• Url: ${data.data[x].url}\n• Desc: ${data.data[x].desc}\n\n`
                }
                reply(text_.trim())
            }).catch(async (err) => {
                console.log(color('[Dewabatch]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'pinterest':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}pinterest query*`)

            async function pinterestSearch(query) {
                return new Promise((resolve, reject) => {
                    fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`, {
                            "headers": {
                                "accept": "application/json, text/javascript, */*, q=0.01",
                                "accept-language": "en-US,en;q=0.9",
                                "cache-control": "no-cache",
                                "pragma": "no-cache",
                                "sec-fetch-dest": "empty",
                                "sec-fetch-mode": "cors",
                                "sec-fetch-site": "same-origin",
                                "sec-gpc": "1",
                                "x-app-version": "9a236a4",
                                "x-pinterest-appstate": "active",
                                "x-requested-with": "XMLHttpRequest"
                            },
                            "referrer": "https://www.pinterest.com/",
                            "referrerPolicy": "origin",
                            "body": null,
                            "method": "GET",
                            "mode": "cors"
                        }).then((res) => res.json())
                        .then((json) => {
                            const generatepin = json.resource_response.data.results[Math.floor(Math.random() * (json.resource_response.data.results.length))]
                            var result = [];
                            result.push({
                                link: generatepin.images.orig.url
                            })
                            resolve(result)
                        }).catch(reject)
                })
            }

            const pinterest = (query) => new Promise((resolve, reject) => {
                pinterestSearch(query).then((data) => {
                    resolve({
                        status: 200,
                        image: data[0].link
                    })
                }).catch(reject)
            })

            pinterest(q).then(async (res) => {
                await reply(mess.wait)
                await sendFileFromUrl(from, res.image, `Hasil Pencarian: ${q}`, msg)
            }).catch(async (err) => {
                console.log(color('[Pinterest]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'gplay':
        case prefix + 'playstore':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}playstore query*`)
            try {
                reply(mess.wait)
                gplay.search({
                        term: q,
                        num: 1
                    })
                    .then(async (hasil) => {
                        var resultpstore = `「 *PLAYSTORE* 」
  
${monospace(`Judul     : ${hasil[0].title}
Packname  : ${hasil[0].appId}
Developer : ${hasil[0].developer}
Summary   : ${hasil[0].summary}
Ratings   : ${hasil[0].scoreText}
Link      : ${hasil[0].url}`)}`
                        await sendFileFromUrl(from, hasil[0].icon, resultpstore, msg)
                    }).catch(async (err) => {
                        await reply(`Hasil ${q} tidak ditemukan`)
                    })
            } catch (err) {
                console.log(color('[Playstore]', 'red'), err)
                reply(mess.error.api)
            }
            break
        case prefix + 'foliokiri': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}foliokiri* teks`)
            reply(mess.wait)
            const tulisan = body.slice(11)
            const splitText = tulisan.replace(/(\S+\s*){1,13}/g, '$&\n')
            const fixHeight = splitText.split('\n').slice(0, 38).join('\n')
            spawn('convert', [
                    './media/nulis/images/folio/sebelumkiri.jpg',
                    '-font',
                    './media/nulis/font/Indie-Flower.ttf',
                    '-size',
                    '1720x1280',
                    '-pointsize',
                    '23',
                    '-interline-spacing',
                    '4',
                    '-annotate',
                    '+48+185',
                    fixHeight,
                    './media/nulis/images/folio/setelahkiri.jpg'
                ])
                .on('error', () => reply(mess.error.api))
                .on('exit', () => {
                    geps.sendMessage(from, fs.readFileSync('./media/nulis/images/folio/setelahkiri.jpg'), image, {
                        quoted: msg,
                        caption: `Jangan malas pak...`
                    })
                    limitAdd(sender, limit)
                })
        }
        break
        case prefix + 'foliokanan': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}foliokanan* teks`)
            reply(mess.wait)
            const tulisan = body.slice(12)
            const splitText = tulisan.replace(/(\S+\s*){1,13}/g, '$&\n')
            const fixHeight = splitText.split('\n').slice(0, 38).join('\n')
            spawn('convert', [
                    './media/nulis/images/folio/sebelumkanan.jpg',
                    '-font',
                    './media/nulis/font/Indie-Flower.ttf',
                    '-size',
                    '960x1280',
                    '-pointsize',
                    '23',
                    '-interline-spacing',
                    '3',
                    '-annotate',
                    '+89+190',
                    fixHeight,
                    './media/nulis/images/folio/setelahkanan.jpg'
                ])
                .on('error', () => reply(mess.error.api))
                .on('exit', () => {
                    geps.sendMessage(from, fs.readFileSync('./media/nulis/images/folio/setelahkanan.jpg'), image, {
                        quoted: msg,
                        caption: `Jangan malas pak...`
                    })
                    limitAdd(sender, limit)
                })
        }
        break
        case prefix + 'troligc': {
            if (!isOwner && !fromMe) return
            let faketroli = {
                key: {
                    participant: '0@s.whatsapp.net' // Fake sender Jid
                },
                message: {
                    orderMessage: {
                        itemCount: 9999999, // Bug
                        status: 1,
                        surface: 1,
                        message: '?????',
                        orderTitle: '????', // Idk what this does
                        sellerJid: '0@s.whatsapp.net' // Seller
                    }
                }
            }
            for (let i = 0; i < args[1]; i++) {
                geps.sendMessage(from, '?????', MessageType.extendedText, {
                        quoted: faketroli
                    })
                    .then(res => geps.clearMessage(res.key))
            }
        }
        break
        case prefix + 'trolipc': {
            if (!isOwner && !fromMe) return
            let faketroli = {
                key: {
                    fromMe: false,
                    participant: from,
                    remoteJid: from // Fake sender Jid
                },
                message: {
                    orderMessage: {
                        itemCount: 9999999, // Bug
                        status: 1,
                        surface: 1,
                        message: '?????',
                        orderTitle: '????', // Idk what this does
                        sellerJid: '0@s.whatsapp.net' // Seller
                    }
                }
            }
            for (let i = 0; i < args[1]; i++) {
                geps.sendMessage(from, '?????', MessageType.extendedText, {
                        quoted: faketroli
                    })
                    .then(res => geps.clearMessage(res.key))
            }
        }
        break
        case prefix + 'listsw': {
            if (!isOwner && !fromMe) return
            let rapih = []
            let stomries = await geps.getStories()
            let stomries1 = stomries.map(v => v.messages)
            for (let i = 0; i < stomries1.length; i++) {
                let semder = geps.user.jid
                if (!stomries1[i][0].key) {
                    semder = stomries1[i][1].participant
                    stomries1[i].splice(0, 1)
                } else if (!stomries1[i][0].key.fromMe) {
                    semder = stomries1[i][0].participant
                }
                rapih.push({
                    sender: semder,
                    stories: stomries1[i]
                })
            }
            let teg = rapih.map(v => v.sender)
            let tmt = `*LIST STATUS WHATSAPP*\nJumlah sender : ${rapih.length}\n`
            for (let i = 0; i < rapih.length; i++) {
                let mesek = rapih[i].stories
                tmt += `\n${1 + i}. @${rapih[i].sender.split("@")[0]}\n`
                tmt += `=> Jumlah : ${rapih[i].stories.length}\n`
                for (let a = 0; a < mesek.length; a++) {
                    let tipe = Object.keys(mesek[a].message)[0]
                    tmt += `==> ${1 + a}. ${tipe}\n`
                }
            }
            tmt += `\nUntuk mengambil sw, silahkan kirim ${prefix}getsw nomor sender(spasi)nomor sw\n\nContoh : ${prefix}getsw 1 1`
            mentions(tmt, teg, true)
        }
        break
        case prefix + 'getsw': {
            if (!isOwner && !fromMe) return
            if (args.length < 2) return reply(`Penggunaan ${command} nomor sender(spasi)nomor sw\n\nContoh : ${command} 1 1`)
            if (isNaN(args[1])) return reply(`Penggunaan ${command} nomor sender(spasi)nomor sw\n\nContoh : ${command} 1 1`)
            if (isNaN(args[2])) return reply(`Penggunaan ${command} nomor sender(spasi)nomor sw\n\nContoh : ${command} 1 1`)
            try {
                let rapih = []
                let stomries = await geps.getStories()
                let stomries1 = stomries.map(v => v.messages)
                for (let i = 0; i < stomries1.length; i++) {
                    let semder = geps.user.jid
                    if (!stomries1[i][0].key) {
                        semder = stomries1[i][1].participant
                        stomries1[i].splice(0, 1)
                    } else if (!stomries1[i][0].key.fromMe) {
                        semder = stomries1[i][0].participant
                    }
                    rapih.push({
                        sender: semder,
                        stories: stomries1[i]
                    })
                }
                let swnya = rapih[args[1] - 1].stories[args[2] - 1]
                let tipenya = Object.keys(swnya.message)[0]
                if (tipenya == 'extendedTextMessage') {
                    geps.sendMessage(from, swnya.message[tipenya].text, text, {
                        quoted: swnya
                    })
                } else {
                    let media = await geps.downloadMediaMessage(swnya)
                    geps.sendMessage(from, media, tipenya, {
                        quoted: swnya,
                        caption: swnya.message[tipenya].caption
                    })
                }
            } catch (err) {
                console.log(err)
                reply(`SW tidak ditemukan`)
            }
        }
        break
        case prefix + 'resend': {
            if (!isQuotedMsg) return reply(`reply message yang ingin di download`)
            if (!isQuotedImage && !isQuotedVideo) return reply(`Hanya bisa download pesan media`)
            let encmedia = isQuotedMsg ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
            let media = await geps.downloadMediaMessage(encmedia)
            geps.sendMessage(from, media, quotedMsg.type)
        }
        break
        case prefix + 'getpp':
        case prefix + 'getpic':
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Penggunaan ${command} @tag atau 'group'`)
            if (args[1] === 'group') {
                reply(mess.wait)
                try {
                    var pic = await geps.getProfilePicture(from)
                } catch {
                    var pic = 'https://i.ibb.co/Tq7d7TZ/age-hananta-495-photo.png'
                }
                geps.sendImage(from, await getBuffer(pic), 'Nih bang', msg)
                limitAdd(sender, limit)
            } else if (mentioned.length !== 0) {
                reply(mess.wait)
                try {
                    var pic = await geps.getProfilePicture(mentioned[0])
                } catch {
                    var pic = 'https://i.ibb.co/Tq7d7TZ/age-hananta-495-photo.png'
                }
                geps.sendImage(from, await getBuffer(pic), 'Nih bang', msg)
                limitAdd(sender, limit)
            } else {
                reply(`Penggunaan ${command} @tag atau 'group'`)
            }
            break
        case prefix + 'tagme':
            mentions(`@${sender.split("@")[0]} Sayang😚`, [sender], true)
            break
        case prefix + 'kontak':
            if (args.length < 2) return reply(`Penggunaan ${command} nomor|nama\n\nContoh : ${command} 0|Mark asu`)
            if (!q.includes("|")) return reply(`Penggunaan ${command} nomor|nama\n\nContoh : ${command} 0|Mark asu`)
            if (isNaN(q.split("|")[0])) return reply(`Penggunaan ${command} nomor|nama\n\nContoh : ${command} 0|Mark asu`)
            geps.sendContact(from, q.split("|")[0], q.split("|")[1], msg)
            break
        case prefix + 'hidetag': {
            if (!isPremium) return reply(mess.OnlyPrem)
            if (args.length < 2) return reply(`Masukkan text`)
            let arr = [];
            for (let i of groupMembers) {
                arr.push(i.jid)
            }
            mentions(q, arr, false)
        }
        break
        case prefix + 'revokelink':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            await geps.revokeInvite(from)
            mentions(`Link group has been revoke by admin @${sender.replace('@s.whatsapp.net', '')}`, [sender], true)
            break
        case prefix + 'antidelete':
            if (!isOwner && !fromMe && !isGroupAdmins) return reply(mess.GrupAdmin)
            const dataRevoke = JSON.parse(fs.readFileSync('./database/gc-revoked.json'))
            const dataCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked.json'))
            const dataBanCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked-banlist.json'))
            const isRevoke = dataRevoke.includes(from)
            const isCtRevoke = dataCtRevoke.data
            const isBanCtRevoke = dataBanCtRevoke.includes(sender) ? true : false
            if (args.length === 1) return reply(`Penggunaan fitur antidelete :\n\n*${prefix}antidelete [aktif/mati]* (Untuk grup)\n*${prefix}antidelete [ctaktif/ctmati]* (untuk semua kontak)\n*${prefix}antidelete banct 628558xxxxxxx* (banlist kontak)`)
            if (args[1] == 'aktif') {
                if (isGroup) {
                    if (isRevoke) return reply(`Antidelete telah diaktifkan di grup ini sebelumnya!`)
                    dataRevoke.push(from)
                    fs.writeFileSync('./database/gc-revoked.json', JSON.stringify(dataRevoke, null, 2))
                    reply(`Antidelete diaktifkan di grup ini!`)
                } else if (!isGroup) {
                    reply(`Untuk kontak penggunaan *${prefix}antidelete ctaktif*`)
                }
            } else if (args[1] == 'ctaktif') {
                if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
                if (!isGroup) {
                    if (isCtRevoke) return reply(`Antidelete telah diaktifkan di semua kontak sebelumnya!`)
                    dataCtRevoke.data = true
                    fs.writeFileSync('./database/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
                    reply(`Antidelete diaktifkan disemua kontak!`)
                } else if (isGroup) {
                    reply(`Untuk grup penggunaan *${prefix}antidelete aktif*`)
                }
            } else if (args[1] == 'banct') {
                if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
                if (isBanCtRevoke) return reply(`kontak ini telah ada di database banlist!`)
                if (args.length === 2 || args[2].startsWith('0')) return reply(`Masukan nomer diawali dengan 62! contoh 62859289xxxxx`)
                dataBanCtRevoke.push(args[2] + '@s.whatsapp.net')
                fs.writeFileSync('./database/ct-revoked-banlist.json', JSON.stringify(dataBanCtRevoke, null, 2))
                reply(`Kontak ${args[2]} telah dimasukan ke banlist antidelete secara permanen!`)
            } else if (args[1] == 'mati') {
                if (isGroup) {
                    const index = dataRevoke.indexOf(from)
                    dataRevoke.splice(index, 1)
                    fs.writeFileSync('./database/gc-revoked.json', JSON.stringify(dataRevoke, null, 2))
                    reply(`Antidelete dimatikan di grup ini!`)
                } else if (!isGroup) {
                    reply(`Untuk kontak penggunaan *${prefix}antidelete ctmati*`)
                }
            } else if (args[1] == 'ctmati') {
                if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
                if (!isGroup) {
                    dataCtRevoke.data = false
                    fs.writeFileSync('./database/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
                    reply(`Antidelete dimatikan disemua kontak!`)
                } else if (isGroup) {
                    reply(`Untuk grup penggunaan *${prefix}antidelete mati*`)
                }
            }
            break
        case prefix + 'limit':
        case prefix + 'ceklimit':
        case prefix + 'balance':
        case prefix + 'glimit':
            if (mentioned.length !== 0) {
                reply(`Limit : ${_prem.checkPremiumUser(mentioned[0], premium) ? 'Unlimited' : `${getLimit(mentioned[0], limitCount, limit)}/${limitCount}`}\nLimit Game : ${cekGLimit(mentioned[0], gcount, glimit)}/${gcount}\nBalance : $${getBalance(mentioned[0], balance)}\n\nKamu dapat membeli limit dengan ${prefix}buylimit dan ${prefix}buyglimit untuk membeli game limit`)
            } else {
                reply(`Limit : ${isPremium ? 'Unlimited' : `${getLimit(sender, limitCount, limit)}/${limitCount}`}\nLimit Game : ${cekGLimit(sender, gcount, glimit)}/${gcount}\nBalance : $${getBalance(sender, balance)}\n\nKamu dapat membeli limit dengan ${prefix}buylimit dan ${prefix}buyglimit untuk membeli game limit`)
            }
            break
        case prefix + 'owner':
            geps.sendContact(from, ownerNumber.split("@")[0], 'X-MrG3P5', msg)
                .then((res) => geps.sendMessage(from, 'Tuh Nomor Ownerku~', text, {
                    quoted: res
                }))
            break
        case prefix + 'info':
            let data_info = `「 *INFORMATION* 」
                
• BOT Type: NodeJS v14.x.x
• Name: DarkChat-BOT
• Lib: Baileys
• Version: 2.8
• Instagram: mrg3p5_id

*THANKS TO*
• Inisial A:3
• </ LeysCoders >
• Tekajeh TEAM
• Aqulz
• And All creator bot
_Since © 2020_`
            reply(data_info)
            break
        case prefix + 'runtime':
            reply(`${runtime(process.uptime())}`)
            break
        case prefix + 'stats':
        case prefix + 'botstatus':
        case prefix + 'ping':
        case prefix + 'botstat': {
            let totalchat = await geps.chats.all()
            let i = []
            let giid = []
            for (let mem of totalchat) {
                i.push(mem.jid)
            }
            for (let id of i) {
                if (id && id.includes('g.us')) {
                    giid.push(id)
                }
            }
            let timestampi = speed();
            let latensii = speed() - timestampi
            const {
                wa_version,
                mcc,
                mnc,
                os_version,
                device_manufacturer,
                device_model
            } = geps.user.phone
            let anu = process.uptime()
            let teskny = `「 *STATUS-INFORMATION* 」

*SERVER-STATUS*
• *Host:* ${os.hostname()}
• *Platfrom:* ${os.platform()}
• *Speed:* ${os.cpus()[0].speed} MHz
• *Core:* ${os.cpus().length}
• *RAM:* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
• *CPU:* ${os.cpus()[0].model}
• *Release:* ${os.release()}

*BOT-STATUS*
• *V. Whatsapp:* ${wa_version}
• *Baterai:* ${geps.baterai.baterai}%
• *Charge:* ${geps.baterai.cas === 'true' ? 'Ya' : 'Tidak'}
• *MCC:* ${mcc}
• *MNC:* ${mnc}
• *Versi OS:* ${os_version}
• *Merk HP:* ${device_manufacturer}
• *Versi HP:* ${device_model}
• *Group Chat:* ${giid.length}
• *Personal Chat:* ${totalchat.length - giid.length}
• *Total Chat:* ${totalchat.length}
• *Speed:* ${latensii.toFixed(4)} Second
• *Runtime:* ${runtime(anu)}`
            reply(teskny)
        }
        break
        case prefix + 'playmp4': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}playmp4 query*`)
            try {
                reply(mess.wait)
                let yut = await yts(q)
                ytv(yut.videos[0].url)
                    .then((res) => {
                        const {
                            dl_link,
                            thumb,
                            title,
                            filesizeF,
                            filesize
                        } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                            .then((a) => {
                                if (Number(filesize) >= 40000) return sendFileFromUrl(from, thumb, `「 *PLAYING-YTMP4* 」

*Data Berhasil Didapatkan!*

• Title: ${title}
• Ext: MP4
• Filesize: ${filesizeF}
• ID: ${yut.videos[0].videoId}
• Upload: ${yut.videos[0].ago}
• Ditonton: ${yut.videos[0].views}
• Duration: ${yut.videos[0].timestamp}
• Link: ${a.data}

_Untuk durasi lebih dari batas disajikan dalam bentuk link_`, msg)
                                const captionisu = `「 *PLAYING-YTMP4* 」

*Data Berhasil Didapatkan!*

• Title: ${title}
• Ext: MP4
• Size: ${filesizeF}
• ID: ${yut.videos[0].videoId}
• Upload: ${yut.videos[0].ago}
• Ditonton: ${yut.videos[0].views}
• Duration: ${yut.videos[0].timestamp}
• URL: ${yut.videos[0].url}

_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
                                sendFileFromUrl(from, thumb, captionisu, msg)
                                sendFileFromUrl(from, dl_link, '', msg)
                                limitAdd(sender, limit)
                            })
                    })
                    .catch((err) => reply(`${err}`))
            } catch (err) {
                console.log(color('[PlayMp4]', 'red'), err)
                reply(mess.error.api)
            }
        }
        break
        case prefix + 'play':
        case prefix + 'playmp3': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length === 1) return reply(`Kirim perintah *${prefix}play query*`)
            try {
                reply(mess.wait)
                let yut = await yts(q)
                yta(yut.videos[0].url)
                    .then((res) => {
                        const {
                            dl_link,
                            thumb,
                            title,
                            filesizeF,
                            filesize
                        } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                            .then((a) => {
                                if (Number(filesize) >= 30000) return sendFileFromUrl(from, thumb, `「 *PLAYING-YTMP3* 」

*Data Berhasil Didapatkan!*

• Title: ${title}
• Ext: MP3
• Filesize: ${filesizeF}
• ID: ${yut.videos[0].videoId}
• Upload: ${yut.videos[0].ago}
• Ditonton: ${yut.videos[0].views}
• Duration: ${yut.videos[0].timestamp}
• Link: ${a.data}

_Untuk durasi lebih dari batas disajikan dalam bentuk link_`, msg)
                                const captionis = `「 *PLAYING-YTMP3* 」

*Data Berhasil Didapatkan!*

• Title: ${title}
• Ext: MP3
• Size: ${filesizeF}
• ID: ${yut.videos[0].videoId}
• Upload: ${yut.videos[0].ago}
• Ditonton: ${yut.videos[0].views}
• Duration: ${yut.videos[0].timestamp}
• URL: ${yut.videos[0].url}

_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
                                sendFileFromUrl(from, thumb, captionis, msg)
                                sendFileFromUrl(from, dl_link, '', msg)
                                limitAdd(sender, limit)
                            })
                    })
            } catch (err) {
                console.log(color('[PlayMp3]', 'red'), err)
                reply(mess.error.api)
            }
        }
        break
        case prefix + 'ig':
        case prefix + 'igdl':
        case prefix + 'instagram': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}ig* link ig`)
            if (!isUrl(args[1]) && !args[1].includes('instagram.com')) return reply(mess.error.Iv)
            fetch("https://instasave.website/download#downloadhere", {
                    "credentials": "include",
                    "headers": {
                        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0",
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Upgrade-Insecure-Requests": "1"
                    },
                    "referrer": "https://instasave.website/",
                    "body": `link=${q}&submit=`,
                    "method": "POST",
                    "mode": "cors"
                }).then((res) => res.text())
                .then((text) => {
                    const $ = cheerio.load(text)
                    const url__ = $('#downloadBox > a:nth-child(3)').attr('href');
                    reply(mess.wait)
                    sendFileFromUrl(from, url__, 'nih', msg)
                    limitAdd(sender, limit)
                })
                .catch((err) => {
                    console.log(color('[IG Download]', 'red'), err)
                    reply(mess.error.api)
                })
        }
        break
        case prefix + 'npmjs':
            if (!q) return reply(`Kirim perintah ${prefix}npmjs *query*\nContoh: ${prefix}npmjs axios`)
            axios.get(`https://www.npmjs.com/search/suggestions?q=${q}`).then(x => {
                let listnpm = "*「 NPMJS-SEARCH 」*\n\n"
                for (let y = 0; y < x.data.length; y++) {
                    listnpm += `• *Name:* ${x.data[y].name}\n• *Scope:* ${x.data[y].scope}\n• *Publisher:* ${x.data[y].publisher.username}\n• *Link:* ${x.data[y].links.npm}\n• *Date:* ${x.data[y].date}\n• *Description:* ${x.data[y].description}\n\n`
                }
                sendFileFromUrl(from, "https://static.npmjs.com/5f6e93af5bf0f5dcdd1eecdac99f51ee.png", listnpm.trim(), msg)
            }).catch((err) => {
                console.log(color('[Npmjs]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'fb':
        case prefix + 'fbdl':
        case prefix + 'facebook': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}fb* url`)
            if (!isUrl(args[1]) && !args[1].includes('facebook.com')) return reply(mess.error.Iv)
            reply(mess.wait)
            fbdl(args[1])
                .then((res) => {
                    sendFileFromUrl(from, res.result.links[0].url)
                    limitAdd(sender, limit)
                })
                .catch((err) => {
                    console.log(color('[FB]', 'red'), err)
                    reply(mess.error.api)
                })
        }
        break
        case prefix + 'yts':
        case prefix + 'ytsearch': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah ${prefix}ytsearch *query*`)
            reply(mess.wait)
            yts(q)
                .then((res) => {
                    let yt = res.videos
                    let txt = `「 *YOUTUBE-SEARCH* 」

*Data Berhasil Didapatkan!*
*Hasil Pencarian : ${q}*\n\n`
                    for (let i = 0; i < 10; i++) {
                        txt += `• *Judul:* ${yt[i].title}\n• *ID:* ${yt[i].videoId}\n• *Upload:* ${yt[i].ago}\n• *Ditonton:* ${yt[i].views}\n• *Duration:* ${yt[i].timestamp}\n• *URL:* ${yt[i].url}\n\n`
                    }
                    sendFileFromUrl(from, yt[0].image, txt.trim(), msg)
                    limitAdd(sender, limit)
                })
                .catch((err) => {
                    console.log(color('[YT SEARCH]', 'red'), err)
                    reply(mess.error.api)
                })
        }
        break
        case prefix + 'ghstalk':
        case prefix + 'githubstalk':
        case prefix + 'ghuser': {
            if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply(`Limit kamu sudah habis silahkan kirim ${prefix}limit untuk mengecek limit`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}ghstalk* _username_`)
            reply(mess.wait)
            axios.get(`https://api.github.com/users/${args[1]}`)
                .then((res) => res.data)
                .then((res) => {
                    let {
                        login,
                        type,
                        name,
                        followers,
                        following,
                        created_at,
                        updated_at,
                        public_gists,
                        public_repos,
                        twitter_username,
                        bio,
                        hireable,
                        email,
                        location,
                        blog,
                        company,
                        avatar_url,
                        html_url
                    } = res
                    let txt = `「 *GITHUB-STALKING* 」

*Data Berhasil Didapatkan!*

• Username: ${login}
• Name: ${name ? name : '-'}
• Followers: ${followers}
• Following: ${following}
• Created at:  ${moment(created_at).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
• Updated at: ${moment(updated_at).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}
• Public Gists: ${public_gists ? public_gists : '-'}
• Public Repos: ${public_repos ? public_repos : '-'}
• Twitter: ${twitter_username ? twitter_username : '-'}
• Email: ${email ? email : '-'}
• Location: ${location ? location : '-'}
• Blog: ${blog ? blog : '-'}
• Link: ${html_url ? html_url : '-'}
• Bio: ${bio ? bio : '-'}`
                    sendFileFromUrl(from, avatar_url, txt, msg)
                    limitAdd(sender, limit)
                })
                .catch((err) => {
                    console.log(color('[GH Stalk]', 'red'), err)
                    reply(mess.error.api)
                })
        }
        break
        case prefix + 'sewa':
            if (isGroup) return reply(`Untuk membuat pesanan sewa silahkan chat bot di private wa.me/${geps.user.jid.replace(/@.+/g, '')}`)
            if (!fs.existsSync(sewaPath + '/' + sender + '.json')) {
                if (args[1] == 'batal') {
                    let pathsewa_ = fs.readFileSync(sewaPath + '/' + sender + '.json');
                    sendMess(ownerNumber, `「 PESANAN-SEWA-GROUP 」

${monospace(`Nama        : ${pathsewa_.name.trim()}
Nomor       : wa.me/${pathsewa_.number.split('@')[0]}
Waktu Sewa  : ${pathsewa_.data.month} Bulan
Total Harga : Rp. ${toRupiah(pathsewa_.data.month * 10000)}
ID          : ${data_pathsewa_sewa.ID}
Status      : Di Batalkan
Link Group  : ${pathsewa_.data.grouplink}`)}`)
                    fs.unlinkSync(sewaPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan sewa bot telah dibatalkan 😉`)
                } else {
                    let objsewa = {
                        status: false,
                        ID: require('crypto').randomBytes(8).toString("hex").toUpperCase(),
                        session: 'name',
                        name: pushname,
                        created_at: new Date(),
                        number: sender,
                        data: {
                            name: '',
                            month: '',
                            phone: '',
                            grouplink: ''
                        }
                    }
                    let dataID = JSON.parse(fs.readFileSync(sewaPath + '/ids-match.json'))
                    dataID.push({
                        SID: objsewa['ID'],
                        PAID: '',
                        data: objsewa
                    })
                    fs.writeFileSync(sewaPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.writeFile(sewaPath + '/' + sender + '.json', JSON.stringify(objsewa, null, 3), () => {
                        reply(`Baik kak silahkan ketik disini atas nama siapa 😊`)
                    })
                }
            } else {
                if (args[1] == 'batal') {
                    let data_sewa = JSON.parse(fs.readFileSync(sewaPath + '/' + sender + '.json'))
                    let dataID = JSON.parse(fs.readFileSync(sewaPath + '/ids-match.json'))
                    let indexData_sewa = dataID.findIndex(r => r['ID'] == data_sewa['ID'])
                    sendMess(ownerNumber, `「 PESANAN-SEWA-GROUP 」

${monospace(`Nama        : ${data_sewa.name.trim()}
Nomor       : wa.me/${data_sewa.number.split('@')[0]}
Waktu Sewa  : ${data_sewa.data.month} Bulan
Total Harga : Rp. ${toRupiah(data_sewa.data.month * 10000)}
ID          : ${data_sewa.ID}
Status      : Di Batalkan
Link Group  : ${data_sewa.data.grouplink}`)}`)
                    dataID.splice(indexData_sewa, 1)
                    fs.writeFileSync(sewaPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.unlinkSync(sewaPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan sewa bot telah dibatalkan 😉`)
                } else {
                    geps.sendMessage(from, `Maaf anda sedang ada didalam sesi pembayaran, untuk membatalkannya ketik *!sewa batal*\n\nUntuk lebih jelasnya atau apabila ada kendala silahkan hubungi : @${ownerNumber.replace(/@.+/g, '')}`, MessageType.text, {
                        quoted: msg,
                        contextInfo: {
                            mentionedJid: [ownerNumber]
                        }
                    })
                }
            }
            break
        case prefix + 'buyprem':
        case prefix + 'buypremium':
            if (isGroup) return reply(`Untuk membuat pesanan sewa silahkan chat bot di private wa.me/${geps.user.jid.replace(/@.+/g, '')}`)
            if (!fs.existsSync(PremiumPath + '/' + sender + '.json')) {
                if (args[1] == 'batal') {
                    let pathsewa_ = fs.readFileSync(PremiumPath + '/' + sender + '.json');
                    sendMess(ownerNumber, `「 *PESANAN-PREMIUM* 」

${monospace(`Nama        : ${pathsewa_.name.trim()}
Nomor       : wa.me/${pathsewa_.number.split('@')[0]}
Waktu Sewa  : ${pathsewa_.data.month} Bulan
Total Harga : Rp. ${toRupiah(pathsewa_.data.month * 10000)}
ID          : ${data_pathsewa_sewa.ID}
Status      : Di Batalkan`)}`)
                    fs.unlinkSync(PremiumPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan sewa bot telah dibatalkan 😉`)
                } else {
                    let objsewa = {
                        status: false,
                        ID: require('crypto').randomBytes(8).toString("hex").toUpperCase(),
                        session: 'name',
                        name: pushname,
                        created_at: new Date(),
                        number: sender,
                        data: {
                            name: '',
                            month: '',
                            phone: ''
                        }
                    }
                    let dataID = JSON.parse(fs.readFileSync(PremiumPath + '/ids-match.json'))
                    dataID.push({
                        SID: objsewa['ID'],
                        PAID: '',
                        data: objsewa
                    })
                    fs.writeFileSync(PremiumPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.writeFile(PremiumPath + '/' + sender + '.json', JSON.stringify(objsewa, null, 3), () => {
                        reply(`Baik kak silahkan ketik disini atas nama siapa 😊`)
                    })
                }
            } else {
                if (args[1] == 'batal') {
                    let data_sewa = JSON.parse(fs.readFileSync(PremiumPath + '/' + sender + '.json'))
                    let dataID = JSON.parse(fs.readFileSync(PremiumPath + '/ids-match.json'))
                    let indexData_sewa = dataID.findIndex(r => r['ID'] == data_sewa['ID'])
                    sendMess(ownerNumber, `「 *PESANAN-PREMIUM* 」

${monospace(`Nama        : ${data_sewa.name.trim()}
Nomor       : wa.me/${data_sewa.number.split('@')[0]}
Waktu Sewa  : ${data_sewa.data.month} Bulan
Total Harga : Rp. ${toRupiah(data_sewa.data.month * 10000)}
ID          : ${data_sewa.ID}
Status      : Di Batalkan`)}`)
                    dataID.splice(indexData_sewa, 1)
                    fs.writeFileSync(PremiumPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.unlinkSync(PremiumPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan sewa bot telah dibatalkan 😉`)
                } else {
                    geps.sendMessage(from, `Maaf anda sedang ada didalam sesi pembayaran, untuk membatalkannya ketik *!sewa batal*\n\nUntuk lebih jelasnya atau apabila ada kendala silahkan hubungi : @${ownerNumber.replace(/@.+/g, '')}`, MessageType.text, {
                        quoted: msg,
                        contextInfo: {
                            mentionedJid: [ownerNumber]
                        }
                    })
                }
            }
            break
        case prefix + 'addsewa':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}addsewa* linkgc waktu`)
            let ceh = await geps.cekInviteCode(args[1].replace('https://chat.whatsapp.com/', ''))
            if (ceh.status === 200) {
                geps.acceptInvite(args[1].replace('https://chat.whatsapp.com/', ''))
                    .then((res) => {
                        _sewa.addSewaGroup(res.gid, args[2], sewa)
                        reply(`Bot akan segera masuk`).then(() => {
                            let brp_exp = ms(Date.now() + toMs(args[2]) - Date.now())
                            geps.sendMessage(res.gid, `Halo, waktu sewa bot telah ditambahkan di grup ${ceh.subject} untuk ${brp_exp.days} day(s) ${brp_exp.hours} hour(s) ${brp_exp.minutes} minute(s) ${brp_exp.seconds} second(s)\n\n_have a nice day 😉🎇_`, text)
                        })
                    })
            } else {
                reply(`link salah`)
            }
            break
        case prefix + 'delsewa':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}delprem* idgroup`)
            sewa.splice(_sewa.getSewaPosition(args[1], sewa), 1)
            fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa))
            reply(`Sukses lur`)
            break
        case prefix + 'premium':
        case prefix + 'buyprem':
        case prefix + 'daftarprem':
        case prefix + 'daftarprem':
            // if (isGroup) return reply(`Untuk membuat pesanan premium silahkan chat bot di private wa.me/${geps.user.jid.replace(/@.+/g, '')}`)
            if (!fs.existsSync(PremiumPath + '/' + sender + '.json')) {
                if (args[1] == 'batal') {
                    fs.unlinkSync(PremiumPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan jadi premium telah dibatalkan 😉`)
                } else {
                    let objsewa = {
                        status: false,
                        ID: require('crypto').randomBytes(8).toString("hex").toUpperCase(),
                        session: 'name',
                        name: pushname,
                        created_at: new Date(),
                        number: sender,
                        data: {
                            name: '',
                            bulan: '',
                            payment: '',
                            phone: '',
                        }
                    }
                    let dataID = JSON.parse(fs.readFileSync(PremiumPath + '/ids-match.json'))
                    dataID.push({
                        SID: objsewa['ID'],
                        PAID: '',
                        data: objsewa
                    })
                    fs.writeFileSync(PremiumPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.writeFile(PremiumPath + '/' + sender + '.json', JSON.stringify(objsewa, null, 3), () => {
                        reply(`Baik kak silahkan ketik disini atas nama siapa 😊`)
                    })
                }
            } else {
                if (args[1] == 'batal') {
                    let data_sewa = JSON.parse(fs.readFileSync(PremiumPath + '/' + sender + '.json'))
                    let dataID = JSON.parse(fs.readFileSync(PremiumPath + '/ids-match.json'))
                    let indexData_sewa = dataID.findIndex(r => r['ID'] == data_sewa['ID'])
                    dataID.splice(indexData_sewa, 1)
                    fs.writeFileSync(PremiumPath + '/ids-match.json', JSON.stringify(dataID, null, 3))
                    fs.unlinkSync(PremiumPath + '/' + sender + '.json')
                    reply(`Oke kak pesanan premium bot telah dibatalkan 😉`)
                } else {
                    geps.sendMessage(from, `Maaf anda sedang ada didalam sesi pembayaran, untuk membatalkannya ketik *!premium batal*\n\nUntuk lebih jelasnya atau apabila ada kendala silahkan hubungi : @${ownerNumber.replace(/@.+/g, '')}`, MessageType.text, {
                        quoted: msg,
                        contextInfo: {
                            mentionedJid: [ownerNumber]
                        }
                    })
                }
            }
            break
        case prefix + 'addprem':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}addprem* @tag waktu\n*${prefix}addprem* nomor waktu`)
            if (mentioned.length !== 0) {
                _prem.addPremiumUser(mentioned[0], args[2], premium)
                reply('Sukses')
            } else {
                _prem.addPremiumUser(args[1] + '@s.whatsapp.net', args[2], premium)
                reply('Sukses')
            }
            break
        case prefix + 'delprem':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Penggunaan :\n*${prefix}delprem* @tag\n*${prefix}delprem* nomor`)
            if (mentioned.length !== 0) {
                for (let i = 0; i < mentioned.length; i++) {
                    premium.splice(_prem.getPremiumPosition(mentioned[i], premium), 1)
                    fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
                }
                reply('Sukses')
            } else {
                premium.splice(_prem.getPremiumPosition(args[1] + '@s.whatsapp.net', premium), 1)
                fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
            }
            break
        case prefix + 'cekprem':
        case prefix + 'cekpremium':
            if (!isPremium) return reply(`Kamu bukan user premium, kirim perintah *${prefix}daftarprem* untuk membeli premium`)
            let cekvip = ms(_prem.getPremiumExpired(sender, premium) - Date.now())
            let premiumnya = `*Expire :* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s)`
            reply(premiumnya)
            break
        case prefix + 'listprem':
        case prefix + 'listpremium':
            let txt = `「 *LIST-PREMIUM* 」\n\nJumlah : ${premium.length}\n\n`
            let men = [];
            for (let i of premium) {
                men.push(i.id)
                let cekvip = ms(i.expired - Date.now())
                txt += `• *ID:* @${i.id.split("@")[0]}\n• *Expire:* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s) ${cekvip.seconds} second(s)\n\n`
            }
            mentions(txt, men, true)
            break
        case prefix + 'ban':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (mentioned.length !== 0) {
                for (let i = 0; i < mentioned.length; i++) {
                    addBanned(mentioned[0], args[2], ban)
                }
                reply('Sukses')
            } else if (isQuotedMsg) {
                if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa ban Owner`)
                addBanned(quotedMsg.sender, args[1], ban)
                reply(`Sukses ban target`)
            } else if (!isNaN(args[1])) {
                addBanned(args[1] + '@s.whatsapp.net', args[2], ban)
                reply('Sukses')
            } else {
                reply(`Kirim perintah ${prefix}ban @tag atau nomor atau reply pesan orang yang ingin di ban`)
            }
            break
        case prefix + 'unban':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (mentioned.length !== 0) {
                for (let i = 0; i < mentioned.length; i++) {
                    unBanned(mentioned[i], ban)
                }
                reply('Sukses')
            }
            if (isQuotedMsg) {
                unBanned(quotedMsg.sender, ban)
                reply(`Sukses unban target`)
            } else if (!isNaN(args[1])) {
                unBanned(args[1] + '@s.whatsapp.net', ban)
                reply('Sukses')
            } else {
                reply(`Kirim perintah ${prefix}unban @tag atau nomor atau reply pesan orang yang ingin di unban`)
            }
            break
        case prefix + 'listban':
            let txtx = `「 *LIST-BANNED* 」\n\nJumlah : ${ban.length}\n\n`
            let menx = [];
            for (let i of ban) {
                menx.push(i.id)
                txtx += `• *ID:* @${i.id.split("@")[0]}\n`
                if (i.expired === 'PERMANENT') {
                    let cekvip = 'PERMANENT'
                    txtx += `*Expire :* PERMANENT\n\n`
                } else {
                    let cekvip = ms(i.expired - Date.now())
                    txtx += `• *Expire:* ${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s) ${cekvip.seconds} second(s)\n\n`
                }
            }
            mentions(txtx, menx, true)
            break
        case prefix + 'topglobal': {
            balance.sort((a, b) => (a.balance < b.balance) ? 1 : -1)
            let top = '*── 「 TOPGLOBAL 」 ──*\n\n'
            let arrTop = []
            for (let i = 0; i < 10; i++) {
                top += `${i + 1}. @${balance[i].id.split("@")[0]}\n• *Balance:* $${balance[i].balance}\n\n`
                arrTop.push(balance[i].id)
            }
            mentions(top, arrTop, true)
        }
        break
        case prefix + 'toplocal': {
            balance.sort((a, b) => (a.balance < b.balance) ? 1 : -1)
            let top = '*── 「 TOPLOCAL 」 ──*\n\n'
            let arrTop = []
            let anggroup = groupMembers.map(a => a.jid)
            for (let i = 0; i < balance.length; i++) {
                if (arrTop.length >= 10) continue
                if (anggroup.includes(balance[i].id)) {
                    top += `${i + 1}. @${balance[i].id.split("@")[0]}\n=> Balance : $${balance[i].balance}\n\n`
                    arrTop.push(balance[i].id)
                }
            }
            mentions(top, arrTop, true)
        }
        break
        case prefix + 'buylimit': {
            if (global.geps.user.jid !== geps.user.jid) return reply('Tidak melakukan command ini di dalam bot!\n\nhttps://wa.me/' + global.geps.user.jid.split `@` [0] + `?text=${command}`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}buylimit* jumlah limit yang ingin dibeli\n\nContoh : ${command} 5\n\nHarga 1 limit = $100 balance`)
            if (args[1].includes('-')) return reply(body.replace(args[1], "*" + args[1] + "*") + '\n\n' + 'Jangan menggunakan -' + `\nContoh : ${command} 5`)
            if (isNaN(args[1])) return reply(body.replace(args[1], "*" + args[1] + "*") + '\n\n' + 'Pembelian limit harus berupa angka' + `\nContoh : ${command} 5`)
            let ane = Number(nebal(args[1]) * 100)
            if (getBalance(sender, balance) < ane) return reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
            kurangBalance(sender, ane, balance)
            giveLimit(sender, nebal(args[1]), limit)
            reply(monospace(`Pembeliaan limit sebanyak ${args[1]} berhasil\n\nSisa Balance : $${getBalance(sender, balance)}\nSisa Limit : ${getLimit(sender, limitCount, limit)}/${limitCount}`))
        }
        break
        case prefix + 'buygamelimit':
        case prefix + 'buyglimit': {
            if (global.geps.user.jid !== geps.user.jid) return reply('Tidak melakukan command ini di dalam bot!\n\nhttps://wa.me/' + global.geps.user.jid.split `@` [0] + `?text=${command}`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}buyglimit* jumlah game limit yang ingin dibeli\n\nContoh : ${command} 5\n\nHarga 1 limit = $100 balance`)
            if (args[1].includes('-')) return reply(body.replace(args[1], "*" + args[1] + "*") + '\n\n' + 'Jangan menggunakan -' + `\nContoh : ${command} 5`)
            if (isNaN(args[1])) return reply(body.replace(args[1], "*" + args[1] + "*") + '\n\n' + 'Pembelian limit harus berupa angka' + `\nContoh : ${command} 5`)
            let ane = Number(nebal(args[1]) * 100)
            if (getBalance(sender, balance) < ane) return reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
            kurangBalance(sender, ane, balance)
            givegame(sender, nebal(args[1]), glimit)
            reply(monospace(`Pembeliaan game limit sebanyak ${args[1]} berhasil\n\nSisa Balance : $${getBalance(sender, balance)}\nSisa Game Limit : ${cekGLimit(sender, gcount, glimit)}/${gcount}`))
        }
        break
        case prefix + 'tictactoe':
        case prefix + 'ttt':
        case prefix + 'ttc':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (isGame(sender, isOwner, gcount, glimit)) return reply(`Limit game kamu sudah habis`)
            if (isTicTacToe(from, tictactoe)) return reply(`Masih ada game yg blum selesai`)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}tictactoe* @tag`)
            if (mentioned.length !== 0) {
                if (mentioned[0] === sender) return reply(`Sad amat main ama diri sendiri`)
                let h = randomNomor(100)
                mentions(monospace(`@${sender.split('@')[0]} menantang @${mentioned[0].split('@')[0]} untuk bermain TicTacToe\n\nKirim (Y/T) untuk bermain\n\nHadiah : ${h} balance`), [sender, mentioned[0]], false)
                tictactoe.push({
                    id: from,
                    status: null,
                    hadiah: h,
                    penantang: sender,
                    ditantang: mentioned[0],
                    TicTacToe: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']
                })
                gameAdd(sender, glimit)
            } else {
                reply(`Kirim perintah *${prefix}tictactoe* @tag`)
            }
            break
        case prefix + 'delttt':
        case prefix + 'delttc':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isTicTacToe(from, tictactoe)) return reply(`Tidak ada sesi game tictactoe di grup ini`)
            tictactoe.splice(getPosTic(from, tictactoe), 1)
            reply(`Berhasil menghapus sesi tictactoe di grup ini`)
            break
        case prefix + 'tebakgambar':
            if (isGame(sender, isOwner, gcount, glimit)) return reply(`Limit game kamu sudah habis`)
            if (game.isTebakGambar(from, tebakgambar)) return reply(`Masih ada soal yang belum di selesaikan`)
            tebak_gambar().then(anu => {
                let anih = anu.jawaban.toLowerCase()
                console.log(anu.jawaban)
                game.addgambar(from, anih, gamewaktu, tebakgambar)
                const petunjuk = anu.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
                sendFileFromUrl(from, anu.img, monospace(`Silahkan jawab soal berikut ini\n\nPetunjuk : ${petunjuk}\nWaktu : ${gamewaktu}s`), msg)
                gameAdd(sender, glimit)
            })
            break
        case prefix + 'listbot': {
            let arrayBot = [];
            let tmx = `「 *LIST-BOT* 」\n\n`
            tmx += `• *Nomor:* @${global.geps.user.jid.split("@")[0]}\n`
            tmx += `• *Prefix:* ${global.geps.multi ? 'MULTI PREFIX' : global.geps.nopref ? 'NO PREFIX' : global.geps.prefa}\n`
            tmx += `• *Status:* ${global.geps.mode.toUpperCase()}\n\n`
            arrayBot.push(global.geps.user.jid)
            for (let i of conns) {
                tmx += `• *Nomor:* @${i.user.jid.split("@")[0]}\n`
                tmx += `• *Prefix:* ${i.multi ? 'MULTI PREFIX' : i.nopref ? 'NO PREFIX' : i.prefa}\n`
                tmx += `• *Status:* ${i.mode.toUpperCase()}\n\n`
                arrayBot.push(i.user.jid)
            }
            tmx += `Total : ${conns.length + 1}`
            mentions(tmx, arrayBot, true)
        }
        break
        case prefix + 'stopjadibot': {
            if (global.geps.user.jid == geps.user.jid) geps.reply(from, 'Kenapa nggk langsung ke terminalnya?', msg)
            else {
                await geps.reply(from, 'Bye...', msg).then(() => geps.close())
            }
        }
        break
        case prefix + 'getcode': {
            if (global.geps.user.jid == geps.user.jid) geps.reply(from, 'Command ini hanya untuk yang jadi bot', msg)
            else global.geps.reply(geps.user.jid, `${prefix}jadibot ${Buffer.from(JSON.stringify(geps.base64EncodedAuthInfo())).toString('base64')}`, msg)
        }
        break
        case prefix + 'jadibot': {
            if (!isPremium) return reply(mess.OnlyPrem)
            let parent = args[1] && args[1] == 'plz' ? geps : global.geps
            let auth = false
            if (global.conns.length >= 4) return reply(`Maaf maksimal bot adalah 5, coba lain kali`)
            if ((args[0] && args[0] == 'plz') || global.geps.user.jid == geps.user.jid || geps.user.jid == ownerNumber) {
                let id = global.conns.length
                let conn = new global.geps.constructor()
                conn.multi = true
                conn.nopref = false
                conn.prefa = 'anjing'
                if (args[1] && args[1].length > 200) {
                    let json = Buffer.from(args[1], 'base64').toString('utf-8')
                    // global.conn.reply(m.isGroup ? m.sender : m.chat, json, m)
                    let obj = JSON.parse(json)
                    await conn.loadAuthInfo(obj)
                    auth = true
                    conn.multi = false
                    conn.nopref = false
                    conn.prefa = args[2] ? args[2] : 'z'
                }
                conn.mode = 'self'
                conn.spam = []
                conn.baterai = {
                    baterai: 0,
                    cas: false
                };
                conn.logger.level = 'warn'
                conn.browserDescription = ['MacOs', 'Desktop', '3.0']
                conn.on('qr', async qr => {
                    qrcode.toDataURL(qr, {
                        scale: 8
                    }, async (err, Durl) => {
                        const data = Durl.replace(/^data:image\/png;base64,/, '')
                        const bufferDataQr = new Buffer.from(data, 'base64');
                        let scan = await parent.sendImage(from, bufferDataQr, 'Scan QR ini untuk jadi bot sementara\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \nQR Expired dalam 20 detik', msg)
                        setTimeout(() => {
                            parent.deleteMessage(from, scan.key)
                        }, 30000)
                    })
                })
                conn.connect().then(async ({
                    user
                }) => {
                    parent.reply(from, `Berhasil tersambung dengan WhatsApp - mu.\nSekarang kamu berada di mode self, kirim ${prefix}public untuk pindah ke mode public\n*NOTE: Ini cuma numpang*\n` + JSON.stringify(user, null, 2), msg)
                    if (auth) return
                    await parent.sendMessage(user.jid, `Kamu bisa login tanpa qr dengan pesan dibawah ini. untuk mendapatkan kode lengkapnya, silahkan kirim *${prefix}getcode* untuk mendapatkan kode yang akurat`, MessageType.extendedText)
                    parent.sendMessage(user.jid, `${command} ${Buffer.from(JSON.stringify(conn.base64EncodedAuthInfo())).toString('base64')}`, MessageType.extendedText)
                })
                conn.on('chat-update', async (qul) => {
                    if (!qul.hasNewMessage) return
                    qul = qul.messages.all()[0]
                    // Anti oversized
                    if (qul.messageStubType) {
                        if (qul.messageStubType == 68) {
                            geps.modifyChat(qul.key.remoteJid, 'clear')
                        }
                    }

                    if (!qul.message) return
                    if (qul.key && qul.key.remoteJid == 'status@broadcast') return
                    let msg = serialize(conn, qul)
                    // Detect Troli
                    if (msg.message && msg.isBaileys && msg.isQuotedMsg && msg.quotedMsg.type === 'orderMessage') {
                        geps.clearMessage(msg.key)
                    }
                    module.exports(conn, msg, blocked, _afk, welcome, left)
                })
                conn.on('message-delete', async (json) => {
                    require('./antidelete')(conn, json)
                })
                conn.on('CB:action,,battery', json => {
                    const a = json[2][0][1].value
                    const b = json[2][0][1].live
                    conn.baterai.baterai = a
                    conn.baterai.cas = b
                })
                conn.regenerateQRIntervalMs = null
                setTimeout(() => {
                    if (conn.user) return
                    conn.close()
                    let i = global.conns.indexOf(conn)
                    if (i < 0) return
                    delete global.conns[i]
                    global.conns.splice(i, 1)
                }, 60000)
                conn.on('close', () => {
                    setTimeout(async () => {
                        try {
                            if (conn.state != 'close') return
                            if (conn.user && conn.user.jid)
                                parent.sendMessage(conn.user.jid, `Koneksi terputus...`, MessageType.extendedText)
                            let i = global.conns.indexOf(conn)
                            if (i < 0) return
                            delete global.conns[i]
                            global.conns.splice(i, 1)
                        } catch (e) {
                            conn.logger.error(e)
                        }
                    }, 30000)
                })
                global.conns.push(conn)
            } else {
                reply('Tidak bisa membuat bot didalam bot!\n\nhttps://wa.me/' + global.geps.user.jid.split `@` [0] + '?text=#jadibot')
            }
        }
        break
        case prefix + 'resetlimit':
            if (!isOwner) return reply(mess.OnlyOwner)
            let ovb = []
            fs.writeFileSync('./database/limit.json', JSON.stringify(ovb, null, 2))
            fs.writeFileSync('./database/glimit.json', JSON.stringify(ovb, null, 2))
            reply(`Done`)
            break
        case prefix + 'addchangelog':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}addchangelog* Judul|Isi change log`)
            if (!q.includes('|')) return reply(`Kirim perintah *${prefix}addchangelog* Judul|Isi change log`)
            let obj = {
                Judul: q.split('|')[0],
                Waktu: Date.now(),
                Perubahan: q.split('|')[1]
            }
            changelog.push(obj)
            fs.writeFileSync('./database/changelog.json', JSON.stringify(changelog, null, 2))
            reply(`berhasil, silahkan cek di ${prefix}changelog`)
            break
        case prefix + 'update':
        case prefix + 'changelog':
            changelog.sort((a, b) => (a.Waktu < b.Waktu) ? 1 : -1)
            let cha = `「 *CHANGELOG-BOT* 」\n\n`
            for (let i = 0; i < changelog.length; i++) {
                cha += `• *Judul:* ${changelog[i].Judul}\n• *Waktu:* ${moment(changelog[i].Waktu).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n• *Perubahan:* ${changelog[i].Perubahan}\n\n`
            }
            reply(cha.trim())
            break
        case prefix + 'sendbug':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Penggunaan ${command} idgroup`)
            geps.sendBugGC(args[1], WA_DEFAULT_EPHEMERAL)
            geps.sendBugGC(args[1], 0)
            geps.sendBugGC(args[1], 999)
            reply('done owner')
            break
        case prefix + 'self': {
            if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
            geps.mode = 'self'
            reply('Berhasil berubah ke mode self')
        }
        break
        case prefix + 'publik':
        case prefix + 'public': {
            if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
            geps.mode = 'public'
            reply('Berhasil berubah ke mode public')
        }
        break
        case prefix + 'clearall': {
            if (!isOwner) return reply(mess.OnlyOwner)
            let chiit = await geps.chats.all()
            for (let i of chiit) {
                geps.modifyChat(i.jid, 'clear', {
                    includeStarred: false
                })
            }
            reply(`Selesai`)
        }
        break
        case prefix + 'setprefix':
            if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Masukkan prefix\nOptions :\n=> multi\n=> nopref`)
            if (q === 'multi') {
                geps.multi = true
                reply(`Berhasil mengubah prefix ke ${q}`)
            } else if (q === 'nopref') {
                geps.multi = false
                geps.nopref = true
                reply(`Berhasil mengubah prefix ke ${q}`)
            } else {
                geps.multi = false
                geps.nopref = false
                geps.prefa = `${q}`
                reply(`Berhasil mengubah prefix ke ${q}`)
            }
            break
        case prefix + 'bc':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Masukkan text`)
            const timer = ms => new Promise(res => setTimeout(res, ms))
            if (isImage || isQuotedImage) {
                let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadMediaMessage(encmedia)
                async function broadcast_Image() {
                    for (let i of pendaftar) {
                        geps.sendMessage(i, media, image, {
                            caption: q
                        })
                        await timer(3000)
                    }
                }
                broadcast_Image()
                reply(`Sukses Broadcast ke *${pendaftar.length}* user!`)
            } else if (isVideo || isQuotedVideo) {
                let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadMediaMessage(encmedia)
                async function broadcast_video() {
                    for (let i of pendaftar) {
                        geps.sendMessage(i, media, video, {
                            caption: q
                        })
                        await timer(3000)
                    }
                }
                broadcast_video()
                reply(`Sukses Broadcast ke *${pendaftar.length}* user!`)
            } else {
                async function broadcast_text() {
                    for (let i of pendaftar) {
                        geps.sendMessage(i, q, text)
                        await timer(3000)
                    }
                }
                broadcast_text()
                reply(`Sukses Broadcast ke *${pendaftar.length}* user!`)
            }
            break
        case prefix + 'delete':
        case prefix + 'del':
        case prefix + 'd':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isQuotedMsg) return reply(`Reply pesan dari bot`)
            if (!quotedMsg.fromMe) return reply(`Reply pesan dari bot`)
            geps.deleteMessage(from, {
                id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                remoteJid: from,
                fromMe: true
            })
            break
        case prefix + 'afk':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (isAfkOn) return reply('afk sudah diaktifkan sebelumnya')
            if (body.slice(150)) return reply('Alasanlu kepanjangan')
            let reason = body.slice(5) ? body.slice(5) : 'Nothing.'
            afk.addAfkUser(sender, Date.now(), reason, _afk)
            mentions(`@${sender.split('@')[0]} sedang afk\nAlasan : ${reason}`, [sender], true)
            break
        case prefix + 'infogrup':
        case prefix + 'infogrouup':
        case prefix + 'grupinfo':
        case prefix + 'groupinfo':
            if (!isGroup) return reply(mess.OnlyGrup)
            try {
                var pic = await geps.getProfilePicture(from)
            } catch {
                var pic = 'https://i.ibb.co/Tq7d7TZ/age-hananta-495-photo.png'
            }
            let ingfo = `「 *GROUP-INFO* 」\n\n*Name :* ${groupName}\n*ID Grup :* ${from}\n*Dibuat :* ${moment(`${groupMetadata.creation}` * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n*Owner Grup :* @${groupMetadata.owner.split('@')[0]}\n*Jumlah Admin :* ${groupAdmins.length}\n*Jumlah Peserta :* ${groupMembers.length}\n*Welcome :* ${isWelcome ? 'Aktif' : 'Mati'}\n*Left :* ${isLeft ? 'Aktif' : 'Mati'}\n*AntiLink :* ${isAntiLink ? 'Aktif' : 'Mati'}\n*AntiBadword :* ${isBadword ? 'Aktif' : 'Mati'}\n*Desc :* \n${groupMetadata.desc}`
            geps.sendMessage(from, await getBuffer(pic), image, {
                quoted: msg,
                caption: ingfo,
                contextInfo: {
                    "mentionedJid": [groupMetadata.owner.replace('@c.us', '@s.whatsapp.net')]
                }
            })
            break
        case prefix + 'add':
            if (!isOwner) return
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (isQuotedMsg && args.length < 2) {
                geps.groupAdd(from, [quotedMsg.sender])
                    .then((res) => {
                        if (res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us'].code === "403") {
                            let au = res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us']
                            geps.sendGroupInvite(from, quotedMsg.sender, au.invite_code, au.invite_code_exp, groupName, `Join bang`)
                            reply(`Mengirimkan groupInvite kepada nomor`)
                        } else {
                            reply(jsonformat(res))
                        }
                    })
                    .catch((err) => reply(jsonformat(err)))
            } else if (args.length < 3 && !isNaN(args[1])) {
                geps.groupAdd(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => {
                        if (res.participants[0][args[1] + '@c.us'].code === "403") {
                            let au = res.participants[0][args[1] + '@c.us']
                            geps.sendGroupInvite(from, args[1] + '@s.whatsapp.net', au.invite_code, au.invite_code_exp, groupName, `Join bang`)
                            reply(`Mengirimkan groupInvite kepada nomor`)
                        } else {
                            reply(jsonformat(res))
                        }
                    })
                    .catch((err) => reply(jsonformat(err)))
            } else {
                reply()
            }
            break
        case prefix + 'kick':
            if (!isOwner) return
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (mentioned.length > 1) return reply('Tagnya satu aja kaka')
            if (mentioned.length !== 0) {
                geps.groupRemove(from, mentioned)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (isQuotedMsg) {
                if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa kick Owner`)
                geps.groupRemove(from, [quotedMsg.sender])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (!isNaN(args[1])) {
                geps.groupRemove(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else {
                reply(`Kirim perintah ${prefix}kick @tag atau nomor atau reply pesan orang yang ingin di kick`)
            }
            break
        case prefix + 'promote':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (mentioned.length > 1) return reply('Tagnya satu aja kaka')
            if (mentioned.length !== 0) {
                geps.groupMakeAdmin(from, mentioned)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (isQuotedMsg) {
                geps.groupMakeAdmin(from, [quotedMsg.sender])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (!isNaN(args[1])) {
                geps.groupMakeAdmin(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else {
                reply(`Kirim perintah ${prefix}promote @tag atau nomor atau reply pesan orang yang ingin di promote`)
            }
            break
        case prefix + 'demote':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (mentioned.length > 1) return reply('Tagnya satu aja kaka')
            if (mentioned.length !== 0) {
                geps.groupDemoteAdmin(from, mentioned)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (isQuotedMsg) {
                if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa kick Owner`)
                geps.groupDemoteAdmin(from, [quotedMsg.sender])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else if (!isNaN(args[1])) {
                geps.groupDemoteAdmin(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else {
                reply(`Kirim perintah ${prefix}demote @tag atau nomor atau reply pesan orang yang ingin di demote`)
            }
            break
        case prefix + 'linkgc':
        case prefix + 'linkgrup':
        case prefix + 'linkgroup':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            geps.groupInviteCode(from)
                .then((res) => reply('https://chat.whatsapp.com/' + res))
            break
        case prefix + 'leave':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            reply('sy pamit kak ><')
                .then(() => geps.groupLeave(from))
            break
        case prefix + 'setdesc':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (args.length === 1) return reply(`Penggunaan ${prefix}setdesc desc`)
            geps.groupUpdateDescription(from, q)
                .then((res) => reply(jsonformat(res)))
                .catch((err) => reply(jsonformat(err)))
            break
        case prefix + 'anoboylast':
            request('https://anoboy.media/', function(err, res, html) {
                if (!err & res.statusCode == 200) {
                    var $ = cheerio.load(html)
                    var resultanoboylasts = []
                    $('div.amv').each((i, el) => {
                        var judullastanoboy = $(el).find('h3').text();
                        var lastupdatenoboy = $(el).find('div.jamup').text();
                        var resultanoboylast = {
                            Judul: judullastanoboy,
                            Waktu: lastupdatenoboy
                        }
                        resultanoboylasts.push(resultanoboylast)
                    })
                    var resultanoboylastt = `「 *ANOBOY-LAST* 」\n\n`
                    for (let i = 0; i < resultanoboylasts.length; i++) {
                        resultanoboylastt += `• Judul: ${resultanoboylasts[i].Judul}\n• Waktu: ${resultanoboylasts[i].Waktu.replace('UP', '')}\n\n`
                    }
                    reply(resultanoboylastt.trim())
                } else {
                    console.log(color('[Anoboylast]', 'red'), err)
                    reply(mess.error.api)
                }
            })
            break
        case prefix + 'neonimeongoing':
            const neonimeongoing = () => new Promise((resolve, reject) => {
                request('https://nekonime.vip/ongoing-list/', function(err, res, html) {
                    if (!err & res.statusCode == 200) {
                        const $ = cheerio.load(html)
                        const resultnekonime = []
                        $('div.article-body').each((i, el) => {
                            const judulnekonime = $(el).find('a').text();
                            const linknekonime = $(el).find('a').attr('href');
                            const resultnekopush = {
                                Judul: judulnekonime,
                                Link: linknekonime
                            }
                            resultnekonime.push(resultnekopush)
                        })
                        resolve({
                            status: 200,
                            data: resultnekonime
                        })
                    }
                })
            })

            neonimeongoing().then((res) => {
                var resultnekonime321 = `「 *NEONIME-ON-GOING* 」\n\n`
                for (let i = 0; i < res.data.length; i++) {
                    resultnekonime321 += `• Judul: ${res.data[i].Judul}\n• Link: ${res.data[i].Link}\n\n`
                }
                reply(mess.wait)
                reply(resultnekonime321.trim())
            }).catch((err) => {
                console.log(color('[NenimeOnGoing]', 'red'), err)
                reply(mess.error.api)
            })
            break
        case prefix + 'listgrup':
            const txtss = geps.chats.array.filter(v => v.jid.endsWith('g.us')).map(v => `• Grup: ${geps.contacts[v.jid] != undefined ? geps.contacts[v.jid].name || geps.contacts[v.jid].vname || geps.contacts[v.jid].notify : undefined}\n• Action: ${v.read_only ? 'Left' : 'Joined'}`).join `\n\n`
            reply(txtss.trim())
            break
        case prefix + 'searchmsg':
            if (!q) return reply(`Penggunaan : ${prefix}searchmsg <Kata>\nContoh : ${prefix}searchmsg udin`)
            const query = body.split(' ').slice(1).join(' ')
            const searched = await geps.searchMessages(query, from, 25, 1)
            if (searched.messages.length === 0) {
                reply(`Kata [ ${query} ] tidak ditemukan!`)
                return
            }
            let katatemu = `[ Message Search ]\n\nDitemukan ${searched.messages.length - 1} pesan!\n`
            for (let i = 1; i < searched.messages.length - 1; i++) {
                let typeSrc = Object.keys(searched.messages[i].message)[0]
                typeSrc = typeSrc === 'extendedTextMessage' && searched.messages[i].message.extendedTextMessage.text.includes('@') ? typeSrc = 'mentionedText' : typeSrc
                const bodySrc = typeSrc == 'conversation' ? searched.messages[i].message.conversation : typeSrc == 'mentionedText' ? searched.messages[i].message.extendedTextMessage.text : typeSrc == 'extendedTextMessage' ? searched.messages[i].message.extendedTextMessage.text : typeSrc == 'imageMessage' ? searched.messages[i].message.imageMessage.caption : typeSrc == 'stickerMessage' ? 'Sticker' : typeSrc == 'audioMessage' ? 'Audio' : typeSrc == 'videoMessage' ? searched.messages[i].message.videoMessage.caption : typeSrc == 'documentMessage' ? 'document' : '[ NOT FOUND BODY ]'
                const senderSrc = isGroup ? searched.messages[i].participant : searched.messages[i].key.remoteJid
                const jidSrc = senderSrc
                const contsSrc = searched.messages[i].key.fromMe ? geps.user.jid : geps.contacts[senderSrc] || {
                    notify: jidSrc.replace(/@.+/, '')
                }
                const pushnameSrc = searched.messages[i].key.fromMe ? geps.user.name : contsSrc.notify || contsSrc.vname || contsSrc.name || '-'

                katatemu += `

Pesan : ${bodySrc}
Type : ${typeSrc}
Pengirim : ${senderSrc.replace('@s.whatsapp.net', '')} ( ${pushnameSrc} )
`
            }
            reply(katatemu.trim())
            break
        case prefix + 'setgrupname':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (args.length === 1) return reply(`Penggunaan ${prefix}setgrupname name`)
            geps.groupUpdateSubject(from, q)
                .then((res) => reply(jsonformat(res)))
                .catch((err) => reply(jsonformat(err)))
            break
        case prefix + 'sider':
        case prefix + 'chatinfo':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isQuotedMsg) return reply(`Reply pesan dari bot`)
            if (!quotedMsg.fromMe) return reply(`Reply pesan dari bot`)
            geps.messageInfo(from, msg.message.extendedTextMessage.contextInfo.stanzaId)
                .then((res) => {
                    let anu = []
                    let txt = `*Info Chat*\n\n`
                    for (let i = 0; i < res.reads.length; i++) {
                        anu.push(res.reads[i].jid)
                        txt += `@${res.reads[i].jid.split("@")[0]}\n`
                        txt += `Waktu membaca : ${moment(`${res.reads[i].t}` * 1000).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n\n`
                    }
                    mentions(txt, anu, true)
                })
                .catch((err) => reply(jsonformat(err)))
            break
        case prefix + 'setppgrup':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (isImage || isQuotedImage) {
                let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                let media = await geps.downloadMediaMessage(encmedia)
                geps.updateProfilePicture(from, media)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
            } else {
                reply(`Kirim atau tag gambar dengan caption ${prefix}setppgrup`)
            }
            break
        case prefix + 'join':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`Kirim perintah *${prefix}join* link grup`)
            if (!isUrl(args[1]) && !args[1].includes('chat.whatsapp.com')) return reply(mess.error.Iv)
            let code = args[1].replace('https://chat.whatsapp.com/', '')
            geps.acceptInvite(code)
                .then((res) => reply(jsonformat(res)))
                .catch((err) => reply(jsonformat(err)))
            break
        case prefix + 'tagall':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            let arr = [];
            let txti = `*[ TAG ALL ]*\n\n${q ? q : ''}\n\n`
            for (let i of groupMembers) {
                txti += `=> @${i.jid.split("@")[0]}\n`
                arr.push(i.jid)
            }
            mentions(txti, arr, true)
            break
        case prefix + 'antibadword':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (args.length === 1) return reply(`Pilih on atau off`)
            if (args[1].toLowerCase() === 'on') {
                if (isBadword) return reply(`Udah aktif`)
                grupbadword.push(from)
                fs.writeFileSync('./database/grupbadword.json', JSON.stringify(grupbadword))
                reply(`antibadword grup aktif, kirim ${prefix}listbadword untuk melihat list badword`)
            } else if (args[1].toLowerCase() === 'off') {
                let anu = grupbadword.indexOf(from)
                grupbadword.splice(anu, 1)
                fs.writeFileSync('./database/grupbadword.json', JSON.stringify(grupbadword))
                reply('antibadword grup nonaktif')
            } else {
                reply(`Pilih on atau off`)
            }
            break
        case prefix + 'listbadword':
            let bi = `List badword\n\n`
            for (let boo of badword) {
                bi += `- ${boo}\n`
            }
            bi += `\nTotal : ${badword.length}`
            reply(bi)
            break
        case prefix + 'addbadword':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`masukkan kata`)
            if (isKasar(args[1].toLowerCase(), badword)) return reply(`Udah ada`)
            addBadword(args[1].toLowerCase(), badword)
            reply(`Sukses`)
            break
        case prefix + 'delbadword':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`masukkan kata`)
            if (!isKasar(args[1].toLowerCase(), badword)) return reply(`Ga ada`)
            delBadword(args[1].toLowerCase(), badword)
            reply(`Sukses`)
            break
        case prefix + 'clearbadword':
            if (!isOwner) return reply(mess.OnlyOwner)
            if (args.length < 2) return reply(`tag atau nomor`)
            if (mentioned.length !== 0) {
                for (let i = 0; i < mentioned.length; i++) {
                    delCountKasar(mentioned[i], senbadword)
                }
                reply('Sukses')
            } else {
                delCountKasar(args[1] + '@s.whatsapp.net', senbadword)
                reply('Sukses')
            }
            break
        case prefix + 'mute':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (isMuted) return reply(`udah mute`)
            mute.push(from)
            fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
            reply(`Bot berhasil dimute di chat ini`)
            break
        case prefix + 'antilink':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            if (args.length === 1) return reply(`Pilih on atau off`)
            if (args[1].toLowerCase() === 'on') {
                if (isAntiLink) return reply(`Udah aktif`)
                antilink.push(from)
                fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
                reply('Antilink grup aktif')
            } else if (args[1].toLowerCase() === 'off') {
                let anu = antilink.indexOf(from)
                antilink.splice(anu, 1)
                fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
                reply('Antilink grup nonaktif')
            } else {
                reply(`Pilih on atau off`)
            }
            break
        case prefix + 'welcome':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (args.length === 1) return reply(`Pilih on atau off`)
            if (args[1].toLowerCase() === 'on') {
                if (isWelcome) return reply(`Udah aktif`)
                welcome.push(from)
                fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome))
                reply('Welcome aktif')
            } else if (args[1].toLowerCase() === 'off') {
                let anu = welcome.indexOf(from)
                welcome.splice(anu, 1)
                fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome))
                reply('Welcome nonaktif')
            } else {
                reply(`Pilih on atau off`)
            }
            break
        case prefix + 'left':
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (args.length === 1) return reply(`Pilih on atau off`)
            if (args[1].toLowerCase() === 'on') {
                if (isLeft) return reply(`Udah aktif`)
                left.push(from)
                fs.writeFileSync('./database/left.json', JSON.stringify(left))
                reply('Left aktif')
            } else if (args[1].toLowerCase() === 'off') {
                let anu = left.indexOf(from)
                left.splice(anu, 1)
                fs.writeFileSync('./database/left.json', JSON.stringify(left))
                reply('Left nonaktif')
            } else {
                reply(`Pilih on atau off`)
            }
            break
        }
    } catch (err) {
        console.log(color('[ERROR]', 'red'), err)
    }
}