"use strict";
let {
    WAConnection: _WAConnection
} = require("@adiwajshing/baileys");
let {
    MessageType
} = require("@adiwajshing/baileys");
let {
    ownerNumber,
    botName
} = require('./config.json');
const {
    extendedText
} = MessageType
const qrcode = require("qrcode-terminal");
const figlet = require("figlet");
const fs = require("fs");

const {
    color,
    gepsLog
} = require("./lib/color");
const {
    serialize
} = require("./lib/myfunc");
const myfunc = require("./lib/myfunc");
const afk = require("./lib/afk");

let WAConnection = myfunc.WAConnection(_WAConnection)

let _afk = JSON.parse(fs.readFileSync('./database/afk.json'));
let welcome = JSON.parse(fs.readFileSync('./database/welcome.json'));
let left = JSON.parse(fs.readFileSync('./database/left.json'));
let setting_path = JSON.parse(fs.readFileSync('./config.json'));
let reqDB_tiktok = JSON.parse(fs.readFileSync('./database/ttdl_req.json'));
let reqDB = JSON.parse(fs.readFileSync('./database/ytdl_req.json'));
let balance = JSON.parse(fs.readFileSync('./database/balance.json'));
let blocked = [];

global.geps = new WAConnection()
geps.mode = 'public'
geps.baterai = {
    baterai: 0,
    cas: false
};
geps.multi = true
geps.nopref = false
geps.prefa = 'anjing'
geps.spam = []

require('./message/geps.js')
nocache('./message/geps.js', module => console.log(color(`'${module}' Telah berubah!`)))
require('./database/balance.json')
nocache('./database/balance.json', module => console.log(color(`'${module}' Telah berubah!`)))
require('./message/help.js')
nocache('./message/help.js', module => console.log(color(`'${module}' Telah berubah!`)))

const start = async (sesion) => {
    geps.logger.level = 'warn'
    geps.browserDescription = ['MacOs', 'Desktop', '3.0']

    // MENG WE EM
    console.log(color(figlet.textSync('EvilTwin-DCB', {
        font: 'Standard',
        horizontalLayout: 'default',
        vertivalLayout: 'default',
        whitespaceBreak: false
    }), 'cyan'))

    // Menunggu QR
    geps.on('qr', qr => {
        qrcode.generate(qr, {
            small: true
        })
        console.log(gepsLog('Scan QR ~~'))
    })

    // Restore Sesion
    fs.existsSync(sesion) && geps.loadAuthInfo(sesion)

    // Mencoba menghubungkan
    geps.on('connecting', () => {
        console.log(gepsLog('Connecting...'))
    })

    // Konek
    geps.on('open', (json) => {
        console.log(gepsLog('Connect, Welcome Owner'))
    })

    // Write Sesion
    await geps.connect({
        timeoutMs: 30 * 1000
    })
    fs.writeFileSync(sesion, JSON.stringify(geps.base64EncodedAuthInfo(), null, '\t'))

    // Ya gitulah
    geps.on('ws-close', () => {
        console.log(gepsLog('Koneksi terputus, mencoba menghubungkan kembali..'))
    })

    // Ntahlah
    geps.on('close', async ({
        reason,
        isReconnecting
    }) => {
        console.log(gepsLog('Terputus, Alasan :' + reason + '\nMencoba mengkoneksi ulang :' + isReconnecting))
        if (!isReconnecting) {
            console.log(gepsLog('Connect To Phone Rejected and Shutting Down.'))
        }
    })

    // Block
    geps.on('CB:Blocklist', json => {
        if (blocked.length > 2) return
        for (let i of json[1].blocklist) {
            blocked.push(i.replace('c.us', 's.whatsapp.net'))
        }
    })

    // Reject Call
    geps.on('CB:Call', async json => {
        let number = json[1]['from'];
        let isOffer = json[1]["type"] == "offer";
        if (number && isOffer && json[1]["data"]) {
            var tag = geps.generateMessageTag();
            var NodePayload = ["action", "call", ["call", {
                    "from": geps.user.jid,
                    "to": number.split("@")[0] + "@s.whatsapp.net",
                    "id": tag
                },
                [
                    ["reject", {
                        "call-id": json[1]['id'],
                        "call-creator": number.split("@")[0] + "@s.whatsapp.net",
                        "count": "0"
                    }, null]
                ]
            ]];
            geps.send(`${tag}, ${JSON.stringify(NodePayload)}`)
            geps.sendMessage(number, `Tolong jangan telpon saya jika tidak ingin diblock!\n\n*WhatsApp Bot*`, MessageType.text);
        }
    })

    // Action Battery
    geps.on('CB:action,,battery', json => {
        const a = json[2][0][1].value
        const b = json[2][0][1].live
        geps.baterai.baterai = a
        geps.baterai.cas = b
    })

    // Anti delete
    geps.on('message-delete', async (json) => {
        require('./message/antidelete')(geps, json)
    })

    // DETECTOR DEMOTE / PROMOTE PARTICIPANTS
    geps.on('group-participants-update', async (json) => {
        if (json.action === "demote") {
            let this_mem = ''
            let thisA_mem = [];
            for (let x = 0; x < json.participants.length; x++) {
                this_mem += `• @${json.participants[x].split('@')[0]}\n`
                thisA_mem.push(json.participants[x])
            }
            geps.sendMessage(json.jid, `「 *DEMOTE-DETECTED!* 」\n\n *Total:* ${json.participants.length}\n\n${this_mem}`, extendedText, {
                contextInfo: {
                    "mentionedJid": thisA_mem
                }
            })
        } else if (json.action === "promote") {
            let this_mem = ''
            let thisA_mem = [];
            for (let x = 0; x < json.participants.length; x++) {
                this_mem += `• @${json.participants[x].split('@')[0]}\n`
                thisA_mem.push(json.participants[x])
            }
            geps.sendMessage(json.jid, `「 *PROMOTE-DETECTED!* 」\n\n *Total:* ${json.participants.length}\n\n${this_mem}`, extendedText, {
                contextInfo: {
                    "mentionedJid": thisA_mem
                }
            })
        }
    })

    // Chat
    geps.on('chat-update', async (m) => {
        // Presence
        if (m.presences) {
            for (let key in m.presences) {
                if (m.presences[key].lastKnownPresence === "composing" || m.presences[key].lastKnownPresence === "recording") {
                    if (afk.checkAfkUser(key, _afk)) {
                        _afk.splice(afk.getAfkPosition(key, _afk), 1)
                        fs.writeFileSync('./database/afk.json', JSON.stringify(_afk))
                        geps.sendMessage(m.jid, `@${key.split("@")[0]} berhenti afk, dia sedang ${m.presences[key].lastKnownPresence === "composing" ? "mengetik" : "merekam"}`, MessageType.extendedText, {
                            contextInfo: {
                                "mentionedJid": [key]
                            }
                        })
                    }
                }
            }
        }
        if (!m.hasNewMessage) return
        m = m.messages.all()[0]

        // Anti oversized
        if (m.messageStubType) {
            if (m.messageStubType == 68) {
                geps.clearMessage(m.key)
            }
        }
        if (!m.message) return
        if (m.key && m.key.remoteJid == 'status@broadcast') return
        let msg = serialize(geps, m)

        // Detect Troli
        if (msg.message && msg.isBaileys && msg.isQuotedMsg && msg.quotedMsg.type === 'orderMessage') {
            geps.clearMessage(msg.key)
        }

        require('./message/geps')(geps, msg, blocked, _afk, welcome, left, reqDB, reqDB_tiktok, setting_path)
        require('./message/button_respon')(geps, msg, reqDB, reqDB_tiktok, balance)
    })

    // Event Group 
    geps.on('group-participants-update', async (anj) => {
        require("./message/group")(geps, anj, welcome, left)
    })
}
/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => {}) {
    console.log(color(`Module ${module} Dipantau oleh kang Bakso`))
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}

start(`./${setting_path.sessionName}.json`)
    .catch(err => console.log(err))