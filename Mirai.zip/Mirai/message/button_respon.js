"use strict";

// Module
const {
    MessageType,
    groupSettingChange,
    Mimetype
} = require('@adiwajshing/baileys');
const fs = require('fs');
const cheerio = require('cheerio');
const axios = require('axios');
const {
    addReqtiktok,
    checkReqtiktok,
    deleteReqtiktok,
    getReqtiktok
} = require('../lib/ttdl_button');
const {
    addReq,
    checkReq,
    deleteReq,
    getReq
} = require('../lib/ytdl_button');
const {
    color
} = require('../lib/color');
const {
    ytdlmp3,
    ytdlmp4
} = require('../scrape/ytdl');
const {
    getGroupAdmins,
    getBuffer
} = require('../lib/myfunc');
const {
    addBalance
} = require('../lib/limit');

// Path Config
let setting = JSON.parse(fs.readFileSync('./config.json'));
let mess = JSON.parse(fs.readFileSync('./message/mess.json'));
let {
    botName,
    ownerNumber
} = setting

module.exports = async (geps, msg, reqDB, reqDB_tiktok, balance) => {
    try {
        const {
            type,
            sender,
            from,
            isGroup
        } = msg
        const botNumber = geps.user.jid
        const groupMetadata = isGroup ? await geps.groupMetadata(from) : ''
        const groupMembers = isGroup ? groupMetadata.participants : ''
        const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
        const isOwner = ownerNumber.includes(sender)
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
        const isGroupAdmins = groupAdmins.includes(sender) || false
        const isButton = (type == 'buttonsResponseMessage') ? msg.message.buttonsResponseMessage.selectedDisplayText : ''

        const reply = (str) => {
            return geps.sendMessage(from, str, MessageType.text, {
                quoted: msg
            })
        }

        function randomNomor(angka) {
            return Math.floor(Math.random() * angka) + 1
        }

        async function sendFileFromUrl(from, url, caption, msg, men) {
            let damta = await getBuffer(url)
            let res = await axios.head(url)
            let mime = res.headers['content-type'] ? res.headers['content-type'] : "image/gif"
            let type = mime.split("/")[0] + "Message"
            if (mime === "image/gif") {
                type = MessageType.video
                mime = Mimetype.gif
            }
            if (mime === "application/pdf") {
                type = MessageType.document
                mime = Mimetype.pdf
            }
            if (mime.split("/")[0] === "audio") {
                mime = Mimetype.mp4Audio
            }
            return geps.sendMessage(from, damta, type, {
                caption: caption,
                quoted: msg,
                mimetype: mime,
                contextInfo: {
                    "mentionedJid": men ? men : []
                }
            })
        }

        if (isButton === 'OPEN') {
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            geps.groupSettingChange(from, "announcement", false)
                .then((res) => reply('Success'))
                .catch((err) => reply('Error!'))
        } else if (isButton === 'CLOSE') {
            if (!isGroup) return reply(mess.OnlyGrup)
            if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
            if (!isBotGroupAdmins) return reply(mess.BotAdmin)
            geps.groupSettingChange(from, "announcement", true)
                .then((res) => reply('Success'))
                .catch((err) => reply('Error!'))
        } else if (isButton === "BATU") {
            let suit = ["gunting", "batu", "kertas"];
            let suit1 = suit[Math.floor(Math.random() * (suit.length))]
            let hadi = randomNomor(30)
            if (suit1 === "batu") {
                reply(`Kamu: *BATU*\nKomputer: *${suit1}*\nSeri`)
            } else if (suit1 === "kertas") {
                reply(`Kamu: *BATU*\nKomputer: *${suit1}*\nKamu kalah`)
            } else {
                reply(`Kamu *BATU*\nKomputer: *${suit1}*\nKamu menang\nHadiah : ${hadi} balance`)
                addBalance(sender, hadi, balance)
            }
        } else if (isButton === "GUNTING") {
            let suit = ["gunting", "batu", "kertas"];
            let suit1 = suit[Math.floor(Math.random() * (suit.length))]
            let hadi = randomNomor(30)
            if (suit1 === "gunting") {
                reply(`Kamu: *GUNTING*\nKomputer: *${suit1}*\nseri`)
            } else if (suit1 === "batu") {
                reply(`Kamu: *GUNTING*\nKomputer: *${suit1}*\nKamu kalah`)
            } else {
                reply(`Kamu: *GUNTING*\nKomputer: *${suit1}*\nKamu menang\nHadiah : ${hadi} balance`)
                addBalance(sender, hadi, balance)
            }
        } else if (isButton === "KERTAS") {
            let suit = ["gunting", "batu", "kertas"];
            let suit1 = suit[Math.floor(Math.random() * (suit.length))]
            let hadi = randomNomor(30)
            if (suit1 === "kertas") {
                reply(`Kamu: *KERTAS*\nKomputer: *${suit1}*\nSeri`)
            } else if (suit1 === "gunting") {
                reply(`Kamu: *KERTAS*\nKomputer: *${suit1}*\nKamu kalah`)
            } else {
                reply(`Kamu: *KERTAS*\nKomputer: *${suit1}*\nKamu menang\nHadiah : ${hadi} balance`)
                addBalance(sender, hadi, balance)
            }
        } else if (isButton === "VIDEO") {
            if (!checkReq(sender, reqDB)) return false;
            ytdlmp4(getReq(sender, reqDB)).then(r => {
                reply('_Mohon Tunggu sebentar, media video akan segera dikirim.._')
                if (Number(r[0].filesize.split(' MB')[0]) >= 50.0) {
                    axios.get(`https://tinyurl.com/api-create.php?url=${r[1].dlink}`).then(r => {
                        reply(`_Mohon maaf, media tersebut melebihi batas yang disajikan, Silahkan download menggunakan link dibawah_\n\n${r.data}`)
                        deleteReq(sender, reqDB)
                    }).catch(err => {
                        reply(mess.error.api)
                        deleteReq(sender, reqDB)
                    })
                }
                sendFileFromUrl(from, r[1].dlink, 'nih..', msg)
                deleteReq(sender, reqDB)
            }).catch(err => {
                reply(mess.error.api)
                deleteReq(sender, reqDB)
            });
        } else if (isButton === "AUDIO") {
            if (!checkReq(sender, reqDB)) return false;
            ytdlmp3(getReq(sender, reqDB)).then(r => {
                reply('_Mohon Tunggu sebentar, media audio akan segera dikirim.._')
                if (Number(r[0].filesize.split(' MB')[0]) >= 30.0) {
                    axios.get(`https://tinyurl.com/api-create.php?url=${r[1].dlink}`).then(x => {
                        reply(`_Mohon maaf, media tersebut melebihi batas yang disajikan, Silahkan download menggunakan link dibawah_\n\n${x.data}`)
                        deleteReq(sender, reqDB)
                    }).catch(e => {
                        reply(mess.error.api)
                        deleteReq(sender, reqDB)
                    })
                }
                sendFileFromUrl(from, r[1].dlink, 'nih..', msg)
                deleteReq(sender, reqDB)
            }).catch(e => {
                reply(mess.error.api)
                deleteReq(sender, reqDB)
            });
        } else if (isButton === "MP4-WM") {
            if (!checkReqtiktok(sender, reqDB_tiktok)) return false;
            reply('_Mohon Tunggu sebentar, media video-wm akan segera dikirim.._')

            axios.get('https://en.tiktok-downloader.online/').then(r => {
                const $ = cheerio.load(r.data);
                var _tomken = $('head > meta:nth-child(3)').attr('content');

                axios({
                    method: 'GET',
                    url: `https://en.tiktok-downloader.online/api/v1/fetch?url=${getReqtiktok(sender, reqDB_tiktok)}`,
                    data: new URLSearchParams(Object.entries({
                        url: getReqtiktok(sender, reqDB_tiktok)
                    })),
                    headers: {
                        'token': _tomken,
                        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
                    }
                }).then(r => {
                    sendFileFromUrl(from, r.data.url, "", msg)
                    deleteReqtiktok(sender, reqDB_tiktok)
                }).catch(e => {
                    reply(mess.error.api)
                    deleteReqtiktok(sender, reqDB_tiktok)
                });
            });
        } else if (isButton === "MP4-NOWM") {
            if (!checkReqtiktok(sender, reqDB_tiktok)) return false;

            reply('_Mohon Tunggu sebentar, media video-nowm akan segera dikirim.._')
            axios.get('https://en.tiktok-downloader.online/').then(r => {
                const $ = cheerio.load(r.data);
                var _tomken = $('head > meta:nth-child(3)').attr('content');

                axios({
                    method: 'GET',
                    url: `https://en.tiktok-downloader.online/api/v1/fetch?url=${getReqtiktok(sender, reqDB_tiktok)}`,
                    data: new URLSearchParams(Object.entries({
                        url: getReqtiktok(sender, reqDB_tiktok)
                    })),
                    headers: {
                        'token': _tomken,
                        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
                    }
                }).then(r => {
                    sendFileFromUrl(from, r.data.url_nwm, "", msg)
                    deleteReqtiktok(sender, reqDB_tiktok)
                }).catch(e => {
                    reply(mess.error.api)
                    deleteReqtiktok(sender, reqDB_tiktok)
                });
            });
        } else if (isButton === "MP3") {
            if (!checkReqtiktok(sender, reqDB_tiktok)) return false;

            reply('_Mohon Tunggu sebentar, media MP3 akan segera dikirim.._')
            axios.get('https://en.tiktok-downloader.online/').then(r => {
                const $ = cheerio.load(r.data);
                var _tomken = $('head > meta:nth-child(3)').attr('content');

                axios({
                    method: 'GET',
                    url: `https://en.tiktok-downloader.online/api/v1/fetch?url=${getReqtiktok(sender, reqDB_tiktok)}`,
                    data: new URLSearchParams(Object.entries({
                        url: getReqtiktok(sender, reqDB_tiktok)
                    })),
                    headers: {
                        'token': _tomken,
                        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
                    }
                }).then(r => {
                    sendFileFromUrl(from, r.data.music.url, "", msg)
                    deleteReqtiktok(sender, reqDB_tiktok)
                }).catch(e => {
                    reply(mess.error.api)
                    deleteReqtiktok(sender, reqDB_tiktok)
                });
            });
        }
    } catch (err) {
        console.log(color('[ERROR]', 'red'), err)
    }
}